# NOCTURNE (سُكون) — Super AMOLED Liquid Glass Music Player

A mobile-first, bilingual (Arabic RTL / English LTR) local music player crafted on a true `#000000` Super AMOLED canvas with refractive Liquid Glass surfaces, GPU motion-blur transitions, automatic exclusion of voice recordings and short clips, a real dual-deck Web Audio crossfade engine, and live online synced lyrics.

### User Review & Critical Decisions

> [!IMPORTANT]
> All core product preferences were confirmed during discovery and are locked into this blueprint:
> - **Bilingual Interface (`AR` / `EN`)**: Full Arabic (`dir="rtl"`) and English (`dir="ltr"`) support with an instant live switcher in Settings (defaulting to Arabic RTL).
> - **Adaptive Ice-Silver Accent**: Neutral luminous ice-silver (`#E2E8F0`) default accent on pure `#000000` AMOLED black, dynamically tinted by the dominant hue extracted from the active track's embedded album artwork (clamped for WCAG AA legibility).
> - **Device-Only Library (Zero Demo Tracks)**: Launches directly into a sleek local import experience supporting device folder scanning and multi-file selection, persisted locally in IndexedDB—no preloaded sample songs.
> - **Default Short-Clip Filter (< 30s)**: Audio files shorter than 30 seconds and detected voice/call recordings are automatically filtered out on scan, with customizable duration thresholds and a recoverable Quarantine Drawer in Settings.

---

### 1. Overview & Core Concept

- **What It Does**: Scans user-selected folders or audio files from the phone/desktop storage, parses embedded ID3/MP4/FLAC metadata and album artwork, automatically filters out voice memos, call recordings, and short sound clips (`< 30s`), persists the clean library in IndexedDB, and plays tracks through a dual-deck Web Audio crossfade engine with real-time synced LRC lyrics fetched from LRCLIB.
- **Target Audience / Persona**: Mobile listeners who keep curated offline music libraries (MP3, M4A, FLAC, WAV, OGG, Opus) on their phones and want a distraction-free, battery-friendly AMOLED player that never accidentally plays WhatsApp voice notes, call recordings, or notification chimes.
- **Key Value**: Solves the #1 frustration of local phone music players—polluted libraries filled with voice recordings and short clips—while delivering flagship Liquid Glass motion design, seamless crossfading, and karaoke-grade synced lyrics.

---

### 2. User Experience & Visual Design

- **Key User Flows**:
  1. **First-Launch Empty State & Device Import**: Users see a clean `#000000` AMOLED canvas with a centered Liquid Glass import card offering two touch-friendly actions: *Select Music Folder* (File System Access API / directory picker) and *Select Audio Files* (universal mobile/iOS/Android fallback). As files load, a live scan summary reports imported songs vs. automatically excluded recordings and short clips.
  2. **Main Library & Smart Filtering**: Displays the clean music list (`56px–64px` touch rows, album art thumbnail, track title, `Artist · Album · Duration` unboxed metadata) with instant search, sort (Title, Artist, Duration, Date Added), and quick view tabs (*All Songs*, *Folders*, *Favorites*, *Excluded Quarantine*).
  3. **Mini-Player & Morphing Now Playing Sheet**: Tapping any song triggers a spring + motion-blur slide-up reveal of the compact floating Mini-Player bar directly above the floating navigation dock. Tapping the Mini-Player expands it with a smooth motion-blur shared transition into the full-screen **Now Playing** canvas (dynamic ambient artwork glow, interactive scrubber, playback controls, queue access, and live synced lyrics toggle). Closing or swiping down smoothly collapses it back into the bottom Mini-Player.
  4. **Track Context Menu (Liquid Glass Action Sheet)**: Tapping the three-dot affordance on any track opens a blurred Liquid Glass bottom sheet (`rounded-t-3xl` on mobile, centered glass modal on desktop) with actions: *Play Next*, *Add to Queue*, *Search Synced Lyrics*, *Track Metadata & Audio Specs*, and *Move to Excluded / Restore*.
  5. **Online Synced Lyrics View**: Automatically queries LRCLIB (`get` -> `search` fallback) using parsed tags or cleaned filename. Time-synced `[mm:ss.xx]` lines auto-scroll to center, highlighting the active phrase while subtly softening surrounding lines. Users can tap any lyric line to seek to that exact timestamp, adjust timing offset (`-5.0s` to `+5.0s`), manually search LRCLIB, or attach a local `.lrc` file.
  6. **Crossfade & Filter Settings**: Dedicated Settings view with bilingual `AR / EN` switcher, Crossfade ON/OFF toggle + duration selector (`1s–12s`), Short-Clip duration threshold slider (`10s–120s`), Voice Recording pattern toggles, and Excluded Items Quarantine inspector.

- **Visual Identity & Theme**:
  - *Aesthetic Direction*: Nocturnal Liquid Glass on True OLED Obsidian—high-craft acoustic minimalism with optical glass refraction, zero neon clutter, and ultra-fluid compositor animations.
  - *Color Palette & Mood*:
    - `--background`: `#000000` (60%+ Pure Super AMOLED Black canvas for true pixel-off depth)
    - `--surface-glass`: `rgba(20, 20, 24, 0.58)` with `backdrop-filter: blur(28px) saturate(180%)` and `1px` specular top-rim highlight (`rgba(255, 255, 255, 0.12)`)
    - `--text-primary`: `#F8FAFC` / `--text-muted`: `#94A3B8`
    - `--accent`: Dynamic Ice-Silver `#E2E8F0` default, smoothly interpolated to a luminance-safe tint extracted from the playing track's artwork via offscreen `<canvas>` sampling.
  - *Typography & Hierarchy*:
    - Bilingual Display & UI: **IBM Plex Sans Arabic** paired with **Plus Jakarta Sans** (`400`, `500`, `600`, `700`) for crisp optical balance across RTL Arabic and LTR English.
    - Timestamps & Audio Metrics: **JetBrains Mono** (`tabular-nums`) for playback progress, crossfade duration (`4.0s`), and audio file durations.
    - Strict zero-pill metadata (`Artist · 03:42 · MP3`) and zero orphan headlines.
  - *Responsive Layout Architecture*:
    - Mobile (`< 1024px`): Thumb-zone ergonomic layout with floating bottom Liquid Glass navigation dock + collapsible Mini-Player kept compact inside the bottom thumb zone (`<= 15%` aggregate sticky height budget).
    - Desktop (`>= 1024px`): Expands into a balanced multi-column studio workspace (Sidebar Navigation & Smart Filter summary | Main Library / Folders / Settings | Persistent Now Playing & Live Synced Lyrics Stage).

- **Interactive Feedback & Motion**:
  - Page switches, sheet openings, and Now Playing transitions animate strictly GPU-compositor properties (`transform`, `opacity`, `filter: blur(...)`) for authentic **motion-blur inertia** (`cubic-bezier(0.16, 1, 0.3, 1)`), automatically respecting `prefers-reduced-motion`.
  - Tactile scale feedback (`active:scale-[0.97]`) on `>= 44x44px` touch targets, inline scan progress bar during device import, and recoverable error/empty states for offline lyrics lookup or unsupported folder permissions.

---

### 3. Key Product Decisions & Trade-Offs

- **Decision 1: Dual-Deck Web Audio Crossfade Engine**
  - *Chosen Approach*: Two synchronized `<audio>` decks (`Deck A` and `Deck B`) routed through a Web Audio `AudioContext` with individual `GainNode`s using equal-power fade curves (`cos/sin` ramping), plus automatic graceful fallback to direct HTMLAudio playback if a browser restricts `MediaElementAudioSourceNode`.
  - *Why*: Standard single `<audio>` elements cannot overlap two songs simultaneously. Equal-power gain ramping prevents the noticeable volume dip in the middle of a crossfade.
  - *Alternatives Considered*: Single audio element volume fade-out/in (creates awkward silence gaps) or decoding entire MP3s into `AudioBuffer` RAM (causes mobile browser crashes on large libraries).

- **Decision 2: Smart Heuristic + Quarantine Filter Architecture**
  - *Chosen Approach*: Two-stage automatic filter during import: (1) Duration gate (`duration < thresholdSeconds`, default `30s`) and (2) Path/Filename/Format recording detector matching common mobile voice-recorder signatures (`Recordings`, `Call`, `Voice`, `PTT-`, `AUD-`, `WhatsApp Audio`, `Telegram`, `Memo`, `تسجيل`, `مكالمة`, `.amr`, `.3gp`, etc.). Excluded tracks are logged into a **Quarantine** list rather than silently deleted, allowing 1-tap manual restoration.
  - *Why*: Protects users from losing a legitimate short interlude or misnamed song while keeping the primary library 100% clean automatically.
  - *Alternatives Considered*: Hard-ignoring files without a quarantine log (risks user confusion when a known file appears missing).

- **Decision 3: IndexedDB Local Persistence & Client-Side Metadata/Lyrics**
  - *Chosen Approach*: Store imported audio files (`Blob` + optional `FileSystemDirectoryHandle`), parsed ID3v2/MP4/FLAC tags, extracted cover art, cached LRCLIB lyrics, and user settings inside browser IndexedDB + `localStorage`. Query `https://lrclib.net/api/get` and `/api/search` directly via CORS with `Lrclib-Client` identification header.
  - *Why*: Zero backend latency, works offline for playback and previously fetched lyrics on mobile, and preserves privacy (user audio files never leave the device).
  - *Alternatives Considered*: Uploading user audio files to a server (slow, bandwidth-heavy, unnecessary for local playback).

---

### 4. Technical Architecture & Data Strategy

#### System Architecture Diagram

```
┌─────────────────────────────────────────────────────────────────────────┐
│                        DEVICE STORAGE & NETWORK                         │
│  [Folder Picker / File Picker]        [LRCLIB Public Synced Lyrics API] │
└───────────────┬────────────────────────────────────────┬────────────────┘
                │ File / Blob / Handle                   │ GET /api/get & /search
                ▼                                        ▼
┌─────────────────────────────────────────────────────────────────────────┐
│                    MEDIA INGESTION & PERSISTENCE LAYER                  │
│  ┌──────────────────────┐   ┌───────────────────────┐   ┌────────────┐  │
│  │ Metadata & Art Parser│   │ Smart Filter Engine   │   │ IndexedDB  │  │
│  │ (ID3v2 / MP4 / FLAC) │──▶│ - Voice/Call Regex    │──▶│ + Settings │  │
│  │ + Dominant Hue Calc  │   │ - Short Clip (< 30s)  │   │   Store    │  │
│  └──────────────────────┘   └───────────────────────┘   └─────┬──────┘  │
└───────────────────────────────────────────────────────────────┼─────────┘
                                                                │
┌───────────────────────────────────────────────────────────────┼─────────┐
│                       DUAL-DECK AUDIO ENGINE                  ▼         │
│  ┌─────────────┐      ┌───────────────┐      ┌───────────────────────┐  │
│  │   Deck A    │─────▶│ GainNode A    │─────▶│                       │  │
│  │ (<audio>)   │      │ (Equal-Power) │      │  Web Audio Master     │  │
│  └─────────────┘      └───────────────┘      │  Destination &        │  │
│  ┌─────────────┐      ┌───────────────┐      │  MediaSession API     │  │
│  │   Deck B    │─────▶│ GainNode B    │─────▶│  (Lockscreen Controls)│  │
│  │ (<audio>)   │      │ (Equal-Power) │      └───────────────────────┘  │
│  └─────────────┘      └───────────────┘                                 │
└───────────────────────────────────────────────────────────────┬─────────┘
                                                                │
┌───────────────────────────────────────────────────────────────┼─────────┐
│               LIQUID GLASS UI & MOTION-BLUR LAYER             ▼         │
│  ┌──────────────┐  ┌──────────────────┐  ┌───────────────────────────┐  │
│  │ Floating Nav │  │ Mini-Player Bar  │  │ Full Now Playing & Lyrics │  │
│  │ Dock (Glass) │  │ (Morphs Open /   │  │ - Synced LRC Scroller     │  │
│  │ - Library    │  │  Close Animation)│  │ - Tap-to-Seek Lines       │  │
│  │ - Folders    │  └────────┬─────────┘  │ - Track Action Sheet      │  │
│  │ - Settings   │           └───────────▶│ - Queue & Offset Controls │  │
│  └──────────────┘                        └───────────────────────────┘  │
└─────────────────────────────────────────────────────────────────────────┘
```

#### Data Model & State

- **Track Entity**: `id`, `title`, `artist`, `album`, `duration`, `folderPath`, `fileName`, `mimeType`, `fileSize`, `coverUrl` (object URL from blob), `accentColor` (luminance-safe RGB/Hex), `audioBlob`, `isFavorite`, `addedAt`, `exclusionReason` (`null | 'recording' | 'short_duration'`), `manuallyRestored` (`boolean`).
- **Lyrics Entity**: `trackId`, `syncedLines` (`Array<{ timeMs: number, text: string }>`), `plainLyrics`, `offsetMs`, `source` (`'lrclib' | 'local_lrc' | 'none'`).
- **Settings State**: `language` (`'ar' | 'en'`), `crossfadeEnabled` (`boolean`), `crossfadeSeconds` (`1–12`), `minDurationSeconds` (`10–120`, default `30`), `autoExcludeRecordings` (`boolean`), `customExcludeKeywords` (`string[]`), `dynamicArtworkAccent` (`boolean`).
- **Playback State**: `currentTrackId`, `queueIds`, `isPlaying`, `currentTime`, `duration`, `shuffle`, `repeatMode` (`'off' | 'all' | 'one'`), `activeDeck` (`'A' | 'B'`), `isCrossfading`, `isNowPlayingOpen`, `contextMenuTrackId`.

#### Interactive Component & State Mapping

- **Import Trigger & Re-Scan**: Clicking *Select Music Folder* or *Select Audio Files* invokes the browser picker, extracts metadata & duration per file, runs the Smart Filter Engine in real time (updating progress counters), saves valid & quarantined items to IndexedDB, and refreshes the Library view.
- **Filter Threshold & Recording Rules (Settings)**: Updating `minDurationSeconds` or toggling `autoExcludeRecordings` immediately re-evaluates all stored tracks in memory and IndexedDB without re-importing files, moving tracks cleanly between *Library* and *Quarantine*.
- **Crossfade Controls (Settings)**: Toggling `crossfadeEnabled` or dragging `crossfadeSeconds` updates the audio engine's live scheduler; when enabled, `timeupdate` checks `remaining <= crossfadeSeconds` to pre-load Deck B, trigger `play()`, and schedule `GainNode` equal-power ramps.
- **Track Row & Context Sheet**: Tapping a track loads it into the active deck (or crossfades if already playing) and animates the Mini-Player bar into view at the bottom. Tapping the `...` button opens the Liquid Glass Track Action Sheet with working handlers for Queue management, Lyrics search, Metadata inspection, and Quarantine toggle.
- **Synced Lyrics Controller**: On track change, checks IndexedDB lyrics cache first; on miss, cleans filename/tags and queries LRCLIB (`get` -> `search`). Renders synchronized lines tracked via `requestAnimationFrame` / time updates; clicking any line seeks the active deck immediately.
- **Bilingual RTL/LTR Switcher**: Toggling `AR / EN` updates `document.documentElement.dir` (`rtl` / `ltr`), `lang`, and translates all UI labels, motion directions, and numeric formats seamlessly.
