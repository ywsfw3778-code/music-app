import type { Language } from '../types/music';

export interface Translations {
  appName: string;
  appSubtitle: string;
  navLibrary: string;
  navFolders: string;
  navSettings: string;
  importFolder: string;
  importFiles: string;
  importMore: string;
  emptyTitle: string;
  emptyDescription: string;
  emptyFilterNote: string;
  searchPlaceholder: string;
  tabAllSongs: string;
  tabPlaylists: string;
  tabFavorites: string;
  tabQuarantine: string;
  createPlaylist: string;
  playlistNamePlaceholder: string;
  createAction: string;
  savePlaylist: string;
  addSongsAction: string;
  playlistBuilderHint: string;
  noPlaylistsTitle: string;
  noPlaylistsDesc: string;
  addToPlaylist: string;
  removeFromPlaylist: string;
  deletePlaylist: string;
  playlistSettingsTitle: string;
  playlistSettingsDesc: string;
  playlistReorderSection: string;
  moveTrackUp: string;
  moveTrackDown: string;
  reversePlaylistOrder: string;
  sortPlaylistAlpha: string;
  deletePlaylistDangerTitle: string;
  deletePlaylistConfirmQuestion: string;
  deletePlaylistTypeHint: string;
  deletePlaylistWord: string;
  deletePlaylistFinalBtn: string;
  saveChanges: string;
  playAll: string;
  backToPlaylists: string;
  emptyPlaylistDesc: string;
  toastPlaylistCreated: string;
  toastAddedToPlaylist: string;
  toastRemovedFromPlaylist: string;
  sortTitle: string;
  sortArtist: string;
  sortDuration: string;
  sortRecent: string;
  songsCount: string;
  filteredCount: string;
  unknownArtist: string;
  unknownAlbum: string;
  scanningTitle: string;
  scanningSummary: string;
  scanDoneToast: string;
  noSearchResults: string;
  noFavoritesTitle: string;
  noFavoritesDesc: string;
  noQuarantineTitle: string;
  noQuarantineDesc: string;
  foldersEmptyTitle: string;
  foldersEmptyDesc: string;
  allFolders: string;
  reasonRecording: string;
  reasonShortClip: string;
  restoreTrack: string;
  excludeTrack: string;
  nowPlaying: string;
  lyricsTab: string;
  queueTab: string;
  artworkTab: string;
  fetchingLyrics: string;
  noLyricsFound: string;
  noLyricsHint: string;
  searchLyricsOnline: string;
  uploadLrcFile: string;
  syncedBadge: string;
  plainLyricsNote: string;
  lyricOffset: string;
  tapLineToSeek: string;
  manualSearchTitle: string;
  manualSearchPlaceholder: string;
  manualSearchAction: string;
  searchResultsEmpty: string;
  applyLyrics: string;
  crossfadeActive: string;
  playNext: string;
  addToQueue: string;
  addToFavorites: string;
  removeFromFavorites: string;
  viewLyrics: string;
  trackDetails: string;
  deleteFromLibrary: string;
  fileFormat: string;
  fileSize: string;
  fileDuration: string;
  folderLocation: string;
  fileNameLabel: string;
  close: string;
  cancel: string;
  upNext: string;
  queueEmpty: string;
  clearQueue: string;
  settingsTitle: string;
  settingsSubtitle: string;
  languageSection: string;
  languageLabel: string;
  languageDesc: string;
  crossfadeSection: string;
  crossfadeToggle: string;
  crossfadeDesc: string;
  crossfadeDuration: string;
  secondsUnit: string;
  filterSection: string;
  autoExcludeRecordings: string;
  autoExcludeRecordingsDesc: string;
  minDurationLabel: string;
  minDurationDesc: string;
  customKeywordsLabel: string;
  customKeywordsPlaceholder: string;
  addKeyword: string;
  appearanceSection: string;
  dynamicAccentLabel: string;
  dynamicAccentDesc: string;
  artworkBgLabel: string;
  artworkBgDesc: string;
  artworkBgFull: string;
  artworkBgPartial: string;
  artworkBgOff: string;
  storageSection: string;
  rescanFilters: string;
  clearLibrary: string;
  clearLibraryConfirm: string;
  confirmDelete: string;
  libraryStats: string;
  toastPlayNext: string;
  toastAddedQueue: string;
  toastRestored: string;
  toastExcluded: string;
  toastCrossfadeOn: string;
  toastCrossfadeOff: string;
  toastLyricsApplied: string;
  toastLibraryCleared: string;
  desktopStageIdleTitle: string;
  desktopStageIdleDesc: string;
  openMiniPlayerHint: string;
  stopAndClose: string;
}

export const TRANSLATIONS: Record<Language, Translations> = {
  ar: {
    appName: 'سُكون',
    appSubtitle: 'مشغل صوتي محلي',
    navLibrary: 'المكتبة',
    navFolders: 'المجلدات',
    navSettings: 'الإعدادات',
    importFolder: 'اختيار مجلد الأغاني',
    importFiles: 'اختيار ملفات صوتية',
    importMore: 'إضافة من الجهاز',
    emptyTitle: 'مكتبتك الصوتية جاهزة للاستيراد',
    emptyDescription:
      'اختر مجلد الموسيقى أو الملفات الصوتية من جهازك. يقوم التطبيق باستبعاد التسجيلات الصوتية والمقاطع القصيرة تلقائياً.',
    emptyFilterNote: 'فلترة تلقائية ذكية · استبعاد أقل من 30 ثانية · حفظ محلي آمن',
    searchPlaceholder: 'ابحث باسم الأغنية أو الفنان أو الألبوم...',
    tabAllSongs: 'كل الأغاني',
    tabPlaylists: 'قوائم التشغيل',
    tabFavorites: 'المفضلة',
    tabQuarantine: 'المستبعدات',
    createPlaylist: 'قائمة تشغيل جديدة',
    playlistNamePlaceholder: 'اكتب اسم قائمة التشغيل...',
    createAction: 'إنشاء',
    savePlaylist: 'حفظ القائمة',
    addSongsAction: 'إضافة أغاني',
    playlistBuilderHint: 'اضغط على علامة (+) بجانب أي أغنية لإضافتها إلى القائمة بالترتيب',
    noPlaylistsTitle: 'لا توجد قوائم تشغيل بعد',
    noPlaylistsDesc: 'أنشئ قائمة تشغيل جديدة وأضف إليها أغانيك المفضلة في أي وقت.',
    addToPlaylist: 'إضافة إلى قائمة تشغيل',
    removeFromPlaylist: 'إزالة من القائمة',
    deletePlaylist: 'حذف القائمة',
    playlistSettingsTitle: 'إعدادات قائمة التشغيل',
    playlistSettingsDesc: 'تعديل الاسم، تغيير ترتيب الأغاني، أو حذف أغاني معينة',
    playlistReorderSection: 'ترتيب وحذف الأغاني داخل القائمة',
    moveTrackUp: 'تحريك للأعلى',
    moveTrackDown: 'تحريك للأسفل',
    reversePlaylistOrder: 'عكس الترتيب',
    sortPlaylistAlpha: 'ترتيب أبجدي',
    deletePlaylistDangerTitle: 'حذف قائمة التشغيل نهائياً',
    deletePlaylistConfirmQuestion: 'هل أنت متأكد من حذف قائمة التشغيل هذه؟',
    deletePlaylistTypeHint: 'للتأكيد ومنع الحذف بالخطأ، اكتب كلمة «مسح» في الخانة التالية:',
    deletePlaylistWord: 'مسح',
    deletePlaylistFinalBtn: 'تأكيد حذف القائمة',
    saveChanges: 'حفظ التعديلات',
    playAll: 'تشغيل الكل',
    backToPlaylists: 'كل قوائم التشغيل',
    emptyPlaylistDesc: 'هذه القائمة فارغة حالياً. اضغط على (⋯) بجانب أي أغنية لإضافتها هنا.',
    toastPlaylistCreated: 'تم إنشاء قائمة "{name}"',
    toastAddedToPlaylist: 'تمت الإضافة إلى "{name}"',
    toastRemovedFromPlaylist: 'تمت الإزالة من القائمة',
    sortTitle: 'الاسم',
    sortArtist: 'الفنان',
    sortDuration: 'المدة',
    sortRecent: 'الأحدث',
    songsCount: 'أغنية',
    filteredCount: 'مستبعد تلقائياً',
    unknownArtist: 'فنان غير معروف',
    unknownAlbum: 'ألبوم غير محدد',
    scanningTitle: 'جاري فحص وفلترة الملفات الصوتية...',
    scanningSummary: 'مقبولة: {ok} · تسجيلات مستبعدة: {rec} · مقاطع قصيرة: {short}',
    scanDoneToast: 'تمت إضافة {ok} أغنية واستبعاد {filtered} ملفاً تلقائياً',
    noSearchResults: 'لا توجد أغاني مطابقة لبحثك',
    noFavoritesTitle: 'لا توجد أغاني في المفضلة بعد',
    noFavoritesDesc: 'اضغط على أيقونة القلب بجانب أي أغنية لإضافتها هنا.',
    noQuarantineTitle: 'سجل المستبعدات فارغ',
    noQuarantineDesc: 'أي تسجيلات صوتية أو مقاطع قصيرة يتم استبعادها ستظهر هنا لإمكانية استعادتها.',
    foldersEmptyTitle: 'لا توجد مجلدات مستوردة',
    foldersEmptyDesc: 'قم باستيراد مجلد من جهازك لعرض الأغاني مصنفة حسب المسار.',
    allFolders: 'كل المجلدات',
    reasonRecording: 'تسجيل صوتي / مكالمة',
    reasonShortClip: 'مقطع قصير',
    restoreTrack: 'استعادة للمكتبة',
    excludeTrack: 'نقل للمستبعدات',
    nowPlaying: 'يعمل الآن',
    lyricsTab: 'الكلمات',
    queueTab: 'قائمة الانتظار',
    artworkTab: 'الغلاف',
    fetchingLyrics: 'جاري البحث عن الكلمات المتزامنة أونلاين...',
    noLyricsFound: 'لم يتم العثور على كلمات متزامنة تلقائياً',
    noLyricsHint: 'يمكنك البحث يدوياً باسم الأغنية أو إرفاق ملف .lrc من جهازك.',
    searchLyricsOnline: 'بحث يدوي في LRCLIB',
    uploadLrcFile: 'إرفاق ملف LRC',
    syncedBadge: 'متزامنة مع التشغيل',
    plainLyricsNote: 'كلمات نصية بدون توقيت زمني',
    lyricOffset: 'ضبط التوقيت',
    tapLineToSeek: 'اضغط على أي سطر للانتقال إلى توقيته',
    manualSearchTitle: 'البحث عن كلمات متزامنة',
    manualSearchPlaceholder: 'اكتب اسم الأغنية أو الفنان (يفضل بالإنجليزية أو الاسم الأصلي)...',
    manualSearchAction: 'بحث',
    searchResultsEmpty: 'لم يتم العثور على نتائج مطابقة',
    applyLyrics: 'اعتماد الكلمات',
    crossfadeActive: 'تداخل صوتي نشط',
    playNext: 'تشغيل تالياً',
    addToQueue: 'إضافة لقائمة الانتظار',
    addToFavorites: 'إضافة للمفضلة',
    removeFromFavorites: 'إزالة من المفضلة',
    viewLyrics: 'عرض كلمات الأغنية',
    trackDetails: 'تفاصيل الملف الصوتي',
    deleteFromLibrary: 'حذف من المشغل',
    fileFormat: 'الصيغة',
    fileSize: 'الحجم',
    fileDuration: 'المدة',
    folderLocation: 'المجلد',
    fileNameLabel: 'اسم الملف',
    close: 'إغلاق',
    cancel: 'إلغاء',
    upNext: 'قائمة التشغيل التالية',
    queueEmpty: 'لا توجد أغاني تالية في القائمة',
    clearQueue: 'تفريغ القائمة',
    settingsTitle: 'إعدادات المشغل',
    settingsSubtitle: 'تخصيص التداخل الصوتي، الفلترة التلقائية، واللغة',
    languageSection: 'اللغة والواجهة',
    languageLabel: 'لغة التطبيق',
    languageDesc: 'تبديل فوري بين العربية والإنجليزية مع ثبات التخطيط',
    crossfadeSection: 'التداخل الصوتي (Crossfade)',
    crossfadeToggle: 'تفعيل الكروس فيد بين الأغاني',
    crossfadeDesc: 'مزج نهاية الأغنية الحالية مع بداية الأغنية التالية بسلاسة بدون انقطاع',
    crossfadeDuration: 'مدة التداخل',
    secondsUnit: 'ثانية',
    filterSection: 'الفلترة التلقائية الذكية',
    autoExcludeRecordings: 'استبعاد التسجيلات الصوتية والمكالمات',
    autoExcludeRecordingsDesc: 'يتجاهل تسجيلات الريكورد وملاحظات واتساب وتليجرام تلقائياً أثناء الفحص',
    minDurationLabel: 'استبعاد المقاطع الصوتية القصيرة',
    minDurationDesc: 'يستبعد أي ملف صوتي تقل مدته عن الحد المختار لإبقاء المكتبة نقية',
    customKeywordsLabel: 'كلمات استبعاد إضافية (أسماء ملفات أو مجلدات)',
    customKeywordsPlaceholder: 'مثال: Ringtone أو Voice...',
    addKeyword: 'إضافة',
    appearanceSection: 'المظهر السوبر أموليد',
    dynamicAccentLabel: 'تكيف اللون مع غلاف الأغنية',
    dynamicAccentDesc: 'تعديل إضاءة المشغل والوهج الخلفي تلقائياً حسب ألوان الألبوم',
    artworkBgLabel: 'خلفية صورة الأغنية الضبابية',
    artworkBgDesc: 'اختر كيف تظهر صورة غلاف الأغنية بتأثير Blur خلف شاشات البرنامج والمشغل',
    artworkBgFull: 'البرنامج كله',
    artworkBgPartial: 'جزء علوي',
    artworkBgOff: 'لا تظهر',
    storageSection: 'إدارة المكتبة المحلية',
    rescanFilters: 'إعادة تطبيق الفلترة الآن',
    clearLibrary: 'مسح جميع الأغاني المخزنة',
    clearLibraryConfirm: 'هل تريد حذف جميع الأغاني والبيانات المخزنة محلياً؟',
    confirmDelete: 'تأكيد المسح',
    libraryStats: '{songs} أغنية نشطة · {excluded} ملف مستبعد',
    toastPlayNext: 'سيتم تشغيلها تالياً',
    toastAddedQueue: 'تمت الإضافة لقائمة الانتظار',
    toastRestored: 'تمت استعادة الأغنية إلى المكتبة',
    toastExcluded: 'تم نقل الملف إلى قائمة المستبعدات',
    toastCrossfadeOn: 'تم تفعيل الكروس فيد ({sec} ثانية)',
    toastCrossfadeOff: 'تم إيقاف الكروس فيد',
    toastLyricsApplied: 'تم تطبيق الكلمات المتزامنة بنجاح',
    toastLibraryCleared: 'تم مسح المكتبة المحلية',
    desktopStageIdleTitle: 'اختر أغنية لبدء الاستماع',
    desktopStageIdleDesc: 'ستظهر هنا تفاصيل الغلاف والكلمات المتزامنة أونلاين أثناء التشغيل.',
    openMiniPlayerHint: 'فتح المشغل الكامل',
    stopAndClose: 'إيقاف وإخفاء الشريط',
  },
  en: {
    appName: 'NOCTURNE',
    appSubtitle: 'Local Audio Player',
    navLibrary: 'Library',
    navFolders: 'Folders',
    navSettings: 'Settings',
    importFolder: 'Select Music Folder',
    importFiles: 'Select Audio Files',
    importMore: 'Import from Device',
    emptyTitle: 'Your Local Library Is Ready',
    emptyDescription:
      'Pick a music folder or audio files from your device. Voice recordings and short audio clips are filtered out automatically.',
    emptyFilterNote: 'Smart auto-filter · Excludes clips under 30s · Local IndexedDB storage',
    searchPlaceholder: 'Search tracks, artists, or albums...',
    tabAllSongs: 'All Songs',
    tabPlaylists: 'Playlists',
    tabFavorites: 'Favorites',
    tabQuarantine: 'Excluded',
    createPlaylist: 'New Playlist',
    playlistNamePlaceholder: 'Enter playlist name...',
    createAction: 'Create',
    savePlaylist: 'Save Playlist',
    addSongsAction: 'Add Songs',
    playlistBuilderHint: 'Tap (+) next to any loaded song to add it to your playlist in order',
    noPlaylistsTitle: 'No playlists yet',
    noPlaylistsDesc: 'Create a custom playlist and add your favorite songs anytime.',
    addToPlaylist: 'Add to Playlist',
    removeFromPlaylist: 'Remove from Playlist',
    deletePlaylist: 'Delete Playlist',
    playlistSettingsTitle: 'Playlist Settings',
    playlistSettingsDesc: 'Rename playlist, reorder tracks, or remove specific songs',
    playlistReorderSection: 'Reorder & Remove Tracks',
    moveTrackUp: 'Move Up',
    moveTrackDown: 'Move Down',
    reversePlaylistOrder: 'Reverse Order',
    sortPlaylistAlpha: 'Sort A–Z',
    deletePlaylistDangerTitle: 'Delete Playlist Permanently',
    deletePlaylistConfirmQuestion: 'Are you sure you want to delete this playlist?',
    deletePlaylistTypeHint: 'To confirm and prevent accidental deletion, type "مسح" below:',
    deletePlaylistWord: 'مسح',
    deletePlaylistFinalBtn: 'Confirm Delete Playlist',
    saveChanges: 'Save Changes',
    playAll: 'Play All',
    backToPlaylists: 'All Playlists',
    emptyPlaylistDesc: 'This playlist is empty. Tap (⋯) next to any song to add it here.',
    toastPlaylistCreated: 'Created playlist "{name}"',
    toastAddedToPlaylist: 'Added to "{name}"',
    toastRemovedFromPlaylist: 'Removed from playlist',
    sortTitle: 'Title',
    sortArtist: 'Artist',
    sortDuration: 'Duration',
    sortRecent: 'Recent',
    songsCount: 'songs',
    filteredCount: 'auto-excluded',
    unknownArtist: 'Unknown Artist',
    unknownAlbum: 'Unknown Album',
    scanningTitle: 'Scanning and filtering audio files...',
    scanningSummary: 'Imported: {ok} · Recordings: {rec} · Short clips: {short}',
    scanDoneToast: 'Imported {ok} songs and auto-filtered {filtered} files',
    noSearchResults: 'No tracks match your search',
    noFavoritesTitle: 'No favorite songs yet',
    noFavoritesDesc: 'Tap the heart icon next to any song to save it here.',
    noQuarantineTitle: 'Excluded list is empty',
    noQuarantineDesc: 'Auto-excluded voice recordings and short clips appear here so you can restore them anytime.',
    foldersEmptyTitle: 'No folders imported yet',
    foldersEmptyDesc: 'Import a folder from your device to browse tracks organized by directory.',
    allFolders: 'All Folders',
    reasonRecording: 'Voice / Call Recording',
    reasonShortClip: 'Short Audio Clip',
    restoreTrack: 'Restore to Library',
    excludeTrack: 'Move to Excluded',
    nowPlaying: 'Now Playing',
    lyricsTab: 'Lyrics',
    queueTab: 'Queue',
    artworkTab: 'Artwork',
    fetchingLyrics: 'Fetching synced lyrics online...',
    noLyricsFound: 'No synced lyrics found automatically',
    noLyricsHint: 'Search LRCLIB manually by song title or attach a local .lrc file.',
    searchLyricsOnline: 'Search LRCLIB Manually',
    uploadLrcFile: 'Attach .LRC File',
    syncedBadge: 'Time-synced',
    plainLyricsNote: 'Plain lyrics (no timestamps)',
    lyricOffset: 'Sync Offset',
    tapLineToSeek: 'Tap any lyric line to jump to that moment',
    manualSearchTitle: 'Search Synced Lyrics',
    manualSearchPlaceholder: 'Enter track title or artist...',
    manualSearchAction: 'Search',
    searchResultsEmpty: 'No matching lyrics found',
    applyLyrics: 'Use These Lyrics',
    crossfadeActive: 'Crossfading',
    playNext: 'Play Next',
    addToQueue: 'Add to Queue',
    addToFavorites: 'Add to Favorites',
    removeFromFavorites: 'Remove from Favorites',
    viewLyrics: 'View Synced Lyrics',
    trackDetails: 'Audio File Details',
    deleteFromLibrary: 'Remove from Player',
    fileFormat: 'Format',
    fileSize: 'Size',
    fileDuration: 'Duration',
    folderLocation: 'Folder',
    fileNameLabel: 'File Name',
    close: 'Close',
    cancel: 'Cancel',
    upNext: 'Up Next',
    queueEmpty: 'No upcoming tracks in queue',
    clearQueue: 'Clear Queue',
    settingsTitle: 'Player Settings',
    settingsSubtitle: 'Configure crossfade, smart auto-filtering, and language',
    languageSection: 'Language & Interface',
    languageLabel: 'Interface Language',
    languageDesc: 'Switch between Arabic and English while keeping layout direction consistent',
    crossfadeSection: 'Audio Crossfade',
    crossfadeToggle: 'Enable Crossfade Between Songs',
    crossfadeDesc: 'Smoothly blend the ending of the active song into the next track',
    crossfadeDuration: 'Crossfade Duration',
    secondsUnit: 'sec',
    filterSection: 'Smart Auto-Filtering',
    autoExcludeRecordings: 'Exclude Voice & Call Recordings',
    autoExcludeRecordingsDesc: 'Automatically filters recorder memos, WhatsApp/Telegram voice notes, and calls',
    minDurationLabel: 'Exclude Short Audio Clips',
    minDurationDesc: 'Excludes audio files shorter than this threshold to keep your music library clean',
    customKeywordsLabel: 'Custom Exclusion Keywords (file or folder names)',
    customKeywordsPlaceholder: 'e.g. Ringtone or Voice...',
    addKeyword: 'Add',
    appearanceSection: 'Super AMOLED Appearance',
    dynamicAccentLabel: 'Adaptive Artwork Accent',
    dynamicAccentDesc: 'Dynamically tints the player accent and glow from the current album cover',
    artworkBgLabel: 'Blurred Song Artwork Background',
    artworkBgDesc: 'Choose how the blurred song cover appears across the app and player',
    artworkBgFull: 'Full App',
    artworkBgPartial: 'Top Partial',
    artworkBgOff: 'Hidden',
    storageSection: 'Local Library Storage',
    rescanFilters: 'Re-apply Filter Rules Now',
    clearLibrary: 'Clear All Stored Songs',
    clearLibraryConfirm: 'Remove all imported songs and cached lyrics from local storage?',
    confirmDelete: 'Confirm Clear',
    libraryStats: '{songs} active songs · {excluded} filtered items',
    toastPlayNext: 'Queued to play next',
    toastAddedQueue: 'Added to queue',
    toastRestored: 'Track restored to library',
    toastExcluded: 'Moved to excluded items',
    toastCrossfadeOn: 'Crossfade enabled ({sec}s)',
    toastCrossfadeOff: 'Crossfade disabled',
    toastLyricsApplied: 'Synced lyrics applied',
    toastLibraryCleared: 'Local library cleared',
    desktopStageIdleTitle: 'Select a Track to Listen',
    desktopStageIdleDesc: 'Album artwork, controls, and live online synced lyrics will appear here.',
    openMiniPlayerHint: 'Expand player',
    stopAndClose: 'Stop and hide bar',
  },
};
