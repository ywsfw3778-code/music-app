import type { Track } from '../types/music';
import { nativeApkBridge } from '../utils/nativeApkBridge';

export interface EngineCallbacks {
  onTimeUpdate: (currentTime: number, duration: number) => void;
  onTrackEnded: () => void;
  onCrossfadeStart: (nextTrack: Track) => void;
  onCrossfadeStateChange: (isCrossfading: boolean) => void;
  onPlayStateChange: (isPlaying: boolean) => void;
}

interface Deck {
  audio: HTMLAudioElement;
  objectUrl: string | null;
  trackId: string | null;
}

/**
 * Dual-Deck Native HTMLAudioElement Engine with Realme 11 APK (MediaSessionCompat + MediaStyle)
 * and W3C MediaSession Compliance.
 */
export class AudioCrossfadeEngine {
  private deckA: Deck;
  private deckB: Deck;
  private activeDeck: 'A' | 'B' = 'A';
  private isCrossfading = false;
  private crossfadePreTriggered = false;
  private crossfadeTimer: number | null = null;
  private crossfadeRafId: number | null = null;
  private rafId: number | null = null;
  private crossfadeEnabled = true;
  private crossfadeSeconds = 4;
  private callbacks: EngineCallbacks;
  private nextTrackResolver: (() => Track | null) | null = null;
  private playRequestId = 0;
  private lastSwitchTimestamp = 0;
  private lastPositionReportSec = -1;
  private artworkDataUrlCache = new Map<string, string>();

  constructor(callbacks: EngineCallbacks) {
    this.callbacks = callbacks;
    this.deckA = this.createDeck();
    this.deckB = this.createDeck();
    this.bindDeckEvents(this.deckA, 'A');
    this.bindDeckEvents(this.deckB, 'B');
  }

  private createDeck(): Deck {
    const audio = new Audio();
    audio.preload = 'auto';
    audio.crossOrigin = 'anonymous';
    audio.setAttribute('playsinline', 'true');
    audio.setAttribute('webkit-playsinline', 'true');
    return {
      audio,
      objectUrl: null,
      trackId: null,
    };
  }

  private bindDeckEvents(deck: Deck, id: 'A' | 'B') {
    deck.audio.addEventListener('ended', () => {
      if (this.activeDeck === id && !this.isCrossfading) {
        this.callbacks.onTrackEnded();
      }
    });

    deck.audio.addEventListener('play', () => {
      if (this.activeDeck === id) {
        const cur = deck.audio.currentTime || 0;
        const dur = deck.audio.duration || 0;
        this.callbacks.onPlayStateChange(true);
        this.syncMediaSessionPlaybackState('playing');
        this.syncMediaSessionPosition(cur, dur);
        nativeApkBridge.publishPositionAndState(true, cur, dur);
        this.startTickLoop();
      }
    });

    deck.audio.addEventListener('pause', () => {
      if (this.activeDeck === id && !this.isCrossfading) {
        const cur = deck.audio.currentTime || 0;
        const dur = deck.audio.duration || 0;
        this.callbacks.onPlayStateChange(false);
        this.syncMediaSessionPlaybackState('paused');
        this.syncMediaSessionPosition(cur, dur);
        nativeApkBridge.publishPositionAndState(false, cur, dur);
      }
    });

    deck.audio.addEventListener('loadedmetadata', () => {
      if (this.activeDeck === id) {
        const cur = deck.audio.currentTime || 0;
        const dur = deck.audio.duration || 0;
        this.syncMediaSessionPosition(cur, dur);
        nativeApkBridge.publishPositionAndState(!deck.audio.paused, cur, dur);
      }
    });
  }

  public setNextTrackResolver(resolver: () => Track | null) {
    this.nextTrackResolver = resolver;
  }

  public configureCrossfade(enabled: boolean, seconds: number) {
    this.crossfadeEnabled = enabled;
    this.crossfadeSeconds = Math.max(1, Math.min(12, seconds));
  }

  private getDeck(id: 'A' | 'B'): Deck {
    return id === 'A' ? this.deckA : this.deckB;
  }

  private getInactiveDeckId(): 'A' | 'B' {
    return this.activeDeck === 'A' ? 'B' : 'A';
  }

  private safeReleaseDeckUrl(deck: Deck) {
    if (deck.objectUrl) {
      const oldUrl = deck.objectUrl;
      deck.objectUrl = null;
      window.setTimeout(() => {
        try {
          URL.revokeObjectURL(oldUrl);
        } catch {
          // Ignore revoke error
        }
      }, 300);
    }
  }

  private clearCrossfadeTimer() {
    if (this.crossfadeTimer !== null) {
      window.clearTimeout(this.crossfadeTimer);
      this.crossfadeTimer = null;
    }
    if (this.crossfadeRafId !== null) {
      window.cancelAnimationFrame(this.crossfadeRafId);
      this.crossfadeRafId = null;
    }
  }

  private silenceAndResetDeck(deck: Deck) {
    try {
      deck.audio.pause();
      deck.audio.currentTime = 0;
    } catch {
      // Ignore pause errors
    }
    try {
      deck.audio.volume = 0;
    } catch {
      // Ignore volume errors
    }
  }

  private loadDeckBlob(deck: Deck, track: Track) {
    try {
      deck.audio.pause();
    } catch {
      // Ignore
    }
    this.safeReleaseDeckUrl(deck);
    const url = URL.createObjectURL(track.audioBlob);
    deck.objectUrl = url;
    deck.trackId = track.id;
    deck.audio.src = url;
    deck.audio.load();
  }

  public async playTrack(track: Track, useCrossfade = false) {
    this.clearCrossfadeTimer();

    const nowMs = performance.now();
    const isRapidSwitch = nowMs - this.lastSwitchTimestamp < 850;
    this.lastSwitchTimestamp = nowMs;

    const currentDeck = this.getDeck(this.activeDeck);
    const canCrossfade =
      useCrossfade &&
      !isRapidSwitch &&
      !this.isCrossfading &&
      this.crossfadeEnabled &&
      currentDeck.trackId !== null &&
      !currentDeck.audio.paused &&
      currentDeck.trackId !== track.id &&
      track.duration > this.crossfadeSeconds + 1;

    if (canCrossfade) {
      await this.performCrossfadeTo(track, Math.min(this.crossfadeSeconds, 2.2), false);
      return;
    }

    const reqId = ++this.playRequestId;
    this.isCrossfading = false;
    this.crossfadePreTriggered = false;
    this.callbacks.onCrossfadeStateChange(false);

    const inactiveDeck = this.getDeck(this.getInactiveDeckId());
    this.silenceAndResetDeck(inactiveDeck);

    this.loadDeckBlob(currentDeck, track);
    try {
      currentDeck.audio.volume = 1;
    } catch {
      // Ignore
    }

    void this.updateMediaSession(track, true);
    this.callbacks.onTimeUpdate(0, track.duration || 0);

    try {
      await currentDeck.audio.play();
      if (reqId !== this.playRequestId) return;
      this.callbacks.onPlayStateChange(true);
      this.syncMediaSessionPlaybackState('playing');
      this.syncMediaSessionPosition(0, track.duration || currentDeck.audio.duration || 0);
      this.startTickLoop();
    } catch {
      if (reqId !== this.playRequestId) return;
      this.callbacks.onPlayStateChange(false);
      this.syncMediaSessionPlaybackState('paused');
    }
  }

  private async performCrossfadeTo(
    nextTrack: Track,
    fadeDurationSec: number,
    notifyAutoAdvance = true
  ) {
    this.clearCrossfadeTimer();
    const reqId = ++this.playRequestId;

    const fromId = this.activeDeck;
    const toId = this.getInactiveDeckId();
    const fromDeck = this.getDeck(fromId);
    const toDeck = this.getDeck(toId);

    this.isCrossfading = true;
    this.crossfadePreTriggered = true;
    this.callbacks.onCrossfadeStateChange(true);

    this.loadDeckBlob(toDeck, nextTrack);
    const startVol = Math.max(0.05, Math.min(1, fromDeck.audio.volume || 1));
    try {
      toDeck.audio.volume = 0.01;
    } catch {
      // Ignore
    }

    this.activeDeck = toId;
    if (notifyAutoAdvance) {
      this.callbacks.onCrossfadeStart(nextTrack);
    }
    void this.updateMediaSession(nextTrack, true);
    this.callbacks.onTimeUpdate(0, nextTrack.duration || 0);

    try {
      await toDeck.audio.play();
      if (reqId !== this.playRequestId) return;
      this.callbacks.onPlayStateChange(true);
      this.syncMediaSessionPlaybackState('playing');
      this.syncMediaSessionPosition(0, nextTrack.duration || toDeck.audio.duration || 0);
      this.startTickLoop();
    } catch {
      if (reqId !== this.playRequestId) return;
      this.callbacks.onPlayStateChange(false);
    }

    const durMs = Math.max(400, fadeDurationSec * 1000);
    const startTime = performance.now();

    const stepFade = (now: number) => {
      if (reqId !== this.playRequestId) return;
      const progress = Math.min(1, (now - startTime) / durMs);
      const fadeOut = Math.max(0, startVol * (1 - progress));
      const fadeIn = Math.min(1, progress);
      try {
        fromDeck.audio.volume = fadeOut;
        toDeck.audio.volume = fadeIn;
      } catch {
        // Ignore on devices with fixed volume
      }
      if (progress < 1) {
        this.crossfadeRafId = window.requestAnimationFrame(stepFade);
      } else {
        this.crossfadeRafId = null;
        this.silenceAndResetDeck(fromDeck);
        try {
          toDeck.audio.volume = 1;
        } catch {
          // Ignore
        }
        this.isCrossfading = false;
        this.crossfadePreTriggered = false;
        this.callbacks.onCrossfadeStateChange(false);
      }
    };

    this.crossfadeRafId = window.requestAnimationFrame(stepFade);
  }

  public async togglePlayPause() {
    const deck = this.getDeck(this.activeDeck);
    if (!deck.trackId) return;

    if (deck.audio.paused) {
      try {
        deck.audio.volume = 1;
        await deck.audio.play();
        const cur = deck.audio.currentTime || 0;
        const dur = deck.audio.duration || 0;
        this.callbacks.onPlayStateChange(true);
        this.syncMediaSessionPlaybackState('playing');
        this.syncMediaSessionPosition(cur, dur);
        nativeApkBridge.publishPositionAndState(true, cur, dur);
        this.startTickLoop();
      } catch {
        this.callbacks.onPlayStateChange(false);
      }
    } else {
      deck.audio.pause();
      if (this.isCrossfading) {
        this.clearCrossfadeTimer();
        const otherDeck = this.getDeck(this.getInactiveDeckId());
        this.silenceAndResetDeck(otherDeck);
        this.isCrossfading = false;
        this.callbacks.onCrossfadeStateChange(false);
      }
      const cur = deck.audio.currentTime || 0;
      const dur = deck.audio.duration || 0;
      this.callbacks.onPlayStateChange(false);
      this.syncMediaSessionPlaybackState('paused');
      this.syncMediaSessionPosition(cur, dur);
      nativeApkBridge.publishPositionAndState(false, cur, dur);
    }
  }

  public seek(seconds: number) {
    const deck = this.getDeck(this.activeDeck);
    if (!deck.trackId) return;
    const maxDur = Number.isFinite(deck.audio.duration) ? deck.audio.duration : seconds;
    const clamped = Math.max(0, Math.min(maxDur, seconds));
    deck.audio.currentTime = clamped;
    this.crossfadePreTriggered = false;
    const dur = deck.audio.duration || maxDur || 0;
    this.callbacks.onTimeUpdate(clamped, dur);
    this.syncMediaSessionPosition(clamped, dur);
    nativeApkBridge.publishPositionAndState(!deck.audio.paused, clamped, dur);
  }

  public stopAll() {
    this.playRequestId++;
    this.clearCrossfadeTimer();
    this.stopTickLoop();
    for (const deck of [this.deckA, this.deckB]) {
      this.silenceAndResetDeck(deck);
      deck.trackId = null;
      this.safeReleaseDeckUrl(deck);
    }
    this.isCrossfading = false;
    this.crossfadePreTriggered = false;
    this.callbacks.onCrossfadeStateChange(false);
    this.callbacks.onPlayStateChange(false);
    this.callbacks.onTimeUpdate(0, 0);
    this.syncMediaSessionPlaybackState('none');
    nativeApkBridge.stopNativeSession();
  }

  private startTickLoop() {
    if (this.rafId !== null) return;
    const tick = () => {
      const deck = this.getDeck(this.activeDeck);
      const current = deck.audio.currentTime || 0;
      const duration = Number.isFinite(deck.audio.duration) ? deck.audio.duration : 0;

      this.callbacks.onTimeUpdate(current, duration);

      // Update Android MediaSession & Native APK Bridge once per second so Realme Mini Capsule progress stays synced
      const wholeSec = Math.floor(current);
      if (wholeSec !== this.lastPositionReportSec && duration > 0) {
        this.lastPositionReportSec = wholeSec;
        this.syncMediaSessionPosition(current, duration);
        nativeApkBridge.publishPositionAndState(!deck.audio.paused, current, duration);
      }

      // Automatic pre-trigger crossfade before track ends
      if (
        this.crossfadeEnabled &&
        !this.isCrossfading &&
        !this.crossfadePreTriggered &&
        !deck.audio.paused &&
        duration > this.crossfadeSeconds + 2
      ) {
        const remaining = duration - current;
        if (remaining > 0.15 && remaining <= this.crossfadeSeconds) {
          const upcoming = this.nextTrackResolver?.();
          if (upcoming && upcoming.id !== deck.trackId) {
            this.crossfadePreTriggered = true;
            void this.performCrossfadeTo(
              upcoming,
              Math.min(this.crossfadeSeconds, remaining),
              true
            );
          }
        }
      }

      if (!deck.audio.paused || this.isCrossfading) {
        this.rafId = window.requestAnimationFrame(tick);
      } else {
        this.rafId = null;
      }
    };

    this.rafId = window.requestAnimationFrame(tick);
  }

  private stopTickLoop() {
    if (this.rafId !== null) {
      window.cancelAnimationFrame(this.rafId);
      this.rafId = null;
    }
  }

  private syncMediaSessionPlaybackState(state: MediaSessionPlaybackState) {
    if (!('mediaSession' in navigator)) return;
    try {
      navigator.mediaSession.playbackState = state;
    } catch {
      // Ignore
    }
  }

  private syncMediaSessionPosition(position: number, duration: number) {
    if (!('mediaSession' in navigator) || typeof navigator.mediaSession.setPositionState !== 'function') {
      return;
    }
    if (!Number.isFinite(duration) || duration <= 0) return;
    try {
      navigator.mediaSession.setPositionState({
        duration: Math.max(duration, 5),
        playbackRate: 1,
        position: Math.max(0, Math.min(duration, position)),
      });
    } catch {
      // Ignore invalid position state
    }
  }

  /**
   * Generates a 512x512 square Data URL bitmap for Android SystemUI & Realme 11 Mini Capsule APK.
   */
  private async resolveSquareArtworkDataUrl(track: Track): Promise<string> {
    const cached = this.artworkDataUrlCache.get(track.id);
    if (cached) return cached;

    const size = 512;
    const canvas = document.createElement('canvas');
    canvas.width = size;
    canvas.height = size;
    const ctx = canvas.getContext('2d');
    if (!ctx) return '/pwa-512x512.png';

    const drawFallbackVinyl = () => {
      const accent = track.accentColor || '#F5F5F5';
      const grad = ctx.createRadialGradient(size / 2, size / 2, 24, size / 2, size / 2, size / 2);
      grad.addColorStop(0, '#1f1f24');
      grad.addColorStop(0.65, '#0c0c0f');
      grad.addColorStop(1, '#000000');
      ctx.fillStyle = grad;
      ctx.fillRect(0, 0, size, size);

      ctx.strokeStyle = 'rgba(255,255,255,0.08)';
      ctx.lineWidth = 3;
      for (const r of [190, 155, 120]) {
        ctx.beginPath();
        ctx.arc(size / 2, size / 2, r, 0, Math.PI * 2);
        ctx.stroke();
      }

      ctx.beginPath();
      ctx.arc(size / 2, size / 2, 72, 0, Math.PI * 2);
      ctx.fillStyle = accent;
      ctx.fill();

      ctx.beginPath();
      ctx.arc(size / 2, size / 2, 18, 0, Math.PI * 2);
      ctx.fillStyle = '#000000';
      ctx.fill();
    };

    if (track.coverUrl) {
      try {
        const img = new Image();
        img.crossOrigin = 'anonymous';
        await new Promise<void>((resolve, reject) => {
          img.onload = () => resolve();
          img.onerror = () => reject(new Error('Image load failed'));
          img.src = track.coverUrl!;
        });
        const minSide = Math.min(img.naturalWidth || size, img.naturalHeight || size);
        const sx = ((img.naturalWidth || size) - minSide) / 2;
        const sy = ((img.naturalHeight || size) - minSide) / 2;
        ctx.drawImage(img, sx, sy, minSide, minSide, 0, 0, size, size);
      } catch {
        drawFallbackVinyl();
      }
    } else {
      drawFallbackVinyl();
    }

    try {
      const dataUrl = canvas.toDataURL('image/jpeg', 0.88);
      if (this.artworkDataUrlCache.size > 40) {
        const firstKey = this.artworkDataUrlCache.keys().next().value;
        if (firstKey) this.artworkDataUrlCache.delete(firstKey);
      }
      this.artworkDataUrlCache.set(track.id, dataUrl);
      return dataUrl;
    } catch {
      return '/pwa-512x512.png';
    }
  }

  private async updateMediaSession(track: Track, isPlayingNow: boolean) {
    try {
      const squareDataUrl = await this.resolveSquareArtworkDataUrl(track);
      const activeDeck = this.getDeck(this.activeDeck);
      if (activeDeck.trackId !== track.id) return;

      // 1. Dispatch to Native Android APK Bridge (AndroidMediaBridge / Capacitor / Cordova)
      nativeApkBridge.publishMetadataAndState({
        trackId: track.id,
        title: track.title || track.fileName,
        artist: track.artist || 'سُكون',
        album: track.album || 'سُكون — NOCTURNE',
        durationMs: Math.round(Math.max(5, track.duration || 0) * 1000),
        positionMs: Math.round((activeDeck.audio.currentTime || 0) * 1000),
        isPlaying: isPlayingNow,
        artworkBase64: squareDataUrl,
        accentColor: track.accentColor || '#F5F5F5',
      });

      // 2. Dispatch to W3C MediaSession API
      if ('mediaSession' in navigator) {
        navigator.mediaSession.metadata = new MediaMetadata({
          title: track.title || track.fileName,
          artist: track.artist || 'سُكون',
          album: track.album || 'سُكون — NOCTURNE',
          artwork: [
            { src: squareDataUrl, sizes: '96x96', type: 'image/jpeg' },
            { src: squareDataUrl, sizes: '192x192', type: 'image/jpeg' },
            { src: squareDataUrl, sizes: '256x256', type: 'image/jpeg' },
            { src: squareDataUrl, sizes: '512x512', type: 'image/jpeg' },
          ],
        });
      }
    } catch {
      // Ignore MediaSession errors
    }
  }
}
