export type Language = 'ar' | 'en';

export type LibraryTab = 'songs' | 'playlists' | 'folders' | 'favorites' | 'quarantine';

export type AppView = 'library' | 'folders' | 'settings';

export type SortOption = 'title' | 'artist' | 'duration' | 'addedAt';

export type RepeatMode = 'off' | 'all' | 'one';

export type ExclusionReason = 'recording' | 'short_duration' | null;

export interface Track {
  id: string;
  title: string;
  artist: string;
  album: string;
  duration: number; // seconds
  folderPath: string;
  fileName: string;
  mimeType: string;
  fileSize: number;
  formatLabel: string;
  coverUrl?: string;
  coverBlob?: Blob;
  accentColor: string; // luminance-safe adaptive hex
  audioBlob: Blob;
  isFavorite: boolean;
  addedAt: number;
  exclusionReason: ExclusionReason;
  matchedRule?: string;
  manuallyRestored: boolean;
}

export interface Playlist {
  id: string;
  name: string;
  trackIds: string[];
  createdAt: number;
}

export interface LyricLine {
  timeMs: number;
  text: string;
}

export interface LyricsData {
  trackId: string;
  syncedLines: LyricLine[];
  plainLyrics: string;
  offsetMs: number;
  source: 'lrclib' | 'local_lrc' | 'none';
  matchedTitle?: string;
  matchedArtist?: string;
  fetchedAt: number;
}

export type ArtworkBackgroundMode = 'full' | 'partial' | 'off';

export interface AppSettings {
  language: Language;
  crossfadeEnabled: boolean;
  crossfadeSeconds: number; // 1 to 12
  minDurationSeconds: number; // 10 to 120, default 30
  autoExcludeRecordings: boolean;
  customExcludeKeywords: string[];
  dynamicArtworkAccent: boolean;
  artworkBackgroundMode: ArtworkBackgroundMode;
}

export interface ScanProgress {
  isScanning: boolean;
  totalFiles: number;
  processedFiles: number;
  importedCount: number;
  excludedRecordings: number;
  excludedShortClips: number;
  currentFileName: string;
}
