import { AnimatePresence, motion } from 'motion/react';
import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import type { ChangeEvent } from 'react';
import { LibraryView } from './components/LibraryView';
import { LiquidGlassNav } from './components/LiquidGlassNav';
import { MiniPlayerBar } from './components/MiniPlayerBar';
import { MotionBlurDefs } from './components/MotionBlurDefs';
import { NowPlayingSheet, type NowPlayingTab } from './components/NowPlayingSheet';
import { SettingsView } from './components/SettingsView';
import { TrackContextSheet } from './components/TrackContextSheet';
import { AudioCrossfadeEngine } from './engine/AudioCrossfadeEngine';
import { TRANSLATIONS } from './i18n/translations';
import type {
  AppSettings,
  AppView,
  LyricsData,
  Playlist,
  RepeatMode,
  ScanProgress,
  Track,
} from './types/music';
import {
  extractAdaptiveAccent,
  extractAudioMetadata,
  extractPaletteFromCoverUrl,
  MONOCHROME_PALETTE,
  type TrackColorPalette,
} from './utils/audioMetadata';
import {
  clearAllStorageDB,
  deleteTrackFromDB,
  loadAllTracksFromDB,
  loadLyricsFromDB,
  loadPlaylists,
  loadSettings,
  saveLyricsToDB,
  savePlaylists,
  saveSettings,
  saveTracksToDB,
} from './utils/db';
import { fetchSyncedLyricsForTrack } from './utils/lyricsService';
import {
  evaluateTrackExclusion,
  isSupportedAudioFile,
  reevaluateTracksWithSettings,
} from './utils/smartFilter';
import { nativeApkBridge } from './utils/nativeApkBridge';

const DEFAULT_PALETTE: TrackColorPalette = MONOCHROME_PALETTE;

const IDLE_SCAN: ScanProgress = {
  isScanning: false,
  totalFiles: 0,
  processedFiles: 0,
  importedCount: 0,
  excludedRecordings: 0,
  excludedShortClips: 0,
  currentFileName: '',
};

interface CollectedFile {
  file: File;
  folderPath: string;
}

export default function App() {
  const [settings, setSettings] = useState<AppSettings>(() => loadSettings());
  const [playlists, setPlaylists] = useState<Playlist[]>(() => loadPlaylists());
  const [activeView, setActiveView] = useState<AppView>('library');
  const [tracks, setTracks] = useState<Track[]>([]);
  const [currentTrackId, setCurrentTrackId] = useState<string | null>(null);
  const [queueIds, setQueueIds] = useState<string[]>([]);
  const [playbackContextIds, setPlaybackContextIds] = useState<string[] | null>(null);
  const [isPlaying, setIsPlaying] = useState(false);
  const [currentTime, setCurrentTime] = useState(0);
  const [duration, setDuration] = useState(0);
  const [shuffle, setShuffle] = useState(false);
  const [repeatMode, setRepeatMode] = useState<RepeatMode>('all');
  const [isCrossfading, setIsCrossfading] = useState(false);
  const [isNowPlayingOpen, setIsNowPlayingOpen] = useState(false);
  const [nowPlayingTab, setNowPlayingTab] = useState<NowPlayingTab>('artwork');
  const [contextMenuTrack, setContextMenuTrack] = useState<Track | null>(null);
  const [scanProgress, setScanProgress] = useState<ScanProgress>(IDLE_SCAN);

  const [lyrics, setLyrics] = useState<LyricsData | null>(null);
  const [isLoadingLyrics, setIsLoadingLyrics] = useState(false);
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  const t = TRANSLATIONS[settings.language];
  const fileInputRef = useRef<HTMLInputElement | null>(null);
  const folderInputRef = useRef<HTMLInputElement | null>(null);
  const toastTimerRef = useRef<number | null>(null);

  const activeSongs = useMemo(
    () => tracks.filter((tr) => tr.exclusionReason === null),
    [tracks]
  );
  const excludedCount = tracks.length - activeSongs.length;

  const contextSongs = useMemo(() => {
    if (!playbackContextIds || playbackContextIds.length === 0) return activeSongs;
    const mapped = playbackContextIds
      .map((id) => activeSongs.find((tr) => tr.id === id))
      .filter((tr): tr is Track => Boolean(tr));
    return mapped.length > 0 ? mapped : activeSongs;
  }, [playbackContextIds, activeSongs]);

  const currentTrack = useMemo(
    () => tracks.find((tr) => tr.id === currentTrackId) || null,
    [tracks, currentTrackId]
  );

  const queueTracks = useMemo(() => {
    const manualQueue = queueIds
      .map((id) => tracks.find((tr) => tr.id === id))
      .filter((tr): tr is Track => Boolean(tr));

    if (!currentTrackId || contextSongs.length <= 1) return manualQueue;
    const currIdx = contextSongs.findIndex((s) => s.id === currentTrackId);
    if (currIdx === -1) return manualQueue;

    const rotatedContext = [
      ...contextSongs.slice(currIdx + 1),
      ...contextSongs.slice(0, currIdx),
    ].filter((tr) => !queueIds.includes(tr.id));

    return [...manualQueue, ...rotatedContext];
  }, [queueIds, tracks, currentTrackId, contextSongs]);

  const [livePalette, setLivePalette] = useState<TrackColorPalette>(DEFAULT_PALETTE);
  const paletteCacheRef = useRef<Map<string, TrackColorPalette>>(new Map());

  useEffect(() => {
    if (!settings.dynamicArtworkAccent || !currentTrack) {
      setLivePalette(DEFAULT_PALETTE);
      return;
    }

    if (!currentTrack.coverUrl) {
      setLivePalette(MONOCHROME_PALETTE);
      return;
    }

    const cached = paletteCacheRef.current.get(currentTrack.id);
    if (cached) {
      setLivePalette(cached);
      return;
    }

    let cancelled = false;
    void extractPaletteFromCoverUrl(
      currentTrack.coverUrl,
      currentTrack.title || currentTrack.fileName
    ).then((extracted) => {
      paletteCacheRef.current.set(currentTrack.id, extracted);
      if (!cancelled) {
        setLivePalette(extracted);
      }
    });

    return () => {
      cancelled = true;
    };
  }, [currentTrack?.id, currentTrack?.coverUrl, settings.dynamicArtworkAccent]);

  const accentColor = livePalette.accent;
  const glowColor = livePalette.glow;
  const secondaryColor = livePalette.secondary;

  // Keep layout locked to RTL permanently regardless of language selection
  useEffect(() => {
    document.documentElement.lang = settings.language;
    document.documentElement.dir = 'rtl';
    document.documentElement.style.setProperty('--accent-adaptive', accentColor);
    document.documentElement.style.setProperty('--accent-glow', glowColor);
    document.documentElement.style.setProperty('--accent-secondary', secondaryColor);
  }, [settings.language, accentColor, glowColor, secondaryColor]);

  // Hydrate tracks from IndexedDB on mount
  useEffect(() => {
    let mounted = true;
    void loadAllTracksFromDB().then((stored) => {
      if (mounted && stored.length > 0) {
        setTracks(stored);
      }
    });
    return () => {
      mounted = false;
    };
  }, []);

  const showToast = useCallback((msg: string) => {
    setToastMessage(msg);
    if (toastTimerRef.current !== null) {
      window.clearTimeout(toastTimerRef.current);
    }
    toastTimerRef.current = window.setTimeout(() => {
      setToastMessage(null);
    }, 2600);
  }, []);

  // Refs for latest state inside audio engine callbacks
  const stateRef = useRef({
    activeSongs,
    contextSongs,
    playbackContextIds,
    currentTrackId,
    queueIds,
    shuffle,
    repeatMode,
    tracks,
  });
  stateRef.current = {
    activeSongs,
    contextSongs,
    playbackContextIds,
    currentTrackId,
    queueIds,
    shuffle,
    repeatMode,
    tracks,
  };

  const resolveNextTrack = useCallback((): Track | null => {
    const {
      activeSongs: allSongs,
      contextSongs: poolSongs,
      playbackContextIds: ctxIds,
      currentTrackId: currId,
      queueIds: qIds,
      shuffle: isShuffle,
      repeatMode: repeat,
    } = stateRef.current;

    if (poolSongs.length === 0) return null;

    if (repeat === 'one' && currId) {
      return allSongs.find((s) => s.id === currId) || null;
    }

    if (qIds.length > 0) {
      const nextFromQueue = allSongs.find((s) => s.id === qIds[0]);
      if (nextFromQueue) return nextFromQueue;
    }

    if (isShuffle && poolSongs.length > 1) {
      const candidates = poolSongs.filter((s) => s.id !== currId);
      return candidates[Math.floor(Math.random() * candidates.length)] || null;
    }

    const currentIdx = poolSongs.findIndex((s) => s.id === currId);
    if (currentIdx === -1) return poolSongs[0] || null;
    if (currentIdx + 1 < poolSongs.length) return poolSongs[currentIdx + 1];

    // Always loop playlists (and when repeat is 'all') back to the first song in the pool
    if ((ctxIds && ctxIds.length > 0) || repeat !== 'off') {
      return poolSongs[0] || null;
    }
    return null;
  }, []);

  const engineRef = useRef<AudioCrossfadeEngine | null>(null);

  if (!engineRef.current) {
    engineRef.current = new AudioCrossfadeEngine({
      onTimeUpdate: (cur, dur) => {
        setCurrentTime(cur);
        if (dur > 0) setDuration(dur);
      },
      onTrackEnded: () => {
        const next = resolveNextTrack();
        if (next) {
          setQueueIds((prev) => (prev[0] === next.id ? prev.slice(1) : prev));
          setCurrentTrackId(next.id);
          void engineRef.current?.playTrack(next, false);
        } else {
          setIsPlaying(false);
        }
      },
      onCrossfadeStart: (nextTrack) => {
        setQueueIds((prev) => (prev[0] === nextTrack.id ? prev.slice(1) : prev));
        setCurrentTrackId(nextTrack.id);
      },
      onCrossfadeStateChange: (active) => {
        setIsCrossfading(active);
      },
      onPlayStateChange: (playing) => {
        setIsPlaying(playing);
      },
    });
  }

  useEffect(() => {
    engineRef.current?.setNextTrackResolver(resolveNextTrack);
  }, [resolveNextTrack]);

  useEffect(() => {
    engineRef.current?.configureCrossfade(settings.crossfadeEnabled, settings.crossfadeSeconds);
  }, [settings.crossfadeEnabled, settings.crossfadeSeconds]);

  const handlePlayTrack = useCallback(
    (track: Track, useCrossfade = true) => {
      setCurrentTrackId(track.id);
      setCurrentTime(0);
      setDuration(track.duration);
      void engineRef.current?.playTrack(track, useCrossfade);
    },
    []
  );

  const handleNext = useCallback(() => {
    const next = resolveNextTrack();
    if (!next) return;
    setQueueIds((prev) => (prev[0] === next.id ? prev.slice(1) : prev));
    handlePlayTrack(next, settings.crossfadeEnabled);
  }, [resolveNextTrack, handlePlayTrack, settings.crossfadeEnabled]);

  const handlePrev = useCallback(() => {
    if (currentTime > 3) {
      engineRef.current?.seek(0);
      return;
    }
    if (contextSongs.length === 0) return;
    const idx = contextSongs.findIndex((s) => s.id === currentTrackId);
    const prevIdx = idx <= 0 ? contextSongs.length - 1 : idx - 1;
    const prevTrack = contextSongs[prevIdx];
    if (prevTrack) {
      handlePlayTrack(prevTrack, settings.crossfadeEnabled);
    }
  }, [currentTime, contextSongs, currentTrackId, handlePlayTrack, settings.crossfadeEnabled]);

  // Bind mobile hardware / lockscreen / Realme 11 Mini Capsule MediaSession actions
  useEffect(() => {
    if (!('mediaSession' in navigator)) return;
    const bindHandler = (
      action: MediaSessionAction,
      handler: MediaSessionActionHandler | null
    ) => {
      try {
        navigator.mediaSession.setActionHandler(action, handler);
      } catch {
        // Ignore unsupported action on older browsers
      }
    };

    bindHandler('play', () => void engineRef.current?.togglePlayPause());
    bindHandler('pause', () => void engineRef.current?.togglePlayPause());
    bindHandler('nexttrack', handleNext);
    bindHandler('previoustrack', handlePrev);
    bindHandler('seekbackward', (details) => {
      const offset = details.seekOffset || 10;
      engineRef.current?.seek(Math.max(0, currentTime - offset));
    });
    bindHandler('seekforward', (details) => {
      const offset = details.seekOffset || 10;
      engineRef.current?.seek(currentTime + offset);
    });
    bindHandler('seekto', (details) => {
      if (typeof details.seekTime === 'number') {
        engineRef.current?.seek(details.seekTime);
      }
    });
    bindHandler('stop', () => {
      engineRef.current?.stopAll();
      setCurrentTrackId(null);
      setIsNowPlayingOpen(false);
    });

    // Bind Native Android APK Bridge (RealmeMediaPlaybackService / Capacitor / Cordova)
    nativeApkBridge.bindActionHandler((action, value) => {
      if (action === 'play' || action === 'pause' || action === 'toggle') {
        void engineRef.current?.togglePlayPause();
      } else if (action === 'next') {
        handleNext();
      } else if (action === 'prev') {
        handlePrev();
      } else if (action === 'seek' && typeof value === 'number') {
        engineRef.current?.seek(value);
      } else if (action === 'stop') {
        engineRef.current?.stopAll();
        setCurrentTrackId(null);
        setIsNowPlayingOpen(false);
      }
    });
  }, [handleNext, handlePrev, currentTime]);

  // Fetch / Hydrate Synced Lyrics whenever currentTrack changes
  useEffect(() => {
    if (!currentTrack) {
      setLyrics(null);
      return;
    }

    let cancelled = false;
    setIsLoadingLyrics(true);

    void (async () => {
      const cached = await loadLyricsFromDB(currentTrack.id);
      if (cancelled) return;
      if (cached && (cached.syncedLines.length > 0 || cached.plainLyrics)) {
        setLyrics(cached);
        setIsLoadingLyrics(false);
        return;
      }

      const fetched = await fetchSyncedLyricsForTrack(currentTrack);
      if (cancelled) return;
      setLyrics(fetched);
      setIsLoadingLyrics(false);
      if (fetched.source !== 'none') {
        void saveLyricsToDB(fetched);
      }
    })();

    return () => {
      cancelled = true;
    };
  }, [currentTrack?.id]);

  // Ingest collected audio files, extract tags, run Smart Filter, save to IndexedDB
  const ingestAudioFiles = useCallback(
    async (items: CollectedFile[]) => {
      const audioItems = items.filter((it) => isSupportedAudioFile(it.file));
      if (audioItems.length === 0) return;

      setScanProgress({
        isScanning: true,
        totalFiles: audioItems.length,
        processedFiles: 0,
        importedCount: 0,
        excludedRecordings: 0,
        excludedShortClips: 0,
        currentFileName: '',
      });

      const existingIds = new Set(tracks.map((tr) => tr.id));
      const newTracks: Track[] = [];
      let importedCount = 0;
      let excludedRecordings = 0;
      let excludedShortClips = 0;

      for (let i = 0; i < audioItems.length; i++) {
        const { file, folderPath } = audioItems[i];
        const id = `${file.name}__${file.size}__${folderPath}`;

        if (!existingIds.has(id)) {
          existingIds.add(id);
          const meta = await extractAudioMetadata(file, t.unknownArtist, t.unknownAlbum);
          const accent = await extractAdaptiveAccent(meta.coverBlob, meta.title || file.name);
          const filterRes = evaluateTrackExclusion(
            {
              fileName: file.name,
              folderPath,
              duration: meta.duration,
              manuallyRestored: false,
            },
            settings
          );

          if (filterRes.exclusionReason === 'recording') {
            excludedRecordings += 1;
          } else if (filterRes.exclusionReason === 'short_duration') {
            excludedShortClips += 1;
          } else {
            importedCount += 1;
          }

          const track: Track = {
            id,
            title: meta.title,
            artist: meta.artist,
            album: meta.album,
            duration: meta.duration,
            folderPath,
            fileName: file.name,
            mimeType: file.type || 'audio/mpeg',
            fileSize: file.size,
            formatLabel: meta.formatLabel,
            coverBlob: meta.coverBlob,
            coverUrl: meta.coverBlob ? URL.createObjectURL(meta.coverBlob) : undefined,
            accentColor: accent,
            audioBlob: file,
            isFavorite: false,
            addedAt: Date.now() + i,
            exclusionReason: filterRes.exclusionReason,
            matchedRule: filterRes.matchedRule,
            manuallyRestored: false,
          };
          newTracks.push(track);
        }

        setScanProgress({
          isScanning: true,
          totalFiles: audioItems.length,
          processedFiles: i + 1,
          importedCount,
          excludedRecordings,
          excludedShortClips,
          currentFileName: file.name,
        });
      }

      if (newTracks.length > 0) {
        await saveTracksToDB(newTracks);
        setTracks((prev) => [...newTracks, ...prev]);
      }

      setScanProgress(IDLE_SCAN);
      const totalFiltered = excludedRecordings + excludedShortClips;
      showToast(
        t.scanDoneToast
          .replace('{ok}', String(importedCount))
          .replace('{filtered}', String(totalFiltered))
      );
    },
    [tracks, settings, t, showToast]
  );

  // Directory picker (File System Access API + webkitdirectory fallback for mobile browsers)
  const handleImportFolder = useCallback(async () => {
    const win = window as unknown as {
      showDirectoryPicker?: () => Promise<FileSystemDirectoryHandle>;
    };

    if (typeof win.showDirectoryPicker === 'function') {
      try {
        const rootHandle = await win.showDirectoryPicker();
        const collected: CollectedFile[] = [];

        const walk = async (dirHandle: FileSystemDirectoryHandle, pathPrefix: string) => {
          const entries = (
            dirHandle as unknown as {
              values: () => AsyncIterable<FileSystemHandle>;
            }
          ).values();
          for await (const entry of entries) {
            if (entry.kind === 'file') {
              const fileHandle = entry as FileSystemFileHandle;
              const file = await fileHandle.getFile();
              collected.push({ file, folderPath: pathPrefix });
            } else if (entry.kind === 'directory') {
              await walk(
                entry as FileSystemDirectoryHandle,
                pathPrefix ? `${pathPrefix}/${entry.name}` : entry.name
              );
            }
          }
        };

        await walk(rootHandle, rootHandle.name);
        await ingestAudioFiles(collected);
        return;
      } catch (err) {
        if ((err as Error)?.name === 'AbortError') return;
        // Fallback to hidden webkitdirectory input
      }
    }

    folderInputRef.current?.click();
  }, [ingestAudioFiles]);

  const handleImportFiles = useCallback(() => {
    fileInputRef.current?.click();
  }, []);

  const handleFileInputChange = (e: ChangeEvent<HTMLInputElement>) => {
    const fileList = e.target.files;
    if (!fileList || fileList.length === 0) return;

    const collected: CollectedFile[] = Array.from(fileList).map((file) => {
      const rel = (file as File & { webkitRelativePath?: string }).webkitRelativePath || '';
      const parts = rel.split('/');
      const folderPath = parts.length > 1 ? parts.slice(0, -1).join('/') : '/';
      return { file, folderPath };
    });

    void ingestAudioFiles(collected);
    e.target.value = '';
  };

  // Update settings + live re-apply filter rules when filter thresholds change
  const handleUpdateSettings = useCallback(
    (patch: Partial<AppSettings>) => {
      setSettings((prev) => {
        const next = { ...prev, ...patch };
        saveSettings(next);

        if (
          patch.crossfadeEnabled !== undefined &&
          patch.crossfadeEnabled !== prev.crossfadeEnabled
        ) {
          showToast(
            patch.crossfadeEnabled
              ? t.toastCrossfadeOn.replace('{sec}', String(next.crossfadeSeconds))
              : t.toastCrossfadeOff
          );
        }

        if (
          patch.minDurationSeconds !== undefined ||
          patch.autoExcludeRecordings !== undefined ||
          patch.customExcludeKeywords !== undefined
        ) {
          setTracks((currTracks) => {
            const updated = reevaluateTracksWithSettings(currTracks, next);
            void saveTracksToDB(updated);
            return updated;
          });
        }

        return next;
      });
    },
    [showToast, t]
  );

  const handleReapplyFilters = useCallback(() => {
    setTracks((curr) => {
      const updated = reevaluateTracksWithSettings(curr, settings);
      void saveTracksToDB(updated);
      return updated;
    });
  }, [settings]);

  const handleClearLibrary = useCallback(async () => {
    engineRef.current?.stopAll();
    setCurrentTrackId(null);
    setQueueIds([]);
    setPlaylists([]);
    setIsNowPlayingOpen(false);
    await clearAllStorageDB();
    setTracks([]);
    showToast(t.toastLibraryCleared);
  }, [showToast, t.toastLibraryCleared]);

  const handleToggleFavorite = useCallback((trackId: string) => {
    setTracks((prev) => {
      const next = prev.map((tr) =>
        tr.id === trackId ? { ...tr, isFavorite: !tr.isFavorite } : tr
      );
      const changed = next.find((tr) => tr.id === trackId);
      if (changed) void saveTracksToDB([changed]);
      return next;
    });
  }, []);

  const handleRestoreTrack = useCallback(
    (track: Track) => {
      const restored: Track = {
        ...track,
        exclusionReason: null,
        matchedRule: undefined,
        manuallyRestored: true,
      };
      setTracks((prev) => prev.map((tr) => (tr.id === track.id ? restored : tr)));
      void saveTracksToDB([restored]);
      showToast(t.toastRestored);
    },
    [showToast, t.toastRestored]
  );

  const handleToggleExclusion = useCallback(
    (track: Track) => {
      if (track.exclusionReason) {
        handleRestoreTrack(track);
        return;
      }
      const excluded: Track = {
        ...track,
        exclusionReason: 'recording',
        matchedRule: 'Manual',
        manuallyRestored: false,
      };
      setTracks((prev) => prev.map((tr) => (tr.id === track.id ? excluded : tr)));
      void saveTracksToDB([excluded]);
      if (currentTrackId === track.id) {
        engineRef.current?.stopAll();
        setCurrentTrackId(null);
      }
      showToast(t.toastExcluded);
    },
    [handleRestoreTrack, currentTrackId, showToast, t.toastExcluded]
  );

  const handleDeleteTrack = useCallback(
    (trackId: string) => {
      if (currentTrackId === trackId) {
        engineRef.current?.stopAll();
        setCurrentTrackId(null);
        setIsNowPlayingOpen(false);
      }
      setQueueIds((prev) => prev.filter((id) => id !== trackId));
      setTracks((prev) => prev.filter((tr) => tr.id !== trackId));
      setPlaylists((prev) => {
        const next = prev.map((pl) => ({
          ...pl,
          trackIds: pl.trackIds.filter((id) => id !== trackId),
        }));
        savePlaylists(next);
        return next;
      });
      void deleteTrackFromDB(trackId);
    },
    [currentTrackId]
  );

  const handleCreatePlaylist = useCallback(
    (name: string, initialTrackIds: string[] = []): string => {
      const newPl: Playlist = {
        id: `pl_${Date.now()}_${Math.random().toString(36).slice(2, 7)}`,
        name,
        trackIds: initialTrackIds,
        createdAt: Date.now(),
      };
      setPlaylists((prev) => {
        const next = [newPl, ...prev];
        savePlaylists(next);
        return next;
      });
      showToast(t.toastPlaylistCreated.replace('{name}', name));
      return newPl.id;
    },
    [showToast, t.toastPlaylistCreated]
  );

  const handleCreatePlaylistAndAdd = useCallback(
    (name: string, trackId: string) => {
      const newPl: Playlist = {
        id: `pl_${Date.now()}_${Math.random().toString(36).slice(2, 7)}`,
        name,
        trackIds: [trackId],
        createdAt: Date.now(),
      };
      setPlaylists((prev) => {
        const next = [newPl, ...prev];
        savePlaylists(next);
        return next;
      });
      showToast(t.toastAddedToPlaylist.replace('{name}', name));
    },
    [showToast, t.toastAddedToPlaylist]
  );

  const handleToggleTrackInPlaylist = useCallback(
    (playlistId: string, trackId: string) => {
      setPlaylists((prev) => {
        const target = prev.find((p) => p.id === playlistId);
        const alreadyIn = target?.trackIds.includes(trackId) ?? false;
        const next = prev.map((pl) => {
          if (pl.id !== playlistId) return pl;
          return {
            ...pl,
            trackIds: alreadyIn
              ? pl.trackIds.filter((id) => id !== trackId)
              : [...pl.trackIds, trackId],
          };
        });
        savePlaylists(next);
        if (target) {
          showToast(
            alreadyIn
              ? t.toastRemovedFromPlaylist
              : t.toastAddedToPlaylist.replace('{name}', target.name)
          );
        }
        return next;
      });
    },
    [showToast, t.toastAddedToPlaylist, t.toastRemovedFromPlaylist]
  );

  const handleRemoveTrackFromPlaylist = useCallback(
    (playlistId: string, trackId: string) => {
      setPlaylists((prev) => {
        const next = prev.map((pl) =>
          pl.id === playlistId
            ? { ...pl, trackIds: pl.trackIds.filter((id) => id !== trackId) }
            : pl
        );
        savePlaylists(next);
        return next;
      });
      showToast(t.toastRemovedFromPlaylist);
    },
    [showToast, t.toastRemovedFromPlaylist]
  );

  const handleUpdatePlaylist = useCallback(
    (playlistId: string, patch: { name?: string; trackIds?: string[] }) => {
      setPlaylists((prev) => {
        const next = prev.map((pl) => {
          if (pl.id !== playlistId) return pl;
          return {
            ...pl,
            ...(patch.name !== undefined ? { name: patch.name } : {}),
            ...(patch.trackIds !== undefined ? { trackIds: patch.trackIds } : {}),
          };
        });
        savePlaylists(next);
        return next;
      });
      if (patch.trackIds !== undefined) {
        setPlaybackContextIds((prevCtx) => {
          if (!prevCtx) return prevCtx;
          return patch.trackIds || prevCtx;
        });
      }
    },
    []
  );

  const handleDeletePlaylist = useCallback((playlistId: string) => {
    setPlaylists((prev) => {
      const next = prev.filter((pl) => pl.id !== playlistId);
      savePlaylists(next);
      return next;
    });
  }, []);

  const handlePlayPlaylist = useCallback(
    (playlistTracks: Track[]) => {
      if (playlistTracks.length === 0) return;
      setPlaybackContextIds(playlistTracks.map((tr) => tr.id));
      setQueueIds([]);
      handlePlayTrack(playlistTracks[0], settings.crossfadeEnabled);
    },
    [handlePlayTrack, settings.crossfadeEnabled]
  );

  const handlePlayNext = useCallback(
    (track: Track) => {
      setQueueIds((prev) => [track.id, ...prev.filter((id) => id !== track.id)]);
      showToast(t.toastPlayNext);
    },
    [showToast, t.toastPlayNext]
  );

  const handleAddToQueue = useCallback(
    (track: Track) => {
      setQueueIds((prev) => (prev.includes(track.id) ? prev : [...prev, track.id]));
      showToast(t.toastAddedQueue);
    },
    [showToast, t.toastAddedQueue]
  );

  const handleViewLyrics = useCallback(
    (track: Track) => {
      if (currentTrackId !== track.id) {
        handlePlayTrack(track, settings.crossfadeEnabled);
      }
      setNowPlayingTab('lyrics');
      setIsNowPlayingOpen(true);
    },
    [currentTrackId, handlePlayTrack, settings.crossfadeEnabled]
  );

  const handleUpdateLyrics = useCallback(
    (nextLyrics: LyricsData) => {
      setLyrics(nextLyrics);
      void saveLyricsToDB(nextLyrics);
      showToast(t.toastLyricsApplied);
    },
    [showToast, t.toastLyricsApplied]
  );

  const handleStopAndCloseMiniPlayer = useCallback(() => {
    engineRef.current?.stopAll();
    setCurrentTrackId(null);
    setIsNowPlayingOpen(false);
  }, []);

  const cycleRepeat = () => {
    setRepeatMode((prev) => (prev === 'off' ? 'all' : prev === 'all' ? 'one' : 'off'));
  };

  return (
    <div dir="rtl" className="min-h-screen bg-black text-slate-50 flex flex-col max-w-md mx-auto relative shadow-2xl">
      <MotionBlurDefs />
      {/* Hidden device file/folder inputs */}
      <input
        ref={fileInputRef}
        type="file"
        accept="audio/*,.mp3,.m4a,.flac,.wav,.ogg,.opus,.aac"
        multiple
        onChange={handleFileInputChange}
        className="hidden"
      />
      <input
        ref={folderInputRef}
        type="file"
        // @ts-expect-error webkitdirectory is supported on Chromium/Android/Safari
        webkitdirectory=""
        directory=""
        multiple
        onChange={handleFileInputChange}
        className="hidden"
      />

      {/* Center Content Area — Pitch-Black (#000000) When No Track Selected, Clear Artwork Background When Track Selected (Playing or Paused) */}
      <main className="relative flex-1 min-w-0 min-h-screen bg-[#000000] overflow-x-hidden">
        {/* Dynamic Ambient Artwork Glow + Clear Softly-Blurred Cover */}
        {currentTrack && (settings.artworkBackgroundMode || 'full') !== 'off' && (
          <div
            className={`pointer-events-none fixed lg:absolute inset-x-0 top-0 transition-opacity duration-500 z-0 ${
              (settings.artworkBackgroundMode || 'full') === 'full'
                ? 'h-full opacity-55'
                : 'h-80 opacity-45'
            }`}
            style={{
              background:
                (settings.artworkBackgroundMode || 'full') === 'full'
                  ? `
                    radial-gradient(100% 70% at 50% 15%, ${glowColor}55 0%, ${secondaryColor}28 52%, #000000 100%),
                    radial-gradient(85% 60% at 50% 90%, ${accentColor}26 0%, transparent 75%)
                  `
                  : `radial-gradient(85% 75% at 50% 0%, ${glowColor}55 0%, ${secondaryColor}22 50%, transparent 100%)`,
            }}
          />
        )}
        {currentTrack?.coverUrl && (settings.artworkBackgroundMode || 'full') !== 'off' && (
          <div
            className={`pointer-events-none fixed lg:absolute inset-x-0 top-0 overflow-hidden z-0 transition-opacity duration-500 ${
              (settings.artworkBackgroundMode || 'full') === 'full'
                ? 'h-full opacity-75'
                : 'h-80 opacity-65'
            }`}
          >
            <img
              src={currentTrack.coverUrl}
              alt=""
              aria-hidden="true"
              referrerPolicy="no-referrer"
              className="w-full h-full object-cover scale-105 transition-all duration-700"
              style={{
                filter:
                  (settings.artworkBackgroundMode || 'full') === 'full'
                    ? 'blur(9px) saturate(135%) brightness(0.72)'
                    : 'blur(7px) saturate(135%) brightness(0.78)',
                WebkitFilter:
                  (settings.artworkBackgroundMode || 'full') === 'full'
                    ? 'blur(9px) saturate(135%) brightness(0.72)'
                    : 'blur(7px) saturate(135%) brightness(0.78)',
              }}
            />
            <div
              className="absolute inset-0"
              style={{
                background:
                  (settings.artworkBackgroundMode || 'full') === 'full'
                    ? 'linear-gradient(180deg, rgba(0,0,0,0.22) 0%, rgba(0,0,0,0.38) 50%, rgba(0,0,0,0.62) 100%)'
                    : 'linear-gradient(180deg, rgba(0,0,0,0.18) 0%, rgba(0,0,0,0.55) 65%, #000000 100%)',
              }}
            />
          </div>
        )}

        <div className="relative z-10">
          {activeView === 'settings' ? (
            <motion.div
              key="view-settings"
              initial={{ opacity: 0.4, y: 12, scale: 0.99 }}
              animate={{ opacity: 1, y: 0, scale: 1 }}
              transition={{
                type: 'spring',
                stiffness: 540,
                damping: 38,
                mass: 0.55,
              }}
            >
              <SettingsView
                settings={settings}
                accentColor={accentColor}
                activeTrackCount={activeSongs.length}
                excludedCount={excludedCount}
                onUpdateSettings={handleUpdateSettings}
                onReapplyFilters={handleReapplyFilters}
                onClearLibrary={() => void handleClearLibrary()}
                t={t}
              />
            </motion.div>
          ) : (
            <LibraryView
              mode={activeView === 'folders' ? 'folders' : 'library'}
              tracks={tracks}
              playlists={playlists}
              currentTrackId={currentTrackId}
              isPlaying={isPlaying}
              scanProgress={scanProgress}
              accentColor={accentColor}
              onPlayTrack={(tr, contextTracks) => {
                if (contextTracks && contextTracks.length > 0) {
                  setPlaybackContextIds(contextTracks.map((c) => c.id));
                }
                handlePlayTrack(tr, settings.crossfadeEnabled);
              }}
              onPlayPlaylist={handlePlayPlaylist}
              onCreatePlaylist={handleCreatePlaylist}
              onUpdatePlaylist={handleUpdatePlaylist}
              onToggleTrackInPlaylist={handleToggleTrackInPlaylist}
              onDeletePlaylist={handleDeletePlaylist}
              onRemoveTrackFromPlaylist={handleRemoveTrackFromPlaylist}
              onToggleFavorite={handleToggleFavorite}
              onOpenContextMenu={setContextMenuTrack}
              onRestoreTrack={handleRestoreTrack}
              onImportFolder={() => void handleImportFolder()}
              onImportFiles={handleImportFiles}
              t={t}
            />
          )}
        </div>
      </main>

      {/* Left Sidebar (Desktop) & Floating Dock (Mobile) */}
      <LiquidGlassNav
        activeView={activeView}
        onSelectView={setActiveView}
        onTriggerImport={handleImportFiles}
        t={t}
        accentColor={accentColor}
        glowColor={glowColor}
        activeTrackCount={activeSongs.length}
        excludedCount={excludedCount}
      />

      {/* Mobile Floating Mini-Player Bar */}
      <MiniPlayerBar
        track={currentTrack}
        isPlaying={isPlaying}
        currentTime={currentTime}
        duration={duration}
        isCrossfading={isCrossfading}
        accentColor={accentColor}
        glowColor={glowColor}
        isNowPlayingOpen={isNowPlayingOpen}
        onExpand={() => {
          setNowPlayingTab('artwork');
          setIsNowPlayingOpen(true);
        }}
        onTogglePlay={() => void engineRef.current?.togglePlayPause()}
        onNext={handleNext}
        onStopAndClose={handleStopAndCloseMiniPlayer}
        t={t}
      />

      {/* Mobile Full-Screen Morphing Now Playing Sheet */}
      <NowPlayingSheet
        isOpen={isNowPlayingOpen}
        initialTab={nowPlayingTab}
        track={currentTrack}
        queueTracks={queueTracks}
        isPlaying={isPlaying}
        currentTime={currentTime}
        duration={duration}
        shuffle={shuffle}
        repeatMode={repeatMode}
        isCrossfading={isCrossfading}
        crossfadeEnabled={settings.crossfadeEnabled}
        crossfadeSeconds={settings.crossfadeSeconds}
        accentColor={accentColor}
        glowColor={glowColor}
        secondaryColor={secondaryColor}
        artworkBackgroundMode={settings.artworkBackgroundMode || 'full'}
        lyrics={lyrics}
        isLoadingLyrics={isLoadingLyrics}
        onClose={() => setIsNowPlayingOpen(false)}
        onTogglePlay={() => void engineRef.current?.togglePlayPause()}
        onNext={handleNext}
        onPrev={handlePrev}
        onSeek={(sec) => engineRef.current?.seek(sec)}
        onToggleShuffle={() => setShuffle((v) => !v)}
        onCycleRepeat={cycleRepeat}
        onToggleFavorite={handleToggleFavorite}
        onOpenContextMenu={setContextMenuTrack}
        onPlayQueueTrack={(tr) => handlePlayTrack(tr, settings.crossfadeEnabled)}
        onClearQueue={() => setQueueIds([])}
        onUpdateLyrics={handleUpdateLyrics}
        t={t}
      />

      {/* Track Context Menu Sheet */}
      <TrackContextSheet
        track={contextMenuTrack}
        playlists={playlists}
        onClose={() => setContextMenuTrack(null)}
        onPlayNext={handlePlayNext}
        onAddToQueue={handleAddToQueue}
        onToggleFavorite={handleToggleFavorite}
        onViewLyrics={handleViewLyrics}
        onToggleExclusion={handleToggleExclusion}
        onDeleteTrack={handleDeleteTrack}
        onCreatePlaylistAndAdd={handleCreatePlaylistAndAdd}
        onToggleTrackInPlaylist={handleToggleTrackInPlaylist}
        t={t}
        accentColor={accentColor}
        glowColor={glowColor}
      />

      {/* Floating Natural Matte Toast Feedback */}
      <AnimatePresence>
        {toastMessage && (
          <motion.div
            key="amoled-toast"
            initial={{ opacity: 0, y: -20, scale: 0.94 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: -16, scale: 0.94 }}
            transition={{ type: 'spring', stiffness: 520, damping: 32 }}
            className="fixed top-4 inset-x-4 z-[60] mx-auto max-w-sm pointer-events-none flex justify-center"
          >
            <div className="matte-elevated px-4 py-2.5 rounded-full text-xs font-medium text-slate-100 text-center">
              <span className="relative z-10">{toastMessage}</span>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
