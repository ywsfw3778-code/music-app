import React, { useState, useEffect, useMemo } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import {
  X,
  Settings2,
  ArrowUp,
  ArrowDown,
  Trash2,
  Plus,
  Music,
  ArrowUpDown,
  SortAsc,
  AlertTriangle,
  Check,
} from 'lucide-react';
import type { Playlist, Track } from '../types/music';
import type { Translations } from '../i18n/translations';
import { formatDuration } from '../utils/smartFilter';

interface PlaylistSettingsModalProps {
  isOpen: boolean;
  playlist: Playlist | null;
  tracks: Track[];
  accentColor: string;
  onClose: () => void;
  onUpdatePlaylist: (playlistId: string, patch: { name?: string; trackIds?: string[] }) => void;
  onDeletePlaylist: (playlistId: string) => void;
  onOpenAddSongs: (playlist: Playlist) => void;
  t: Translations;
}

const MODAL_SPRING = {
  type: 'spring' as const,
  stiffness: 400,
  damping: 32,
  mass: 0.85,
};

export const PlaylistSettingsModal: React.FC<PlaylistSettingsModalProps> = ({
  isOpen,
  playlist,
  tracks,
  accentColor,
  onClose,
  onUpdatePlaylist,
  onDeletePlaylist,
  onOpenAddSongs,
  t,
}) => {
  const [nameInput, setNameInput] = useState('');
  const [showDeleteConfirm, setShowDeleteConfirm] = useState(false);
  const [deleteConfirmText, setDeleteConfirmText] = useState('');
  const [nameSavedBadge, setNameSavedBadge] = useState(false);

  useEffect(() => {
    if (isOpen && playlist) {
      setNameInput(playlist.name);
      setShowDeleteConfirm(false);
      setDeleteConfirmText('');
      setNameSavedBadge(false);
    }
  }, [isOpen, playlist?.id]);

  // Keep nameInput synced if playlist name updates externally
  useEffect(() => {
    if (playlist) {
      setNameInput(playlist.name);
    }
  }, [playlist?.name]);

  const playlistTracks = useMemo(() => {
    if (!playlist) return [];
    const trackMap = new Map(tracks.map((tr) => [tr.id, tr]));
    return playlist.trackIds
      .map((id) => trackMap.get(id))
      .filter((tr): tr is Track => Boolean(tr));
  }, [playlist, tracks]);

  if (!playlist) return null;

  const handleSaveName = (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    const trimmed = nameInput.trim();
    if (!trimmed || trimmed === playlist.name) return;
    onUpdatePlaylist(playlist.id, { name: trimmed });
    setNameSavedBadge(true);
    window.setTimeout(() => setNameSavedBadge(false), 1800);
  };

  const handleMoveTrack = (index: number, direction: 'up' | 'down') => {
    const currentIds = playlistTracks.map((tr) => tr.id);
    const targetIndex = direction === 'up' ? index - 1 : index + 1;
    if (targetIndex < 0 || targetIndex >= currentIds.length) return;
    const nextIds = [...currentIds];
    const [moved] = nextIds.splice(index, 1);
    nextIds.splice(targetIndex, 0, moved);
    onUpdatePlaylist(playlist.id, { trackIds: nextIds });
  };

  const handleRemoveTrack = (trackId: string) => {
    const nextIds = playlist.trackIds.filter((id) => id !== trackId);
    onUpdatePlaylist(playlist.id, { trackIds: nextIds });
  };

  const handleReverseOrder = () => {
    const currentIds = playlistTracks.map((tr) => tr.id);
    if (currentIds.length < 2) return;
    onUpdatePlaylist(playlist.id, { trackIds: [...currentIds].reverse() });
  };

  const handleSortAlphabetical = () => {
    if (playlistTracks.length < 2) return;
    const sortedIds = [...playlistTracks]
      .sort((a, b) => a.title.localeCompare(b.title, ['ar', 'en']))
      .map((tr) => tr.id);
    onUpdatePlaylist(playlist.id, { trackIds: sortedIds });
  };

  const isConfirmWordValid =
    deleteConfirmText.trim() === 'مسح' ||
    deleteConfirmText.trim() === t.deletePlaylistWord ||
    deleteConfirmText.trim().toLowerCase() === 'delete';

  const handleFinalDelete = (e: React.FormEvent) => {
    e.preventDefault();
    if (!isConfirmWordValid) return;
    onDeletePlaylist(playlist.id);
    onClose();
  };

  return (
    <AnimatePresence>
      {isOpen && (
        <div
          dir="rtl"
          className="fixed inset-0 z-[115] flex items-end sm:items-center justify-center p-0 sm:p-4"
        >
          {/* Backdrop */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.2 }}
            onClick={onClose}
            className="absolute inset-0 bg-black/70"
            style={{
              backdropFilter: 'blur(4px)',
              WebkitBackdropFilter: 'blur(4px)',
            }}
          />

          {/* Modal Sheet */}
          <motion.div
            initial={{ opacity: 0, y: 40, scale: 0.96 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 32, scale: 0.96 }}
            transition={MODAL_SPRING}
            style={{
              backgroundColor: 'rgba(12, 12, 14, 0.72)',
              backdropFilter: 'blur(6px) saturate(120%)',
              WebkitBackdropFilter: 'blur(6px) saturate(120%)',
              border: 'none',
            }}
            className="relative w-full max-w-lg max-h-[88vh] flex flex-col rounded-t-[28px] sm:rounded-[28px] shadow-[0_24px_80px_rgba(0,0,0,0.85)] overflow-hidden"
          >
            {/* Header */}
            <div className="px-5 pt-5 pb-3.5 flex items-center justify-between">
              <div className="flex items-center gap-3 min-w-0">
                <div
                  className="w-10 h-10 rounded-xl flex items-center justify-center shrink-0"
                  style={{
                    backgroundColor: `${accentColor}22`,
                    color: accentColor,
                  }}
                >
                  <Settings2 className="w-5 h-5" />
                </div>
                <div className="min-w-0 text-right">
                  <h2 className="text-base font-bold text-white truncate">
                    {t.playlistSettingsTitle}
                  </h2>
                  <p className="text-xs text-white/50 truncate">
                    {t.playlistSettingsDesc}
                  </p>
                </div>
              </div>
              <button
                type="button"
                onClick={onClose}
                className="w-8 h-8 rounded-full bg-white/[0.06] hover:bg-white/[0.12] flex items-center justify-center text-white/60 hover:text-white transition-colors shrink-0"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* Scrollable Body */}
            <div className="flex-1 overflow-y-auto px-5 pb-5 space-y-4 custom-scrollbar">
              {/* Rename Playlist */}
              <form onSubmit={handleSaveName} className="space-y-1.5">
                <label className="block text-[11px] font-semibold text-white/55 text-right px-1">
                  {t.playlistNamePlaceholder}
                </label>
                <div className="flex items-center gap-2">
                  <input
                    type="text"
                    value={nameInput}
                    onChange={(e) => setNameInput(e.target.value)}
                    onBlur={() => handleSaveName()}
                    placeholder={t.playlistNamePlaceholder}
                    className="flex-1 bg-white/[0.06] rounded-xl py-2.5 px-3.5 text-sm text-white placeholder:text-white/35 focus:outline-none focus:bg-white/[0.1] transition-all text-right"
                  />
                  {nameInput.trim() !== playlist.name && nameInput.trim().length > 0 && (
                    <button
                      type="submit"
                      style={{ backgroundColor: accentColor }}
                      className="px-3.5 py-2.5 rounded-xl text-xs font-bold text-black shrink-0 transition-transform active:scale-95"
                    >
                      {t.saveChanges}
                    </button>
                  )}
                  {nameSavedBadge && (
                    <span className="flex items-center gap-1 text-[11px] font-bold text-emerald-400 px-2 shrink-0">
                      <Check className="w-3.5 h-3.5" />
                    </span>
                  )}
                </div>
              </form>

              {/* Track Order & Management Header */}
              <div className="space-y-2.5">
                <div className="flex items-center justify-between gap-2 flex-wrap">
                  <div className="flex items-center gap-2">
                    <span className="text-xs font-bold text-white/80">
                      {t.playlistReorderSection}
                    </span>
                    <span className="text-[11px] font-semibold text-white/45 tabular-nums">
                      ({playlistTracks.length} {t.songsCount})
                    </span>
                  </div>

                  {/* Quick Order & Add Tools */}
                  <div className="flex items-center gap-1.5">
                    {playlistTracks.length >= 2 && (
                      <>
                        <button
                          type="button"
                          onClick={handleReverseOrder}
                          className="flex items-center gap-1 px-2.5 py-1.5 rounded-lg bg-white/[0.06] hover:bg-white/[0.12] text-[11px] font-semibold text-white/75 hover:text-white transition-colors"
                          title={t.reversePlaylistOrder}
                        >
                          <ArrowUpDown className="w-3 h-3" />
                          <span>{t.reversePlaylistOrder}</span>
                        </button>
                        <button
                          type="button"
                          onClick={handleSortAlphabetical}
                          className="flex items-center gap-1 px-2.5 py-1.5 rounded-lg bg-white/[0.06] hover:bg-white/[0.12] text-[11px] font-semibold text-white/75 hover:text-white transition-colors"
                          title={t.sortPlaylistAlpha}
                        >
                          <SortAsc className="w-3 h-3" />
                          <span>{t.sortPlaylistAlpha}</span>
                        </button>
                      </>
                    )}
                    <button
                      type="button"
                      onClick={() => {
                        onClose();
                        onOpenAddSongs(playlist);
                      }}
                      className="flex items-center gap-1 px-2.5 py-1.5 rounded-lg bg-white/[0.08] hover:bg-white/[0.15] text-[11px] font-bold text-white transition-colors"
                    >
                      <Plus className="w-3 h-3" />
                      <span>{t.addSongsAction}</span>
                    </button>
                  </div>
                </div>

                {/* Tracks List with Move Up / Move Down / Remove */}
                {playlistTracks.length === 0 ? (
                  <div className="py-8 text-center rounded-2xl bg-white/[0.03] flex flex-col items-center gap-2">
                    <Music className="w-6 h-6 text-white/25" />
                    <p className="text-xs text-white/45">{t.emptyPlaylistDesc}</p>
                  </div>
                ) : (
                  <div className="space-y-1.5 max-h-[34vh] overflow-y-auto pr-0.5 custom-scrollbar">
                    <AnimatePresence initial={false}>
                      {playlistTracks.map((track, idx) => (
                        <motion.div
                          key={track.id}
                          layout="position"
                          initial={{ opacity: 0, y: 6 }}
                          animate={{ opacity: 1, y: 0 }}
                          exit={{ opacity: 0, scale: 0.96 }}
                          transition={{ duration: 0.16 }}
                          className="flex items-center gap-2.5 p-2 rounded-xl bg-white/[0.04] hover:bg-white/[0.07] transition-colors"
                        >
                          {/* Index badge */}
                          <span className="w-5 text-center text-[11px] font-bold text-white/40 tabular-nums shrink-0">
                            {idx + 1}
                          </span>

                          {/* Cover */}
                          <div className="w-9 h-9 rounded-lg overflow-hidden bg-white/[0.06] shrink-0 flex items-center justify-center">
                            {track.coverUrl ? (
                              <img
                                src={track.coverUrl}
                                alt={track.title}
                                className="w-full h-full object-cover"
                              />
                            ) : (
                              <Music className="w-4 h-4 text-white/30" />
                            )}
                          </div>

                          {/* Title & Artist */}
                          <div className="flex-1 min-w-0 text-right">
                            <p className="text-xs font-semibold text-white truncate">
                              {track.title}
                            </p>
                            <p className="text-[10px] text-white/45 truncate">
                              {track.artist} • {formatDuration(track.duration)}
                            </p>
                          </div>

                          {/* Reorder & Remove Controls */}
                          <div className="flex items-center gap-1 shrink-0">
                            <button
                              type="button"
                              disabled={idx === 0}
                              onClick={() => handleMoveTrack(idx, 'up')}
                              title={t.moveTrackUp}
                              className="w-7 h-7 rounded-lg bg-white/[0.05] hover:bg-white/[0.12] disabled:opacity-25 disabled:pointer-events-none flex items-center justify-center text-white/75 hover:text-white transition-colors"
                            >
                              <ArrowUp className="w-3.5 h-3.5" />
                            </button>
                            <button
                              type="button"
                              disabled={idx === playlistTracks.length - 1}
                              onClick={() => handleMoveTrack(idx, 'down')}
                              title={t.moveTrackDown}
                              className="w-7 h-7 rounded-lg bg-white/[0.05] hover:bg-white/[0.12] disabled:opacity-25 disabled:pointer-events-none flex items-center justify-center text-white/75 hover:text-white transition-colors"
                            >
                              <ArrowDown className="w-3.5 h-3.5" />
                            </button>
                            <button
                              type="button"
                              onClick={() => handleRemoveTrack(track.id)}
                              title={t.removeFromPlaylist}
                              className="w-7 h-7 rounded-lg bg-red-500/10 hover:bg-red-500/20 flex items-center justify-center text-red-400 hover:text-red-300 transition-colors mr-0.5"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          </div>
                        </motion.div>
                      ))}
                    </AnimatePresence>
                  </div>
                )}
              </div>

              {/* Safe Delete Playlist Section */}
              <div className="pt-2">
                {!showDeleteConfirm ? (
                  <button
                    type="button"
                    onClick={() => {
                      setShowDeleteConfirm(true);
                      setDeleteConfirmText('');
                    }}
                    className="w-full py-2.5 px-4 rounded-xl bg-red-500/10 hover:bg-red-500/15 text-red-400 hover:text-red-300 text-xs font-bold flex items-center justify-center gap-2 transition-colors"
                  >
                    <Trash2 className="w-4 h-4" />
                    <span>{t.deletePlaylistDangerTitle}</span>
                  </button>
                ) : (
                  <motion.form
                    initial={{ opacity: 0, y: 8 }}
                    animate={{ opacity: 1, y: 0 }}
                    onSubmit={handleFinalDelete}
                    className="p-3.5 rounded-2xl bg-red-500/[0.08] space-y-3 text-right"
                  >
                    <div className="flex items-start gap-2.5">
                      <div className="w-8 h-8 rounded-lg bg-red-500/20 text-red-400 flex items-center justify-center shrink-0 mt-0.5">
                        <AlertTriangle className="w-4 h-4" />
                      </div>
                      <div className="flex-1 min-w-0">
                        <h4 className="text-xs font-bold text-red-300">
                          {t.deletePlaylistConfirmQuestion}
                        </h4>
                        <p className="text-[11px] text-white/60 mt-0.5 leading-relaxed">
                          {t.deletePlaylistTypeHint}
                        </p>
                      </div>
                    </div>

                    <input
                      type="text"
                      value={deleteConfirmText}
                      onChange={(e) => setDeleteConfirmText(e.target.value)}
                      placeholder={t.deletePlaylistWord}
                      autoFocus
                      className="w-full bg-black/50 rounded-xl py-2 px-3 text-xs text-white placeholder:text-white/30 focus:outline-none focus:bg-black/70 text-right font-bold tracking-wide"
                    />

                    <div className="flex items-center gap-2">
                      <button
                        type="submit"
                        disabled={!isConfirmWordValid}
                        className="flex-1 py-2 rounded-xl bg-red-500 hover:bg-red-600 disabled:bg-red-500/20 disabled:text-white/30 text-white text-xs font-bold transition-all active:scale-[0.98]"
                      >
                        {t.deletePlaylistFinalBtn}
                      </button>
                      <button
                        type="button"
                        onClick={() => {
                          setShowDeleteConfirm(false);
                          setDeleteConfirmText('');
                        }}
                        className="px-4 py-2 rounded-xl bg-white/[0.07] hover:bg-white/[0.12] text-white/75 text-xs font-semibold transition-colors"
                      >
                        {t.cancel}
                      </button>
                    </div>
                  </motion.form>
                )}
              </div>
            </div>
          </motion.div>
        </div>
      )}
    </AnimatePresence>
  );
};
