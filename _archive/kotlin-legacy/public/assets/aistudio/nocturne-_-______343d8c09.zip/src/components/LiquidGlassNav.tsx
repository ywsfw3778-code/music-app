import { FolderOpen, Music2, Plus, Settings2 } from 'lucide-react';
import { motion } from 'motion/react';
import type { Translations } from '../i18n/translations';
import type { AppView } from '../types/music';

interface LiquidGlassNavProps {
  activeView: AppView;
  onSelectView: (view: AppView) => void;
  onTriggerImport: () => void;
  t: Translations;
  accentColor: string;
  glowColor?: string;
  activeTrackCount: number;
  excludedCount: number;
}

export function LiquidGlassNav({
  activeView,
  onSelectView,
  onTriggerImport,
  t,
  accentColor,
}: LiquidGlassNavProps) {
  const navItems: Array<{ id: AppView; label: string; icon: typeof Music2 }> = [
    { id: 'library', label: t.navLibrary, icon: Music2 },
    { id: 'folders', label: t.navFolders, icon: FolderOpen },
    { id: 'settings', label: t.navSettings, icon: Settings2 },
  ];

  return (
    <nav
      aria-label="Primary"
      className="fixed bottom-3 bottom-3.5 inset-x-3.5 z-40 mx-auto max-w-md flex items-center gap-2.5"
      style={{ top: 'auto', bottom: 'max(14px, env(safe-area-inset-bottom, 14px))' }}
    >
      <div className="water-drop-bar rounded-full p-1.5 flex-1 grid grid-cols-3 items-center h-[58px]">
        {navItems.map((item) => {
          const Icon = item.icon;
          const isActive = activeView === item.id;
          return (
            <motion.button
              key={item.id}
              type="button"
              whileTap={{ scale: 0.9 }}
              onClick={() => onSelectView(item.id)}
              className="relative flex flex-col items-center justify-center h-full rounded-full focus-visible:outline-none"
            >
              {isActive && (
                <motion.div
                  layoutId="mobile-nav-pill"
                  transition={{ type: 'spring', stiffness: 520, damping: 34 }}
                  className="absolute inset-0 rounded-full water-drop-pill"
                />
              )}
              <motion.div
                animate={{
                  y: isActive ? -1.5 : 0,
                  scale: isActive ? 1.08 : 1,
                }}
                transition={{ type: 'spring', stiffness: 500, damping: 26 }}
                className="relative z-10"
              >
                <Icon
                  size={18}
                  strokeWidth={isActive ? 2.4 : 1.9}
                  style={{
                    color: isActive ? accentColor : '#CBD5E1',
                  }}
                />
              </motion.div>
              <span
                className="relative z-10 text-[10.5px] font-semibold leading-none mt-1 whitespace-nowrap shrink-0 transition-colors"
                style={{ color: isActive ? '#FFFFFF' : '#CBD5E1' }}
              >
                {item.label}
              </span>
            </motion.button>
          );
        })}
      </div>

      {/* Water-Drop Transparent Import Button */}
      <motion.button
        type="button"
        whileTap={{ scale: 0.88, rotate: 90 }}
        whileHover={{ scale: 1.04 }}
        transition={{ type: 'spring', stiffness: 450, damping: 24 }}
        onClick={onTriggerImport}
        aria-label={t.importMore}
        className="water-drop-bar w-[58px] h-[58px] rounded-full flex items-center justify-center shrink-0"
      >
        <Plus size={22} strokeWidth={2.5} style={{ color: accentColor }} />
      </motion.button>
    </nav>
  );
}
