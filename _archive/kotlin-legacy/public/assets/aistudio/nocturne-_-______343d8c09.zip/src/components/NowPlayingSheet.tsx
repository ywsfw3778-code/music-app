import {
  ChevronDown,
  FileText,
  Heart,
  Loader2,
  MoreVertical,
  Pause,
  Play,
  Repeat,
  Repeat1,
  Search,
  Shuffle,
  SkipBack,
  SkipForward,
  Upload,
  X,
} from 'lucide-react';
import { AnimatePresence, motion } from 'motion/react';
import { useEffect, useMemo, useRef, useState } from 'react';
import type { ChangeEvent } from 'react';
import type { Translations } from '../i18n/translations';
import type { ArtworkBackgroundMode, LyricsData, RepeatMode, Track } from '../types/music';
import {
  buildLyricsDataFromResult,
  parseLrcText,
  searchLrclibLyrics,
  type LrclibSearchResult,
} from '../utils/lyricsService';
import { formatDuration } from '../utils/smartFilter';
import { ArtworkTile } from './ArtworkTile';
import { CustomGlassSlider } from './CustomGlassSlider';

export type NowPlayingTab = 'artwork' | 'lyrics' | 'queue';

interface NowPlayingSheetProps {
  isOpen: boolean;
  initialTab?: NowPlayingTab;
  track: Track | null;
  queueTracks: Track[];
  isPlaying: boolean;
  currentTime: number;
  duration: number;
  shuffle: boolean;
  repeatMode: RepeatMode;
  isCrossfading: boolean;
  crossfadeEnabled: boolean;
  crossfadeSeconds: number;
  accentColor: string;
  glowColor?: string;
  secondaryColor?: string;
  artworkBackgroundMode?: ArtworkBackgroundMode;
  lyrics: LyricsData | null;
  isLoadingLyrics: boolean;
  onClose: () => void;
  onTogglePlay: () => void;
  onNext: () => void;
  onPrev: () => void;
  onSeek: (seconds: number) => void;
  onToggleShuffle: () => void;
  onCycleRepeat: () => void;
  onToggleFavorite: (trackId: string) => void;
  onOpenContextMenu: (track: Track) => void;
  onPlayQueueTrack: (track: Track) => void;
  onClearQueue: () => void;
  onUpdateLyrics: (lyrics: LyricsData) => void;
  t: Translations;
  isDesktopStage?: boolean;
}

export function NowPlayingSheet({
  isOpen,
  initialTab = 'artwork',
  track,
  queueTracks,
  isPlaying,
  currentTime,
  duration,
  shuffle,
  repeatMode,
  isCrossfading,
  crossfadeEnabled,
  crossfadeSeconds,
  accentColor,
  glowColor,
  secondaryColor,
  artworkBackgroundMode = 'full',
  lyrics,
  isLoadingLyrics,
  onClose,
  onTogglePlay,
  onNext,
  onPrev,
  onSeek,
  onToggleShuffle,
  onCycleRepeat,
  onToggleFavorite,
  onOpenContextMenu,
  onPlayQueueTrack,
  onClearQueue,
  onUpdateLyrics,
  t,
  isDesktopStage = false,
}: NowPlayingSheetProps) {
  const [activeTab, setActiveTab] = useState<NowPlayingTab>(initialTab);
  const [isSearchOpen, setIsSearchOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [searchResults, setSearchResults] = useState<LrclibSearchResult[]>([]);
  const [isSearchingOnline, setIsSearchingOnline] = useState(false);
  const [searchError, setSearchError] = useState(false);

  const lrcInputRef = useRef<HTMLInputElement | null>(null);
  const activeLineRef = useRef<HTMLButtonElement | null>(null);

  useEffect(() => {
    setActiveTab(initialTab);
  }, [initialTab]);

  useEffect(() => {
    if (track) {
      setSearchQuery(`${track.title}${track.artist && !track.artist.includes('غير') && !track.artist.includes('Unknown') ? ` ${track.artist}` : ''}`);
      setSearchResults([]);
      setIsSearchOpen(false);
    }
  }, [track?.id]);

  const effectiveDuration = duration > 0 ? duration : track?.duration || 0;
  const currentMs = currentTime * 1000 + (lyrics?.offsetMs || 0);

  const activeLineIndex = useMemo(() => {
    if (!lyrics || lyrics.syncedLines.length === 0) return -1;
    let idx = -1;
    for (let i = 0; i < lyrics.syncedLines.length; i++) {
      if (currentMs >= lyrics.syncedLines[i].timeMs) {
        idx = i;
      } else {
        break;
      }
    }
    return idx;
  }, [lyrics, currentMs]);

  useEffect(() => {
    if (activeTab === 'lyrics' && activeLineRef.current) {
      activeLineRef.current.scrollIntoView({
        behavior: 'smooth',
        block: 'center',
      });
    }
  }, [activeLineIndex, activeTab]);

  const handleManualSearch = async () => {
    if (!searchQuery.trim()) return;
    setIsSearchingOnline(true);
    setSearchError(false);
    try {
      const results = await searchLrclibLyrics(searchQuery);
      setSearchResults(results);
    } catch {
      setSearchError(true);
      setSearchResults([]);
    } finally {
      setIsSearchingOnline(false);
    }
  };

  const handleLrcFileUpload = async (e: ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file || !track) return;
    const text = await file.text();
    const parsed = parseLrcText(text);
    onUpdateLyrics({
      trackId: track.id,
      syncedLines: parsed,
      plainLyrics: parsed.length === 0 ? text : '',
      offsetMs: 0,
      source: 'local_lrc',
      matchedTitle: track.title,
      matchedArtist: track.artist,
      fetchedAt: Date.now(),
    });
    e.target.value = '';
  };

  const adjustOffset = (deltaMs: number) => {
    if (!lyrics) return;
    onUpdateLyrics({
      ...lyrics,
      offsetMs: Math.max(-10000, Math.min(10000, lyrics.offsetMs + deltaMs)),
    });
  };

  const innerContent = !track ? (
    <div className="h-full flex flex-col items-center justify-center p-8 text-center">
      <div className="w-20 h-20 rounded-3xl bg-white/[0.06] flex items-center justify-center mb-5">
        <ArtworkTile title={t.appName} sizeClass="w-12 h-12" roundedClass="rounded-xl" iconSize={24} />
      </div>
      <h3 className="text-lg font-semibold text-slate-100">{t.desktopStageIdleTitle}</h3>
      <p className="text-sm text-slate-400 mt-2 max-w-xs leading-relaxed">
        {t.desktopStageIdleDesc}
      </p>
    </div>
  ) : (
    <div className="relative h-full flex flex-col justify-between overflow-hidden bg-black">
      {/* Dynamic AMOLED Multi-Layer Artwork Aura */}
      {artworkBackgroundMode !== 'off' && (
        <div
          className="absolute inset-0 pointer-events-none transition-all duration-700"
          style={{
            background:
              artworkBackgroundMode === 'full'
                ? `
                  radial-gradient(110% 80% at 50% 22%, ${(glowColor || accentColor)}55 0%, ${(secondaryColor || accentColor)}33 52%, rgba(0,0,0,0.65) 100%),
                  radial-gradient(95% 65% at 50% 88%, ${accentColor}38 0%, rgba(0,0,0,0) 75%)
                `
                : `
                  radial-gradient(85% 55% at 50% 18%, ${(glowColor || accentColor)}48 0%, ${(secondaryColor || accentColor)}1F 45%, rgba(0,0,0,0) 78%),
                  radial-gradient(70% 40% at 50% 92%, ${accentColor}24 0%, rgba(0,0,0,0) 70%)
                `,
          }}
        />
      )}

      {/* Clear Softly-Blurred Song Cover Background Behind Player (Full / Partial / Off) */}
      {track.coverUrl && artworkBackgroundMode !== 'off' && (
        <div
          className={`pointer-events-none overflow-hidden ${
            artworkBackgroundMode === 'full'
              ? 'absolute inset-0'
              : 'absolute inset-x-0 top-0 h-[62%]'
          }`}
        >
          <img
            src={track.coverUrl}
            alt=""
            aria-hidden="true"
            referrerPolicy="no-referrer"
            className="w-full h-full object-cover scale-105 transition-all duration-700"
            style={{
              opacity: artworkBackgroundMode === 'full' ? 0.78 : 0.72,
              filter:
                artworkBackgroundMode === 'full'
                  ? 'blur(9px) saturate(135%) brightness(0.72)'
                  : 'blur(7px) saturate(135%) brightness(0.8)',
              WebkitFilter:
                artworkBackgroundMode === 'full'
                  ? 'blur(9px) saturate(135%) brightness(0.72)'
                  : 'blur(7px) saturate(135%) brightness(0.8)',
            }}
          />
          <div
            className="absolute inset-0"
            style={{
              background:
                artworkBackgroundMode === 'full'
                  ? 'linear-gradient(180deg, rgba(0,0,0,0.18) 0%, rgba(0,0,0,0.34) 50%, rgba(0,0,0,0.58) 100%)'
                  : 'linear-gradient(180deg, rgba(0,0,0,0.14) 0%, rgba(0,0,0,0.32) 55%, rgba(0,0,0,0.85) 85%, #000000 100%)',
            }}
          />
        </div>
      )}

      {/* Top Bar (Water-Drop Transparent with Minimal Blur) */}
      <div className="relative z-10 flex items-center justify-between px-4 pt-4 pb-2 shrink-0">
        {!isDesktopStage ? (
          <button
            type="button"
            onClick={onClose}
            aria-label={t.close}
            className="min-w-[44px] min-h-[44px] flex items-center justify-center rounded-full water-drop-bar text-slate-100 hover:text-white active:scale-90 transition-all"
          >
            <ChevronDown size={22} />
          </button>
        ) : (
          <div className="w-11" />
        )}

        {/* Water-Drop Segmented Switcher */}
        <div className="flex items-center gap-1 p-1 rounded-full water-drop-bar">
          {(['artwork', 'lyrics', 'queue'] as NowPlayingTab[]).map((tab) => {
            const label =
              tab === 'artwork' ? t.artworkTab : tab === 'lyrics' ? t.lyricsTab : t.queueTab;
            const active = activeTab === tab;
            return (
              <button
                key={tab}
                type="button"
                onClick={() => setActiveTab(tab)}
                className="relative px-3.5 py-1.5 min-h-[34px] rounded-full text-xs font-semibold whitespace-nowrap shrink-0 transition-colors"
              >
                {active && (
                  <motion.div
                    layoutId={isDesktopStage ? 'np-tab-desktop' : 'np-tab-mobile'}
                    transition={{ type: 'spring', stiffness: 420, damping: 34 }}
                    className="absolute inset-0 rounded-full water-drop-pill"
                  />
                )}
                <span className="relative z-10" style={{ color: active ? '#FFFFFF' : '#CBD5E1' }}>
                  {label}
                </span>
              </button>
            );
          })}
        </div>

        <button
          type="button"
          onClick={() => onOpenContextMenu(track)}
          aria-label="Track options"
          className="min-w-[44px] min-h-[44px] flex items-center justify-center rounded-full water-drop-bar text-slate-100 hover:text-white active:scale-90 transition-all"
        >
          <MoreVertical size={19} />
        </button>
      </div>

      {/* Main Dynamic Stage (Artwork / Synced Lyrics / Queue) */}
      <div className="relative z-10 flex-1 min-h-0 px-6 py-2 flex flex-col">
        <AnimatePresence mode="wait">
          {activeTab === 'artwork' && (
            <motion.div
              key="stage-artwork"
              initial={{ opacity: 0, scale: 0.92, y: 12 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.94, y: -10 }}
              transition={{ type: 'spring', stiffness: 450, damping: 32 }}
              className="flex-1 flex flex-col items-center justify-center min-h-0"
            >
              <motion.div
                layoutId={!isDesktopStage ? 'active-player-artwork' : undefined}
                animate={{
                  scale: isPlaying ? 1 : 0.88,
                  y: isPlaying ? 0 : 8,
                }}
                transition={{
                  type: 'spring',
                  stiffness: 380,
                  damping: 28,
                }}
                className="relative w-full max-w-[280px] sm:max-w-[310px] aspect-square rounded-[28px] overflow-hidden shadow-2xl"
                style={{
                  boxShadow: isPlaying
                    ? `0 28px 70px -10px ${(glowColor || accentColor)}66`
                    : '0 16px 40px -12px rgba(0,0,0,0.85)',
                }}
              >
                <ArtworkTile
                  coverUrl={track.coverUrl}
                  title={track.title}
                  accentColor={accentColor}
                  sizeClass="w-full h-full"
                  roundedClass="rounded-none"
                  iconSize={56}
                />
              </motion.div>

              {crossfadeEnabled && (
                <p className="mt-4 text-xs text-slate-300/90 flex items-center justify-center gap-1.5">
                  {isCrossfading ? (
                    <span style={{ color: accentColor }} className="font-semibold">
                      {t.crossfadeActive}
                    </span>
                  ) : (
                    <>
                      <span>{t.crossfadeDuration}:</span>
                      <span
                        dir="ltr"
                        className="font-mono-tabular font-semibold"
                        style={{ color: accentColor }}
                      >
                        {crossfadeSeconds}
                      </span>
                      <span>{t.secondsUnit}</span>
                    </>
                  )}
                </p>
              )}
            </motion.div>
          )}

          {activeTab === 'lyrics' && (
            <motion.div
              key="stage-lyrics"
              initial={{ opacity: 0, y: 18, scale: 0.98 }}
              animate={{ opacity: 1, y: 0, scale: 1 }}
              exit={{ opacity: 0, y: -14, scale: 0.98 }}
              transition={{ type: 'spring', stiffness: 450, damping: 34 }}
              className="flex-1 flex flex-col min-h-0"
            >
              {/* Lyrics toolbar */}
              <div className="flex items-center justify-between gap-2 pb-2 shrink-0 text-xs text-slate-400">
                <span>
                  {lyrics && lyrics.syncedLines.length > 0
                    ? t.syncedBadge
                    : lyrics?.plainLyrics
                    ? t.plainLyricsNote
                    : ''}
                </span>
                <div className="flex items-center gap-1.5">
                  {lyrics && lyrics.syncedLines.length > 0 && (
                    <div className="flex items-center gap-1 water-drop-bar rounded-full px-2 py-0.5 font-mono-tabular">
                      <button
                        type="button"
                        onClick={() => adjustOffset(-500)}
                        className="px-1.5 py-0.5 text-slate-300 hover:text-white"
                      >
                        -0.5s
                      </button>
                      <span className="text-[11px] text-slate-400">
                        {(lyrics.offsetMs / 1000).toFixed(1)}s
                      </span>
                      <button
                        type="button"
                        onClick={() => adjustOffset(500)}
                        className="px-1.5 py-0.5 text-slate-300 hover:text-white"
                      >
                        +0.5s
                      </button>
                    </div>
                  )}

                  <button
                    type="button"
                    onClick={() => setIsSearchOpen((v) => !v)}
                    aria-label={t.searchLyricsOnline}
                    className="min-h-[34px] min-w-[34px] px-2.5 rounded-full water-drop-bar text-slate-200 hover:bg-white/10 flex items-center gap-1"
                  >
                    <Search size={13} />
                    <span className="hidden sm:inline">{t.manualSearchAction}</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => lrcInputRef.current?.click()}
                    aria-label={t.uploadLrcFile}
                    className="min-h-[34px] min-w-[34px] px-2.5 rounded-full water-drop-bar text-slate-200 hover:bg-white/10 flex items-center gap-1"
                  >
                    <Upload size={13} />
                    <span className="hidden sm:inline">.LRC</span>
                  </button>
                  <input
                    ref={lrcInputRef}
                    type="file"
                    accept=".lrc,.txt"
                    onChange={handleLrcFileUpload}
                    className="hidden"
                  />
                </div>
              </div>

              {/* Manual LRCLIB Search Drawer */}
              {isSearchOpen ? (
                <div className="flex-1 flex flex-col min-h-0 liquid-glass rounded-2xl p-3.5">
                  <div className="flex items-center justify-between mb-3">
                    <span className="text-xs font-semibold text-slate-200">{t.manualSearchTitle}</span>
                    <button
                      type="button"
                      onClick={() => setIsSearchOpen(false)}
                      className="p-1.5 rounded-full text-slate-400 hover:text-white"
                    >
                      <X size={15} />
                    </button>
                  </div>
                  <div className="flex gap-2 mb-3">
                    <input
                      type="text"
                      value={searchQuery}
                      onChange={(e) => setSearchQuery(e.target.value)}
                      onKeyDown={(e) => {
                        if (e.key === 'Enter') void handleManualSearch();
                      }}
                      placeholder={t.manualSearchPlaceholder}
                      className="flex-1 min-h-[42px] px-3.5 rounded-xl bg-black/60 border border-white/15 text-sm text-white placeholder:text-slate-500 focus:outline-none focus:border-white/35"
                    />
                    <button
                      type="button"
                      onClick={() => void handleManualSearch()}
                      className="min-h-[42px] px-4 rounded-xl bg-white/15 hover:bg-white/20 text-xs font-semibold text-white whitespace-nowrap"
                    >
                      {t.manualSearchAction}
                    </button>
                  </div>

                  <div className="flex-1 overflow-y-auto no-scrollbar space-y-2">
                    {isSearchingOnline ? (
                      <div className="py-10 flex items-center justify-center gap-2 text-xs text-slate-400">
                        <Loader2 size={16} className="animate-spin" />
                        <span>{t.fetchingLyrics}</span>
                      </div>
                    ) : searchResults.length > 0 ? (
                      searchResults.map((res) => (
                        <div
                          key={res.id}
                          className="p-3 rounded-xl bg-white/[0.04] border border-white/[0.08] flex items-center justify-between gap-3"
                        >
                          <div className="min-w-0 flex-1">
                            <p className="text-sm font-medium text-slate-100 truncate">
                              {res.trackName}
                            </p>
                            <p className="text-xs text-slate-400 truncate mt-0.5">
                              {res.artistName}
                              {res.syncedLyrics ? ` · ${t.syncedBadge}` : ''}
                            </p>
                          </div>
                          <button
                            type="button"
                            onClick={() => {
                              onUpdateLyrics(buildLyricsDataFromResult(track.id, res));
                              setIsSearchOpen(false);
                            }}
                            className="px-3 py-1.5 rounded-lg bg-white/15 hover:bg-white/25 text-xs font-medium text-white shrink-0"
                          >
                            {t.applyLyrics}
                          </button>
                        </div>
                      ))
                    ) : searchError ? (
                      <p className="text-xs text-rose-400 text-center py-6">{t.noLyricsFound}</p>
                    ) : (
                      <p className="text-xs text-slate-500 text-center py-6">{t.searchResultsEmpty}</p>
                    )}
                  </div>
                </div>
              ) : isLoadingLyrics ? (
                <div className="flex-1 flex flex-col items-center justify-center gap-3 text-slate-400">
                  <Loader2 size={24} className="animate-spin" style={{ color: accentColor }} />
                  <p className="text-sm">{t.fetchingLyrics}</p>
                </div>
              ) : lyrics && lyrics.syncedLines.length > 0 ? (
                <div className="flex-1 overflow-y-auto no-scrollbar py-12 space-y-4">
                  <p className="text-[11px] text-slate-500 text-center pb-2">{t.tapLineToSeek}</p>
                  {lyrics.syncedLines.map((line, index) => {
                    const isActive = index === activeLineIndex;
                    const distance = activeLineIndex >= 0 ? Math.abs(index - activeLineIndex) : 1;
                    return (
                      <button
                        key={`${line.timeMs}-${index}`}
                        ref={isActive ? activeLineRef : undefined}
                        type="button"
                        onClick={() => onSeek(line.timeMs / 1000)}
                        className="w-full text-start px-2 py-1.5 rounded-xl transition-all duration-300 block"
                        style={{
                          color: isActive ? '#FFFFFF' : 'rgba(226, 232, 240, 0.42)',
                          transform: isActive ? 'scale(1.03)' : 'scale(0.98)',
                          filter: isActive
                            ? 'blur(0px)'
                            : distance > 2
                            ? 'blur(0.8px)'
                            : 'blur(0.25px)',
                          textShadow: isActive ? `0 0 24px ${accentColor}55` : 'none',
                        }}
                      >
                        <span
                          className={`block leading-relaxed ${
                            isActive ? 'text-xl sm:text-2xl font-bold' : 'text-base sm:text-lg font-medium'
                          }`}
                        >
                          {line.text}
                        </span>
                      </button>
                    );
                  })}
                </div>
              ) : lyrics?.plainLyrics ? (
                <div className="flex-1 overflow-y-auto no-scrollbar py-6">
                  <pre className="whitespace-pre-wrap font-sans text-base leading-loose text-slate-200 text-center">
                    {lyrics.plainLyrics}
                  </pre>
                </div>
              ) : (
                <div className="flex-1 flex flex-col items-center justify-center text-center px-4">
                  <FileText size={32} className="text-slate-600 mb-3" />
                  <p className="text-sm font-medium text-slate-200">{t.noLyricsFound}</p>
                  <p className="text-xs text-slate-400 mt-1.5 max-w-xs leading-relaxed">
                    {t.noLyricsHint}
                  </p>
                  <div className="flex flex-wrap items-center justify-center gap-2.5 mt-5">
                    <button
                      type="button"
                      onClick={() => setIsSearchOpen(true)}
                      className="min-h-[42px] px-4 rounded-xl liquid-glass text-xs font-semibold text-white flex items-center gap-2"
                    >
                      <Search size={14} />
                      <span>{t.searchLyricsOnline}</span>
                    </button>
                    <button
                      type="button"
                      onClick={() => lrcInputRef.current?.click()}
                      className="min-h-[42px] px-4 rounded-xl water-drop-bar text-xs font-medium text-slate-200 flex items-center gap-2"
                    >
                      <Upload size={14} />
                      <span>{t.uploadLrcFile}</span>
                    </button>
                  </div>
                </div>
              )}
            </motion.div>
          )}

          {activeTab === 'queue' && (
            <motion.div
              key="stage-queue"
              initial={{ opacity: 0, y: 18, scale: 0.98 }}
              animate={{ opacity: 1, y: 0, scale: 1 }}
              exit={{ opacity: 0, y: -14, scale: 0.98 }}
              transition={{ type: 'spring', stiffness: 450, damping: 34 }}
              className="flex-1 flex flex-col min-h-0"
            >
              <div className="flex items-center justify-between pb-3 shrink-0">
                <h4 className="text-xs font-semibold text-slate-300">{t.upNext}</h4>
                {queueTracks.length > 0 && (
                  <button
                    type="button"
                    onClick={onClearQueue}
                    className="text-xs text-slate-400 hover:text-white"
                  >
                    {t.clearQueue}
                  </button>
                )}
              </div>

              <div className="flex-1 overflow-y-auto no-scrollbar space-y-1.5">
                {queueTracks.length === 0 ? (
                  <div className="h-full flex items-center justify-center text-xs text-slate-500">
                    {t.queueEmpty}
                  </div>
                ) : (
                  queueTracks.map((qTrack) => (
                    <button
                      key={qTrack.id}
                      type="button"
                      onClick={() => onPlayQueueTrack(qTrack)}
                      className="w-full min-h-[54px] px-2.5 py-2 rounded-xl hover:bg-white/[0.06] flex items-center gap-3 text-start transition-colors"
                    >
                      <ArtworkTile
                        coverUrl={qTrack.coverUrl}
                        title={qTrack.title}
                        sizeClass="w-10 h-10"
                        roundedClass="rounded-lg"
                        iconSize={16}
                      />
                      <div className="min-w-0 flex-1">
                        <p className="text-sm font-medium text-slate-100 truncate">{qTrack.title}</p>
                        <p className="text-xs text-slate-400 truncate mt-0.5">
                          {qTrack.artist} · {formatDuration(qTrack.duration)}
                        </p>
                      </div>
                    </button>
                  ))
                )}
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>

      {/* Clean, Natural Bottom Player Controls with Framer Motion Choreography */}
      <div className="relative z-10 px-6 pb-8 pt-3 space-y-4 shrink-0">
        <div className="flex items-center justify-between gap-3">
          <div className="min-w-0 flex-1 overflow-hidden">
            <AnimatePresence mode="wait" initial={false}>
              <motion.div
                key={track.id}
                initial={{ opacity: 0, y: 12 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -12 }}
                transition={{ type: 'spring', stiffness: 500, damping: 34 }}
              >
                <h2 className="text-lg font-bold text-white truncate tracking-tight">
                  {track.title}
                </h2>
                <p className="text-xs font-medium text-slate-300/80 truncate mt-0.5">
                  {track.artist} · {track.album}
                </p>
              </motion.div>
            </AnimatePresence>
          </div>
          <motion.button
            type="button"
            whileTap={{ scale: 0.78 }}
            animate={{ scale: track.isFavorite ? [1, 1.22, 1] : 1 }}
            transition={{ duration: 0.28 }}
            onClick={() => onToggleFavorite(track.id)}
            aria-label={track.isFavorite ? t.removeFromFavorites : t.addToFavorites}
            className="w-11 h-11 flex items-center justify-center rounded-full hover:bg-white/10 shrink-0"
          >
            <Heart
              size={20}
              fill={track.isFavorite ? accentColor : 'none'}
              style={{ color: track.isFavorite ? accentColor : '#cbd5e1' }}
            />
          </motion.button>
        </div>

        {/* Right-to-Left (RTL) Scrubber & Glowing Thumb */}
        <div dir="rtl" className="space-y-1">
          <CustomGlassSlider
            min={0}
            max={effectiveDuration > 0 ? effectiveDuration : 100}
            step={0.25}
            value={Math.min(currentTime, effectiveDuration || 100)}
            accentColor={accentColor}
            glowColor={glowColor}
            onChange={(val) => onSeek(val)}
            ariaLabel="Seek audio position"
          />
          <div className="flex items-center justify-between text-xs text-slate-300/90 font-mono-tabular px-0.5">
            <span dir="ltr" style={{ color: accentColor }} className="font-semibold">
              {formatDuration(currentTime)}
            </span>
            <span dir="ltr">{formatDuration(effectiveDuration)}</span>
          </div>
        </div>

        {/* Natural Borderless Transport Controls with Spring Physics */}
        <div dir="rtl" className="flex items-center justify-between pt-1">
          <motion.button
            type="button"
            whileTap={{ scale: 0.85 }}
            onClick={onToggleShuffle}
            aria-label="Shuffle"
            className="w-11 h-11 flex items-center justify-center rounded-full hover:bg-white/10"
            style={{ color: shuffle ? accentColor : 'rgba(203, 213, 225, 0.72)' }}
          >
            <Shuffle size={18} />
          </motion.button>

          <motion.button
            type="button"
            whileTap={{ scale: 0.84, x: 4 }}
            onClick={onPrev}
            aria-label="Previous"
            className="w-12 h-12 flex items-center justify-center rounded-full text-white hover:bg-white/10"
          >
            <SkipForward size={23} fill="currentColor" />
          </motion.button>

          <motion.button
            type="button"
            whileTap={{ scale: 0.88 }}
            whileHover={{ scale: 1.05 }}
            transition={{ type: 'spring', stiffness: 500, damping: 26 }}
            onClick={onTogglePlay}
            aria-label={isPlaying ? 'Pause' : 'Play'}
            className="w-16 h-16 rounded-full flex items-center justify-center text-black shadow-xl"
            style={{
              backgroundColor: accentColor,
              boxShadow: `0 12px 32px -4px ${accentColor}88`,
            }}
          >
            <AnimatePresence mode="wait" initial={false}>
              <motion.span
                key={isPlaying ? 'pause' : 'play'}
                initial={{ scale: 0.5, opacity: 0, rotate: -25 }}
                animate={{ scale: 1, opacity: 1, rotate: 0 }}
                exit={{ scale: 0.5, opacity: 0, rotate: 25 }}
                transition={{ duration: 0.15 }}
                className="flex items-center justify-center"
              >
                {isPlaying ? (
                  <Pause size={26} fill="currentColor" />
                ) : (
                  <Play size={26} fill="currentColor" className="translate-x-[1px]" />
                )}
              </motion.span>
            </AnimatePresence>
          </motion.button>

          <motion.button
            type="button"
            whileTap={{ scale: 0.84, x: -4 }}
            onClick={onNext}
            aria-label="Next"
            className="w-12 h-12 flex items-center justify-center rounded-full text-white hover:bg-white/10"
          >
            <SkipBack size={23} fill="currentColor" />
          </motion.button>

          <motion.button
            type="button"
            whileTap={{ scale: 0.85 }}
            onClick={onCycleRepeat}
            aria-label="Repeat mode"
            className="w-11 h-11 flex items-center justify-center rounded-full hover:bg-white/10"
            style={{
              color: repeatMode !== 'off' ? accentColor : 'rgba(203, 213, 225, 0.72)',
            }}
          >
            {repeatMode === 'one' ? <Repeat1 size={18} /> : <Repeat size={18} />}
          </motion.button>
        </div>
      </div>
    </div>
  );

  if (isDesktopStage) {
    return (
      <aside className="hidden lg:block w-[390px] xl:w-[430px] shrink-0 h-screen sticky top-0 border-s border-white/[0.06] bg-black">
        {innerContent}
      </aside>
    );
  }

  return (
    <AnimatePresence>
      {isOpen && track && (
        <motion.div
          key="mobile-now-playing-sheet"
          initial={{ opacity: 0, y: '100%' }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: '100%' }}
          transition={{
            type: 'spring',
            stiffness: 420,
            damping: 38,
            mass: 0.85,
          }}
          drag="y"
          dragConstraints={{ top: 0, bottom: 0 }}
          dragElastic={{ top: 0, bottom: 0.35 }}
          onDragEnd={(_, info) => {
            if (info.offset.y > 110 || info.velocity.y > 500) {
              onClose();
            }
          }}
          className="lg:hidden fixed inset-0 z-50 bg-black"
        >
          {innerContent}
        </motion.div>
      )}
    </AnimatePresence>
  );
}
