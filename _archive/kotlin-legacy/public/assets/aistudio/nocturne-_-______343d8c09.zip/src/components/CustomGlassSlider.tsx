import { motion, useSpring, useTransform } from 'motion/react';
import { useCallback, useEffect, useRef, useState } from 'react';
import type { KeyboardEvent, PointerEvent } from 'react';

interface CustomGlassSliderProps {
  value: number;
  min?: number;
  max: number;
  step?: number;
  accentColor: string;
  glowColor?: string;
  onChange: (newValue: number) => void;
  ariaLabel?: string;
}

export function CustomGlassSlider({
  value,
  min = 0,
  max,
  step = 0.1,
  accentColor,
  glowColor,
  onChange,
  ariaLabel = 'Slider',
}: CustomGlassSliderProps) {
  const railRef = useRef<HTMLDivElement | null>(null);
  const [isDragging, setIsDragging] = useState(false);
  const [dragValue, setDragValue] = useState<number | null>(null);

  const safeMax = max > min ? max : min + 100;
  const displayValue = isDragging && dragValue !== null ? dragValue : value;
  const clampedValue = Math.min(safeMax, Math.max(min, displayValue));
  const percentage = Math.min(100, Math.max(0, ((clampedValue - min) / (safeMax - min)) * 100));
  const activeGlow = glowColor || accentColor;

  // Physics spring for subtle motion blur when scrubbing rapidly
  const springPct = useSpring(percentage, {
    stiffness: isDragging ? 900 : 380,
    damping: isDragging ? 45 : 34,
  });

  useEffect(() => {
    springPct.set(percentage);
  }, [percentage, springPct]);

  const thumbScale = useTransform(springPct, () => (isDragging ? 1.28 : 1));

  // Right-to-Left (RTL) calculation: 0% is at the Right edge (rect.right), 100% is at the Left edge (rect.left)
  const computeValueFromClientX = useCallback(
    (clientX: number): number => {
      const el = railRef.current;
      if (!el) return value;
      const rect = el.getBoundingClientRect();
      if (rect.width <= 0) return value;
      const ratio = Math.min(1, Math.max(0, (rect.right - clientX) / rect.width));
      const raw = min + ratio * (safeMax - min);
      if (step > 0) {
        const stepped = Math.round((raw - min) / step) * step + min;
        return Math.min(safeMax, Math.max(min, Number(stepped.toFixed(2))));
      }
      return Math.min(safeMax, Math.max(min, raw));
    },
    [min, safeMax, step, value]
  );

  const handlePointerDown = (e: PointerEvent<HTMLDivElement>) => {
    e.preventDefault();
    e.stopPropagation();
    e.currentTarget.setPointerCapture(e.pointerId);
    setIsDragging(true);
    const nextVal = computeValueFromClientX(e.clientX);
    setDragValue(nextVal);
    onChange(nextVal);
  };

  const handlePointerMove = (e: PointerEvent<HTMLDivElement>) => {
    if (!isDragging) return;
    const nextVal = computeValueFromClientX(e.clientX);
    setDragValue(nextVal);
    onChange(nextVal);
  };

  const handlePointerUp = (e: PointerEvent<HTMLDivElement>) => {
    if (!isDragging) return;
    if (e.currentTarget.hasPointerCapture(e.pointerId)) {
      e.currentTarget.releasePointerCapture(e.pointerId);
    }
    const finalVal = computeValueFromClientX(e.clientX);
    setIsDragging(false);
    setDragValue(null);
    onChange(finalVal);
  };

  const handleKeyDown = (e: KeyboardEvent<HTMLDivElement>) => {
    const jump = step >= 1 ? step : Math.max(1, (safeMax - min) / 20);
    // In RTL, ArrowLeft increases progress (moves right-to-left) and ArrowRight decreases
    if (e.key === 'ArrowLeft' || e.key === 'ArrowUp') {
      e.preventDefault();
      onChange(Math.min(safeMax, clampedValue + jump));
    } else if (e.key === 'ArrowRight' || e.key === 'ArrowDown') {
      e.preventDefault();
      onChange(Math.max(min, clampedValue - jump));
    }
  };

  const thumbSize = isDragging ? 18 : 15;
  const thumbHalf = thumbSize / 2;

  return (
    <div
      ref={railRef}
      dir="rtl"
      role="slider"
      tabIndex={0}
      aria-label={ariaLabel}
      aria-valuemin={min}
      aria-valuemax={Math.round(safeMax)}
      aria-valuenow={Math.round(clampedValue)}
      onPointerDown={handlePointerDown}
      onPointerMove={handlePointerMove}
      onPointerUp={handlePointerUp}
      onPointerCancel={handlePointerUp}
      onKeyDown={handleKeyDown}
      className="relative w-full h-9 flex items-center cursor-pointer select-none touch-none focus:outline-none group"
    >
      {/* Glass Track Rail */}
      <div
        className="relative w-full h-[7px] rounded-full transition-all duration-200 group-hover:h-[8px]"
        style={{
          backgroundColor: 'rgba(255, 255, 255, 0.22)',
          boxShadow:
            'inset 0 1px 2px rgba(0, 0, 0, 0.65), 0 0 0 1px rgba(255, 255, 255, 0.1)',
        }}
      >
        {/* Active Filled Bar (Grows from Right to Left: right-0) */}
        <div
          className="absolute inset-y-0 right-0 rounded-full"
          style={{
            width: `${percentage}%`,
            background: `linear-gradient(270deg, ${activeGlow} 0%, ${accentColor} 100%)`,
            boxShadow: `0 0 14px ${accentColor}99`,
          }}
        />

        {/* Perfectly Centered Thumb Circle (الدايره) moving Right to Left */}
        <motion.div
          className="pointer-events-none rounded-full"
          style={{
            position: 'absolute',
            top: '50%',
            right: `${percentage}%`,
            width: `${thumbSize}px`,
            height: `${thumbSize}px`,
            marginTop: `-${thumbHalf}px`,
            marginRight: `-${thumbHalf}px`,
            scale: thumbScale,
            backgroundColor: accentColor,
            border: '2.5px solid #FFFFFF',
            boxShadow: isDragging
              ? `0 0 20px 4px ${accentColor}, 0 2px 8px rgba(0,0,0,0.9)`
              : `0 0 12px 2px ${accentColor}cc, 0 2px 6px rgba(0,0,0,0.85)`,
            filter: isDragging ? 'blur(0.3px)' : 'blur(0px)',
          }}
        />
      </div>
    </div>
  );
}
