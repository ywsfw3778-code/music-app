import { Check, ListMusic, Plus, Search, X } from 'lucide-react';
import { AnimatePresence, motion } from 'motion/react';
import { useEffect, useMemo, useState } from 'react';
import type { Translations } from '../i18n/translations';
import type { Playlist, Track } from '../types/music';
import { formatDuration } from '../utils/smartFilter';
import { ArtworkTile } from './ArtworkTile';

interface CreatePlaylistModalProps {
  isOpen: boolean;
  editingPlaylist: Playlist | null;
  tracks: Track[];
  playlistsCount: number;
  accentColor: string;
  onClose: () => void;
  onSaveNewPlaylist: (name: string, trackIds: string[]) => void;
  onToggleTrackInExistingPlaylist: (playlistId: string, trackId: string) => void;
  t: Translations;
}

export function CreatePlaylistModal({
  isOpen,
  editingPlaylist,
  tracks,
  playlistsCount,
  accentColor,
  onClose,
  onSaveNewPlaylist,
  onToggleTrackInExistingPlaylist,
  t,
}: CreatePlaylistModalProps) {
  const [name, setName] = useState('');
  const [selectedTrackIds, setSelectedTrackIds] = useState<string[]>([]);
  const [searchQuery, setSearchQuery] = useState('');

  useEffect(() => {
    if (isOpen) {
      if (editingPlaylist) {
        setName(editingPlaylist.name);
        setSelectedTrackIds(editingPlaylist.trackIds);
      } else {
        setName('');
        setSelectedTrackIds([]);
      }
      setSearchQuery('');
    }
  }, [isOpen, editingPlaylist]);

  // Keep selectedTrackIds in sync if editing an existing playlist
  useEffect(() => {
    if (editingPlaylist) {
      setSelectedTrackIds(editingPlaylist.trackIds);
    }
  }, [editingPlaylist?.trackIds]);

  const orderedTracks = useMemo(() => {
    const active = tracks.filter((tr) => tr.exclusionReason === null);
    const q = searchQuery.trim().toLowerCase();
    if (!q) return active;
    return active.filter(
      (tr) =>
        tr.title.toLowerCase().includes(q) ||
        tr.artist.toLowerCase().includes(q) ||
        tr.album.toLowerCase().includes(q) ||
        tr.fileName.toLowerCase().includes(q)
    );
  }, [tracks, searchQuery]);

  const handleToggleTrack = (trackId: string) => {
    if (editingPlaylist) {
      onToggleTrackInExistingPlaylist(editingPlaylist.id, trackId);
      setSelectedTrackIds((prev) =>
        prev.includes(trackId) ? prev.filter((id) => id !== trackId) : [...prev, trackId]
      );
    } else {
      setSelectedTrackIds((prev) =>
        prev.includes(trackId) ? prev.filter((id) => id !== trackId) : [...prev, trackId]
      );
    }
  };

  const handleSave = () => {
    if (editingPlaylist) {
      onClose();
      return;
    }
    const finalName = name.trim() || `${t.tabPlaylists} #${playlistsCount + 1}`;
    onSaveNewPlaylist(finalName, selectedTrackIds);
    onClose();
  };

  return (
    <AnimatePresence>
      {isOpen && (
        <div
          dir="rtl"
          className="fixed inset-0 z-50 flex items-end sm:items-center justify-center p-2.5 sm:p-4"
        >
          {/* Clear Unblurred / Light Backdrop */}
          <motion.button
            key="playlist-modal-backdrop"
            type="button"
            aria-label={t.close}
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.16 }}
            onClick={onClose}
            className="fixed inset-0 bg-black/45 cursor-default"
          />

          {/* Transparent + 20% Light Blur Modal Sheet */}
          <motion.div
            key="playlist-modal-card"
            initial={{ opacity: 0, y: 36, scale: 0.96 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 28, scale: 0.96 }}
            transition={{
              type: 'spring',
              stiffness: 520,
              damping: 36,
              mass: 0.65,
            }}
            className="relative z-10 w-full max-w-lg max-h-[86vh] flex flex-col rounded-3xl overflow-hidden"
            style={{
              backgroundColor: 'rgba(18, 18, 20, 0.55)',
              backdropFilter: 'blur(4px)',
              WebkitBackdropFilter: 'blur(4px)',
              boxShadow: '0 24px 48px -12px rgba(0, 0, 0, 0.8)',
            }}
          >
            {/* Modal Header */}
            <div className="p-4 sm:p-5 space-y-3.5 shrink-0">
              <div className="flex items-center justify-between gap-3">
                <div className="flex items-center gap-2.5 min-w-0">
                  <div
                    className="w-9 h-9 rounded-xl flex items-center justify-center shrink-0"
                    style={{ backgroundColor: `${accentColor}22` }}
                  >
                    <ListMusic size={18} style={{ color: accentColor }} />
                  </div>
                  <div className="min-w-0">
                    <h2 className="text-base font-extrabold text-white truncate">
                      {editingPlaylist ? editingPlaylist.name : t.createPlaylist}
                    </h2>
                    <p className="text-[11px] text-slate-300 truncate">
                      {t.playlistBuilderHint}
                    </p>
                  </div>
                </div>

                <div className="flex items-center gap-2 shrink-0">
                  <motion.button
                    type="button"
                    whileTap={{ scale: 0.94 }}
                    onClick={handleSave}
                    className="min-h-[38px] px-4 rounded-xl text-xs font-bold text-black flex items-center gap-1.5"
                    style={{ backgroundColor: accentColor }}
                  >
                    <Check size={15} strokeWidth={2.6} />
                    <span>
                      {t.savePlaylist} ({selectedTrackIds.length})
                    </span>
                  </motion.button>

                  <button
                    type="button"
                    onClick={onClose}
                    aria-label={t.close}
                    className="w-9 h-9 rounded-xl bg-white/[0.06] hover:bg-white/[0.12] flex items-center justify-center text-slate-300 hover:text-white transition-colors"
                  >
                    <X size={17} />
                  </button>
                </div>
              </div>

              {/* Playlist Name Input */}
              {!editingPlaylist && (
                <input
                  type="text"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  onKeyDown={(e) => {
                    if (e.key === 'Enter') handleSave();
                  }}
                  placeholder={t.playlistNamePlaceholder}
                  autoFocus
                  className="w-full min-h-[44px] px-4 rounded-2xl bg-white/[0.06] text-sm font-semibold text-white placeholder:text-slate-400 focus:outline-none focus:bg-white/[0.09] transition-colors"
                />
              )}

              {/* Quick Search Track Filter */}
              <div className="relative">
                <Search
                  size={15}
                  className="absolute top-1/2 -translate-y-1/2 right-3.5 text-slate-400 pointer-events-none"
                />
                <input
                  type="search"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  placeholder={t.searchPlaceholder}
                  className="w-full min-h-[38px] pr-9 pl-3.5 rounded-xl bg-white/[0.045] text-xs text-white placeholder:text-slate-400 focus:outline-none focus:bg-white/[0.08]"
                />
              </div>
            </div>

            {/* Ordered List of All Loaded Songs with (+) Button */}
            <div className="flex-1 overflow-y-auto no-scrollbar p-2.5 sm:p-3 space-y-1">
              {orderedTracks.length === 0 ? (
                <div className="py-12 text-center text-xs text-slate-400">
                  {t.noSearchResults}
                </div>
              ) : (
                orderedTracks.map((track, idx) => {
                  const isAdded = selectedTrackIds.includes(track.id);
                  return (
                    <div
                      key={track.id}
                      onClick={() => handleToggleTrack(track.id)}
                      className={`flex items-center gap-3 py-2 px-2.5 rounded-2xl cursor-pointer transition-colors ${
                        isAdded ? 'bg-white/[0.1]' : 'hover:bg-white/[0.05]'
                      }`}
                    >
                      <span className="w-6 text-center text-[11px] font-mono-tabular text-slate-400 shrink-0">
                        {idx + 1}
                      </span>

                      <ArtworkTile
                        coverUrl={track.coverUrl}
                        title={track.title}
                        accentColor={accentColor}
                        sizeClass="w-11 h-11"
                        roundedClass="rounded-xl"
                      />

                      <div className="min-w-0 flex-1">
                        <p
                          className="text-[13.5px] font-semibold truncate leading-snug"
                          style={{ color: isAdded ? accentColor : '#F8FAFC' }}
                        >
                          {track.title}
                        </p>
                        <p className="text-[11.5px] text-slate-400 truncate mt-0.5 flex items-center gap-1.5">
                          <span className="truncate">{track.artist}</span>
                          <span className="opacity-50 shrink-0">·</span>
                          <span dir="ltr" className="font-mono-tabular shrink-0">
                            {formatDuration(track.duration)}
                          </span>
                        </p>
                      </div>

                      <motion.button
                        type="button"
                        whileTap={{ scale: 0.84 }}
                        onClick={(e) => {
                          e.stopPropagation();
                          handleToggleTrack(track.id);
                        }}
                        aria-label={isAdded ? t.removeFromPlaylist : t.addToPlaylist}
                        className={`w-9 h-9 rounded-full flex items-center justify-center shrink-0 transition-colors ${
                          isAdded
                            ? 'text-black font-bold shadow-sm'
                            : 'bg-white/[0.07] text-white hover:bg-white/[0.15]'
                        }`}
                        style={isAdded ? { backgroundColor: accentColor } : undefined}
                      >
                        {isAdded ? <Check size={16} strokeWidth={2.8} /> : <Plus size={18} />}
                      </motion.button>
                    </div>
                  );
                })
              )}
            </div>
          </motion.div>
        </div>
      )}
    </AnimatePresence>
  );
}
