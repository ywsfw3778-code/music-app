import { CheckCircle2, Globe, Plus, RefreshCw, ShieldCheck, Sliders, Smartphone, Sparkles, Trash2, Waves, X } from 'lucide-react';
import { motion } from 'motion/react';
import { useEffect, useState } from 'react';
import type { Translations } from '../i18n/translations';
import type { AppSettings, ArtworkBackgroundMode, Language } from '../types/music';
import { nativeApkBridge } from '../utils/nativeApkBridge';
import { CustomGlassSlider } from './CustomGlassSlider';

interface SettingsViewProps {
  settings: AppSettings;
  accentColor: string;
  activeTrackCount: number;
  excludedCount: number;
  onUpdateSettings: (patch: Partial<AppSettings>) => void;
  onReapplyFilters: () => void;
  onClearLibrary: () => void;
  t: Translations;
}

export function SettingsView({
  settings,
  accentColor,
  activeTrackCount,
  excludedCount,
  onUpdateSettings,
  onReapplyFilters,
  onClearLibrary,
  t,
}: SettingsViewProps) {
  const [keywordInput, setKeywordInput] = useState('');
  const [confirmClear, setConfirmClear] = useState(false);
  const [permState, setPermState] = useState(() => nativeApkBridge.getSystemPermissionsState());

  useEffect(() => {
    setPermState(nativeApkBridge.getSystemPermissionsState());
    window.__onNativePermissionResult = () => {
      setPermState(nativeApkBridge.getSystemPermissionsState());
    };
    return () => {
      window.__onNativePermissionResult = undefined;
    };
  }, []);

  const handleRequestPhonePermissions = async () => {
    await nativeApkBridge.requestPhoneSystemPermissions();
    setPermState(nativeApkBridge.getSystemPermissionsState());
  };

  const handleAddKeyword = () => {
    const clean = keywordInput.trim();
    if (!clean) return;
    if (!settings.customExcludeKeywords.includes(clean)) {
      onUpdateSettings({
        customExcludeKeywords: [...settings.customExcludeKeywords, clean],
      });
    }
    setKeywordInput('');
  };

  const handleRemoveKeyword = (kw: string) => {
    onUpdateSettings({
      customExcludeKeywords: settings.customExcludeKeywords.filter((item) => item !== kw),
    });
  };

  const containerVariants = {
    hidden: { opacity: 0 },
    show: {
      opacity: 1,
      transition: { staggerChildren: 0.05, delayChildren: 0.02 },
    },
  };

  const sectionVariants = {
    hidden: { opacity: 0, y: 14, scale: 0.985 },
    show: {
      opacity: 1,
      y: 0,
      scale: 1,
      transition: { type: 'spring' as const, stiffness: 460, damping: 32 },
    },
  };

  return (
    <motion.div
      dir="rtl"
      variants={containerVariants}
      initial="hidden"
      animate="show"
      className="px-4 pt-6 pb-40 max-w-md mx-auto space-y-5"
    >
      <motion.header variants={sectionVariants}>
        <h1 className="text-3xl sm:text-4xl font-extrabold tracking-tight text-white">
          {t.settingsTitle}
        </h1>
        <p className="text-sm text-slate-400 mt-1">{t.settingsSubtitle}</p>
      </motion.header>

      {/* 1. Language Section (Layout remains fixed RTL regardless of language) */}
      <motion.section variants={sectionVariants} className="p-5 rounded-2xl matte-card space-y-4">
        <div className="flex items-center gap-2.5">
          <Globe size={18} style={{ color: accentColor }} />
          <h2 className="text-base font-bold text-white">{t.languageSection}</h2>
        </div>

        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div>
            <p className="text-sm font-semibold text-slate-100">{t.languageLabel}</p>
            <p className="text-xs text-slate-400 mt-0.5">{t.languageDesc}</p>
          </div>

          <div className="flex items-center gap-1 p-1 rounded-xl bg-white/[0.04] shrink-0">
            {(['ar', 'en'] as Language[]).map((lang) => {
              const active = settings.language === lang;
              return (
                <button
                  key={lang}
                  type="button"
                  onClick={() => onUpdateSettings({ language: lang })}
                  className={`relative min-h-[38px] px-4 rounded-lg text-xs font-bold transition-all whitespace-nowrap ${
                    active ? 'text-black' : 'text-slate-300 hover:text-white'
                  }`}
                >
                  {active && (
                    <motion.div
                      layoutId="settings-lang-pill"
                      transition={{ type: 'spring', stiffness: 480, damping: 34 }}
                      className="absolute inset-0 rounded-lg"
                      style={{ backgroundColor: accentColor }}
                    />
                  )}
                  <span className="relative z-10">{lang === 'ar' ? 'العربية' : 'English'}</span>
                </button>
              );
            })}
          </div>
        </div>
      </motion.section>

      {/* Native Phone System Permissions & Realme 11 System Capsule Integration */}
      <motion.section variants={sectionVariants} className="p-5 rounded-2xl matte-card space-y-4">
        <div className="flex items-center justify-between gap-3">
          <div className="flex items-center gap-2.5">
            <Smartphone size={18} style={{ color: accentColor }} />
            <h2 className="text-base font-bold text-white">
              {settings.language === 'ar'
                ? 'صلاحيات الهاتف وكبسولة النظام (System Mini Capsule)'
                : 'Phone System Permissions & System Mini Capsule'}
            </h2>
          </div>
          <span
            className="px-2.5 py-0.5 rounded-full text-[10px] font-bold text-black"
            style={{ backgroundColor: accentColor }}
          >
            System Native
          </span>
        </div>

        <p className="text-xs text-slate-400 leading-relaxed">
          {settings.language === 'ar'
            ? 'يرتبط المشغل مباشرة بنظام أندرويد وكبسولة الهاتف الأصلية (Realme 11 Mini Capsule) عبر صلاحيات الإشعارات وجلسة الوسائط الخلفية بدون رسم كبسولة وهمية داخل التطبيق.'
            : 'Connects directly to Android and your phone’s native system Mini Capsule via notification and foreground media session permissions.'}
        </p>

        <div className="space-y-2 rounded-xl bg-white/[0.04] p-3.5 text-xs">
          <div className="flex items-center justify-between gap-2">
            <span className="text-slate-200">
              {settings.language === 'ar'
                ? 'صلاحية الإشعارات وكبسولة النظام (POST_NOTIFICATIONS)'
                : 'System Notification & Capsule Permission'}
            </span>
            <span
              className={`flex items-center gap-1 font-bold ${
                permState.notificationsGranted ? 'text-emerald-400' : 'text-amber-300'
              }`}
            >
              <CheckCircle2 size={14} />
              <span>
                {permState.notificationsGranted
                  ? settings.language === 'ar'
                    ? 'ممنوحة'
                    : 'Granted'
                  : settings.language === 'ar'
                  ? 'بانتظار التفعيل'
                  : 'Needs Grant'}
              </span>
            </span>
          </div>

          <div className="flex items-center justify-between gap-2">
            <span className="text-slate-200">
              {settings.language === 'ar'
                ? 'خدمة الوسائط الخلفية (MediaSessionCompat + MediaStyle)'
                : 'Foreground MediaSessionCompat + MediaStyle'}
            </span>
            <span className="flex items-center gap-1 text-emerald-400 font-bold">
              <CheckCircle2 size={14} />
              <span>
                {permState.mediaSessionActive
                  ? settings.language === 'ar'
                    ? 'متصل بالنظام'
                    : 'System Linked'
                  : 'Active'}
              </span>
            </span>
          </div>
        </div>

        <div className="pt-1 flex flex-col sm:flex-row gap-2.5">
          <button
            type="button"
            onClick={() => void handleRequestPhonePermissions()}
            style={{ backgroundColor: accentColor }}
            className="flex-1 min-h-[44px] px-4 rounded-xl text-xs font-bold text-black flex items-center justify-center gap-2 shadow-md active:scale-[0.99] transition-transform"
          >
            <ShieldCheck size={16} />
            <span>
              {settings.language === 'ar'
                ? 'منح صلاحيات الهاتف وتفعيل كبسولة النظام'
                : 'Grant Phone Permissions & Enable System Capsule'}
            </span>
          </button>

          {permState.nativeServiceConnected && (
            <button
              type="button"
              onClick={() => nativeApkBridge.openPhoneCapsuleSettings()}
              className="min-h-[44px] px-4 rounded-xl bg-white/[0.08] hover:bg-white/[0.14] text-xs font-bold text-white flex items-center justify-center gap-2 transition-colors"
            >
              <span>
                {settings.language === 'ar' ? 'إعدادات إشعارات الهاتف' : 'Phone Notification Settings'}
              </span>
            </button>
          )}
        </div>

        <div className="pt-1">
          <a
            href="./sukoon-android-apk-project.zip"
            download="sukoon-android-apk-project.zip"
            className="w-full min-h-[44px] px-4 rounded-xl bg-white/[0.08] hover:bg-white/[0.14] text-xs font-bold text-white flex items-center justify-center gap-2 transition-colors"
          >
            <Smartphone size={16} style={{ color: accentColor }} />
            <span>
              {settings.language === 'ar'
                ? 'تحميل حزمة مشروع الأندرويد الكاملة (sukoon-android-apk-project.zip)'
                : 'Download Full Android Studio APK Project (.zip)'}
            </span>
          </a>
        </div>
      </motion.section>

      {/* 2. Crossfade Engine Section */}
      <motion.section variants={sectionVariants} className="p-5 rounded-2xl matte-card space-y-5">
        <div className="flex items-center gap-2.5">
          <Waves size={18} style={{ color: accentColor }} />
          <h2 className="text-base font-bold text-white">{t.crossfadeSection}</h2>
        </div>

        <div className="flex items-center justify-between gap-4">
          <div className="min-w-0">
            <p className="text-sm font-semibold text-slate-100">{t.crossfadeToggle}</p>
            <p className="text-xs text-slate-400 mt-0.5 leading-relaxed">{t.crossfadeDesc}</p>
          </div>

          <button
            type="button"
            role="switch"
            aria-checked={settings.crossfadeEnabled}
            onClick={() => onUpdateSettings({ crossfadeEnabled: !settings.crossfadeEnabled })}
            className="relative w-14 h-8 rounded-full transition-colors shrink-0 p-1 flex items-center"
            style={{
              backgroundColor: settings.crossfadeEnabled
                ? accentColor
                : 'rgba(255, 255, 255, 0.14)',
            }}
          >
            <motion.span
              animate={{ x: settings.crossfadeEnabled ? -24 : 0 }}
              transition={{ type: 'spring', stiffness: 500, damping: 32 }}
              className="w-6 h-6 rounded-full bg-black shadow-md block"
            />
          </button>
        </div>

        <div
          className={`space-y-3 pt-3 border-t border-white/[0.06] transition-opacity ${
            settings.crossfadeEnabled ? 'opacity-100' : 'opacity-45 pointer-events-none'
          }`}
        >
          <div className="flex items-center justify-between text-sm">
            <span className="text-slate-100 font-semibold">{t.crossfadeDuration}</span>
            <span className="font-bold flex items-center gap-1" style={{ color: accentColor }}>
              <span dir="ltr" className="font-mono-tabular">
                {settings.crossfadeSeconds}
              </span>
              <span>{t.secondsUnit}</span>
            </span>
          </div>

          <CustomGlassSlider
            min={1}
            max={12}
            step={1}
            value={settings.crossfadeSeconds}
            accentColor={accentColor}
            onChange={(val) => onUpdateSettings({ crossfadeSeconds: Math.round(val) })}
            ariaLabel={t.crossfadeDuration}
          />

          <div className="flex flex-wrap gap-2 pt-1">
            {[2, 4, 6, 8, 10, 12].map((sec) => {
              const active = settings.crossfadeSeconds === sec;
              return (
                <button
                  key={sec}
                  type="button"
                  onClick={() => onUpdateSettings({ crossfadeSeconds: sec })}
                  className={`min-h-[36px] px-3.5 rounded-xl text-xs font-mono-tabular transition-all ${
                    active
                      ? 'bg-white/20 text-white font-bold'
                      : 'bg-white/[0.05] text-slate-300 hover:bg-white/[0.1] hover:text-white'
                  }`}
                >
                  {sec}s
                </button>
              );
            })}
          </div>
        </div>
      </motion.section>

      {/* 3. Smart Auto-Filtering Section */}
      <motion.section variants={sectionVariants} className="p-5 rounded-2xl matte-card space-y-5">
        <div className="flex items-center gap-2.5">
          <Sliders size={18} style={{ color: accentColor }} />
          <h2 className="text-base font-bold text-white">{t.filterSection}</h2>
        </div>

        {/* Toggle Voice & Call Recordings */}
        <div className="flex items-center justify-between gap-4">
          <div className="min-w-0">
            <p className="text-sm font-semibold text-slate-100">{t.autoExcludeRecordings}</p>
            <p className="text-xs text-slate-400 mt-0.5 leading-relaxed">
              {t.autoExcludeRecordingsDesc}
            </p>
          </div>

          <button
            type="button"
            role="switch"
            aria-checked={settings.autoExcludeRecordings}
            onClick={() =>
              onUpdateSettings({ autoExcludeRecordings: !settings.autoExcludeRecordings })
            }
            className="relative w-14 h-8 rounded-full transition-colors shrink-0 p-1 flex items-center"
            style={{
              backgroundColor: settings.autoExcludeRecordings
                ? accentColor
                : 'rgba(255, 255, 255, 0.14)',
            }}
          >
            <motion.span
              animate={{ x: settings.autoExcludeRecordings ? -24 : 0 }}
              transition={{ type: 'spring', stiffness: 500, damping: 32 }}
              className="w-6 h-6 rounded-full bg-black shadow-md block"
            />
          </button>
        </div>

        {/* Short Audio Threshold */}
        <div className="space-y-3 pt-3 border-t border-white/[0.06]">
          <div className="flex items-center justify-between gap-3">
            <div>
              <p className="text-sm font-semibold text-slate-100">{t.minDurationLabel}</p>
              <p className="text-xs text-slate-400 mt-0.5">{t.minDurationDesc}</p>
            </div>
            <span
              className="text-sm font-bold shrink-0 flex items-center gap-1"
              style={{ color: accentColor }}
            >
              <span dir="ltr" className="font-mono-tabular">
                &lt; {settings.minDurationSeconds}
              </span>
              <span>{t.secondsUnit}</span>
            </span>
          </div>

          <CustomGlassSlider
            min={10}
            max={120}
            step={5}
            value={settings.minDurationSeconds}
            accentColor={accentColor}
            onChange={(val) => onUpdateSettings({ minDurationSeconds: Math.round(val) })}
            ariaLabel={t.minDurationLabel}
          />

          <div className="flex flex-wrap gap-2">
            {[15, 30, 45, 60, 90].map((sec) => {
              const active = settings.minDurationSeconds === sec;
              return (
                <button
                  key={sec}
                  type="button"
                  onClick={() => onUpdateSettings({ minDurationSeconds: sec })}
                  className={`min-h-[36px] px-3.5 rounded-xl text-xs font-mono-tabular transition-all ${
                    active
                      ? 'bg-white/20 text-white font-bold'
                      : 'bg-white/[0.05] text-slate-300 hover:bg-white/[0.1] hover:text-white'
                  }`}
                >
                  {sec}s
                </button>
              );
            })}
          </div>
        </div>

        {/* Custom Exclude Keywords */}
        <div className="space-y-3 pt-3 border-t border-white/[0.06]">
          <p className="text-sm font-semibold text-slate-100">{t.customKeywordsLabel}</p>
          <div className="flex gap-2">
            <input
              type="text"
              value={keywordInput}
              onChange={(e) => setKeywordInput(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === 'Enter') handleAddKeyword();
              }}
              placeholder={t.customKeywordsPlaceholder}
              className="flex-1 min-h-[44px] px-3.5 rounded-xl bg-white/[0.045] text-sm text-white placeholder:text-slate-500 focus:outline-none focus:bg-white/[0.08]"
            />
            <button
              type="button"
              onClick={handleAddKeyword}
              className="min-h-[44px] px-4 rounded-xl bg-white/[0.08] hover:bg-white/[0.14] text-xs font-bold text-white flex items-center gap-1.5 shrink-0"
            >
              <Plus size={14} style={{ color: accentColor }} />
              <span>{t.addKeyword}</span>
            </button>
          </div>

          {settings.customExcludeKeywords.length > 0 && (
            <div className="flex flex-wrap gap-2 pt-1">
              {settings.customExcludeKeywords.map((kw) => (
                <button
                  key={kw}
                  type="button"
                  onClick={() => handleRemoveKeyword(kw)}
                  className="min-h-[34px] px-3 rounded-xl bg-white/[0.06] text-xs text-slate-100 flex items-center gap-1.5 hover:bg-rose-500/20 transition-colors"
                >
                  <span>{kw}</span>
                  <X size={13} className="text-slate-400" />
                </button>
              ))}
            </div>
          )}
        </div>
      </motion.section>

      {/* 4. Super AMOLED Appearance */}
      <motion.section variants={sectionVariants} className="p-5 rounded-2xl matte-card space-y-5">
        <div className="flex items-center gap-2.5">
          <Sparkles size={18} style={{ color: accentColor }} />
          <h2 className="text-base font-bold text-white">{t.appearanceSection}</h2>
        </div>

        <div className="flex items-center justify-between gap-4">
          <div className="min-w-0">
            <p className="text-sm font-semibold text-slate-100">{t.dynamicAccentLabel}</p>
            <p className="text-xs text-slate-400 mt-0.5">{t.dynamicAccentDesc}</p>
          </div>

          <button
            type="button"
            role="switch"
            aria-checked={settings.dynamicArtworkAccent}
            onClick={() =>
              onUpdateSettings({ dynamicArtworkAccent: !settings.dynamicArtworkAccent })
            }
            className="relative w-14 h-8 rounded-full transition-colors shrink-0 p-1 flex items-center"
            style={{
              backgroundColor: settings.dynamicArtworkAccent
                ? accentColor
                : 'rgba(255, 255, 255, 0.14)',
            }}
          >
            <motion.span
              animate={{ x: settings.dynamicArtworkAccent ? -24 : 0 }}
              transition={{ type: 'spring', stiffness: 500, damping: 32 }}
              className="w-6 h-6 rounded-full bg-black shadow-md block"
            />
          </button>
        </div>

        {/* Blurred Artwork Background Mode Selector (Full App / Partial / Off) */}
        <div className="space-y-3 pt-3 border-t border-white/[0.06]">
          <div>
            <p className="text-sm font-semibold text-slate-100">{t.artworkBgLabel}</p>
            <p className="text-xs text-slate-400 mt-0.5">{t.artworkBgDesc}</p>
          </div>

          <div className="grid grid-cols-3 gap-2 p-1 rounded-xl bg-white/[0.04]">
            {(
              [
                { id: 'full', label: t.artworkBgFull },
                { id: 'partial', label: t.artworkBgPartial },
                { id: 'off', label: t.artworkBgOff },
              ] as Array<{ id: ArtworkBackgroundMode; label: string }>
            ).map((option) => {
              const currentMode = settings.artworkBackgroundMode || 'full';
              const active = currentMode === option.id;
              return (
                <button
                  key={option.id}
                  type="button"
                  onClick={() => onUpdateSettings({ artworkBackgroundMode: option.id })}
                  className={`relative min-h-[40px] px-3 py-2 rounded-lg text-xs font-bold transition-all whitespace-nowrap ${
                    active ? 'text-black' : 'text-slate-300 hover:text-white'
                  }`}
                >
                  {active && (
                    <motion.div
                      layoutId="artwork-bg-mode-pill"
                      transition={{ type: 'spring', stiffness: 480, damping: 34 }}
                      className="absolute inset-0 rounded-lg"
                      style={{ backgroundColor: accentColor }}
                    />
                  )}
                  <span className="relative z-10">{option.label}</span>
                </button>
              );
            })}
          </div>
        </div>
      </motion.section>

      {/* 5. Local Storage & Actions */}
      <motion.section variants={sectionVariants} className="p-5 rounded-2xl matte-card space-y-4">
        <div className="flex items-center justify-between gap-2">
          <h2 className="text-base font-bold text-white">{t.storageSection}</h2>
          <span className="text-xs text-slate-400">
            {t.libraryStats
              .replace('{songs}', String(activeTrackCount))
              .replace('{excluded}', String(excludedCount))}
          </span>
        </div>

        <div className="flex flex-col sm:flex-row gap-3">
          <motion.button
            whileTap={{ scale: 0.97 }}
            type="button"
            onClick={onReapplyFilters}
            className="flex-1 min-h-[46px] px-4 rounded-xl bg-white/[0.07] hover:bg-white/[0.12] text-xs font-bold text-white flex items-center justify-center gap-2 transition-colors"
          >
            <RefreshCw size={15} style={{ color: accentColor }} />
            <span>{t.rescanFilters}</span>
          </motion.button>

          {!confirmClear ? (
            <motion.button
              whileTap={{ scale: 0.97 }}
              type="button"
              onClick={() => setConfirmClear(true)}
              className="flex-1 min-h-[46px] px-4 rounded-xl bg-rose-500/12 hover:bg-rose-500/20 text-xs font-bold text-rose-300 flex items-center justify-center gap-2 transition-colors"
            >
              <Trash2 size={15} />
              <span>{t.clearLibrary}</span>
            </motion.button>
          ) : (
            <div className="flex-1 flex gap-2">
              <button
                type="button"
                onClick={() => {
                  setConfirmClear(false);
                  onClearLibrary();
                }}
                className="flex-1 min-h-[46px] px-3 rounded-xl bg-rose-600 text-xs font-bold text-white"
              >
                {t.confirmDelete}
              </button>
              <button
                type="button"
                onClick={() => setConfirmClear(false)}
                className="min-h-[46px] px-4 rounded-xl bg-white/[0.08] text-xs font-semibold text-slate-200"
              >
                {t.cancel}
              </button>
            </div>
          )}
        </div>
      </motion.section>
    </motion.div>
  );
}
