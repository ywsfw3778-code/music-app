import { Disc3 } from 'lucide-react';
import { useState } from 'react';
import { getFallbackPaletteForSeed } from '../utils/audioMetadata';

interface ArtworkTileProps {
  coverUrl?: string;
  title: string;
  accentColor?: string;
  sizeClass?: string;
  roundedClass?: string;
  iconSize?: number;
  isPlaying?: boolean;
}

export function ArtworkTile({
  coverUrl,
  title,
  accentColor,
  sizeClass = 'w-12 h-12',
  roundedClass = 'rounded-xl',
  iconSize = 20,
  isPlaying = false,
}: ArtworkTileProps) {
  const [failed, setFailed] = useState(false);
  const fallbackPalette = getFallbackPaletteForSeed(title || 'Nocturne');
  const activeColor = accentColor || fallbackPalette.accent;

  if (coverUrl && !failed) {
    return (
      <div
        className={`relative shrink-0 overflow-hidden bg-zinc-950 ${sizeClass} ${roundedClass}`}
      >
        <img
          src={coverUrl}
          alt={title}
          referrerPolicy="no-referrer"
          onError={() => setFailed(true)}
          className="w-full h-full object-cover"
        />
        {isPlaying && (
          <div className="absolute inset-0 bg-black/45 backdrop-blur-[1px] flex items-center justify-center">
            <div className="flex items-end gap-[3px] h-4">
              <span
                className="w-[3px] rounded-full animate-pulse"
                style={{
                  height: '65%',
                  backgroundColor: activeColor,
                  boxShadow: `0 0 8px ${activeColor}`,
                }}
              />
              <span
                className="w-[3px] rounded-full animate-pulse"
                style={{
                  height: '100%',
                  backgroundColor: activeColor,
                  boxShadow: `0 0 8px ${activeColor}`,
                  animationDelay: '150ms',
                }}
              />
              <span
                className="w-[3px] rounded-full animate-pulse"
                style={{
                  height: '45%',
                  backgroundColor: activeColor,
                  boxShadow: `0 0 8px ${activeColor}`,
                  animationDelay: '300ms',
                }}
              />
            </div>
          </div>
        )}
      </div>
    );
  }

  return (
    <div
      className={`relative shrink-0 overflow-hidden flex items-center justify-center ${sizeClass} ${roundedClass}`}
      style={{
        background: `radial-gradient(circle at 28% 22%, ${fallbackPalette.accent}44 0%, ${fallbackPalette.glow}22 45%, rgba(12,12,16,0.96) 85%)`,
      }}
    >
      <Disc3
        size={iconSize}
        style={{
          color: isPlaying ? activeColor : fallbackPalette.accent,
          filter: isPlaying ? `drop-shadow(0 0 8px ${activeColor})` : 'none',
        }}
        className={isPlaying ? 'animate-spin' : 'opacity-85'}
      />
    </div>
  );
}
