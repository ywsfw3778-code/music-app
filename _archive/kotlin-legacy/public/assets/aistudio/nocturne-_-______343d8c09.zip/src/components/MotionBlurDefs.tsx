/**
 * Global SVG Filters:
 * 1. Directional Motion Blur (<feGaussianBlur>) for spring-driven transitions
 * 2. Optical Liquid Glass Refraction (<feTurbulence> + <feDisplacementMap> + <feSpecularLighting>)
 *    modeled after GitHub `liquid-glass-react` / `@developer-hub/liquid-glass`.
 */
export function MotionBlurDefs() {
  return (
    <svg
      aria-hidden="true"
      className="pointer-events-none fixed top-0 left-0 w-0 h-0 overflow-hidden opacity-0"
    >
      <defs>
        {/* Vertical motion blur for sheets, modals, and mini-player */}
        <filter id="motion-blur-vertical" x="-20%" y="-40%" width="140%" height="180%">
          <feGaussianBlur in="SourceGraphic" stdDeviation="0, 12" />
        </filter>

        {/* Subtle vertical motion blur for list/view transitions */}
        <filter id="motion-blur-soft" x="-15%" y="-25%" width="130%" height="150%">
          <feGaussianBlur in="SourceGraphic" stdDeviation="0, 6" />
        </filter>

        {/* Horizontal motion blur for tab & track transitions */}
        <filter id="motion-blur-horizontal" x="-40%" y="-20%" width="180%" height="140%">
          <feGaussianBlur in="SourceGraphic" stdDeviation="10, 0" />
        </filter>

        {/* Apple / GitHub liquid-glass-react Optical Lens Refraction Filter */}
        <filter
          id="apple-liquid-refraction"
          x="-15%"
          y="-15%"
          width="130%"
          height="130%"
          colorInterpolationFilters="sRGB"
        >
          <feTurbulence
            type="fractalNoise"
            baseFrequency="0.014 0.018"
            numOctaves="2"
            seed="5"
            result="noise"
          />
          <feGaussianBlur in="noise" stdDeviation="3.5" result="smoothMap" />
          <feDisplacementMap
            in="SourceGraphic"
            in2="smoothMap"
            scale="16"
            xChannelSelector="R"
            yChannelSelector="G"
            result="refracted"
          />
          <feSpecularLighting
            in="smoothMap"
            surfaceScale="2.5"
            specularConstant="0.75"
            specularExponent="28"
            lightingColor="#ffffff"
            result="specular"
          >
            <fePointLight x="-150" y="-180" z="220" />
          </feSpecularLighting>
          <feComposite
            in="refracted"
            in2="specular"
            operator="arithmetic"
            k1="0"
            k2="1"
            k3="0.14"
            k4="0"
          />
        </filter>
      </defs>
    </svg>
  );
}
