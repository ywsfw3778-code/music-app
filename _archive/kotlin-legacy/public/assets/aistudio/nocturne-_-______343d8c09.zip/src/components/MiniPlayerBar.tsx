import { Pause, Play, SkipBack, X } from 'lucide-react';
import { AnimatePresence, motion } from 'motion/react';
import type { Translations } from '../i18n/translations';
import type { Track } from '../types/music';
import { ArtworkTile } from './ArtworkTile';

interface MiniPlayerBarProps {
  track: Track | null;
  isPlaying: boolean;
  currentTime: number;
  duration: number;
  isCrossfading: boolean;
  accentColor: string;
  glowColor?: string;
  isNowPlayingOpen: boolean;
  onExpand: () => void;
  onTogglePlay: () => void;
  onNext: () => void;
  onStopAndClose: () => void;
  t: Translations;
}

export function MiniPlayerBar({
  track,
  isPlaying,
  currentTime,
  duration,
  isCrossfading,
  accentColor,
  isNowPlayingOpen,
  onExpand,
  onTogglePlay,
  onNext,
  onStopAndClose,
  t,
}: MiniPlayerBarProps) {
  const effectiveDuration = duration > 0 ? duration : track?.duration || 0;
  const progressPct =
    effectiveDuration > 0 ? Math.min(100, Math.max(0, (currentTime / effectiveDuration) * 100)) : 0;

  return (
    <AnimatePresence>
      {track && !isNowPlayingOpen && (
        <motion.div
          key="mini-player-bar"
          dir="rtl"
          initial={{ opacity: 0, y: 40, scale: 0.92 }}
          animate={{ opacity: 1, y: 0, scale: 1 }}
          exit={{ opacity: 0, y: 30, scale: 0.94 }}
          transition={{
            type: 'spring',
            stiffness: 500,
            damping: 35,
            mass: 0.7,
          }}
          drag="y"
          dragConstraints={{ top: 0, bottom: 0 }}
          dragElastic={0.25}
          onDragEnd={(_, info) => {
            if (info.offset.y < -28) {
              onExpand();
            } else if (info.offset.y > 45) {
              onStopAndClose();
            }
          }}
          className="fixed bottom-[76px] inset-x-3.5 z-40 mx-auto max-w-md touch-none"
          style={{ top: 'auto', bottom: 'calc(max(14px, env(safe-area-inset-bottom, 14px)) + 64px)' }}
        >
          <div className="water-drop-bar rounded-[26px] overflow-hidden">
            <div className="flex items-center gap-3 px-3.5 py-2 min-h-[60px]">
              {/* Expand trigger area with shared layoutId artwork & animated track text */}
              <button
                type="button"
                onClick={onExpand}
                aria-label={t.openMiniPlayerHint}
                className="flex items-center gap-3 flex-1 min-w-0 text-start min-h-[46px]"
              >
                <motion.div
                  layoutId="active-player-artwork"
                  transition={{ type: 'spring', stiffness: 420, damping: 34 }}
                  className="shrink-0"
                >
                  <ArtworkTile
                    coverUrl={track.coverUrl}
                    title={track.title}
                    accentColor={accentColor}
                    sizeClass="w-11 h-11"
                    roundedClass="rounded-xl"
                    iconSize={18}
                    isPlaying={isPlaying}
                  />
                </motion.div>

                <div className="min-w-0 flex-1 overflow-hidden">
                  <AnimatePresence mode="wait" initial={false}>
                    <motion.div
                      key={track.id}
                      initial={{ opacity: 0, y: 10 }}
                      animate={{ opacity: 1, y: 0 }}
                      exit={{ opacity: 0, y: -10 }}
                      transition={{ type: 'spring', stiffness: 520, damping: 34 }}
                    >
                      <p className="text-[13.5px] font-bold text-white truncate leading-tight">
                        {track.title}
                      </p>
                      <p
                        className="text-[11.5px] font-medium truncate leading-tight mt-0.5 transition-colors"
                        style={{
                          color: isCrossfading ? accentColor : '#94A3B8',
                        }}
                      >
                        {isCrossfading ? t.crossfadeActive : track.artist}
                      </p>
                    </motion.div>
                  </AnimatePresence>
                </div>
              </button>

              {/* Tactile Spring Transport Controls */}
              <div className="flex items-center gap-1 shrink-0">
                <motion.button
                  type="button"
                  whileTap={{ scale: 0.85 }}
                  onClick={(e) => {
                    e.stopPropagation();
                    onTogglePlay();
                  }}
                  aria-label={isPlaying ? 'Pause' : 'Play'}
                  className="w-10 h-10 flex items-center justify-center rounded-full text-black"
                  style={{ backgroundColor: accentColor }}
                >
                  <AnimatePresence mode="wait" initial={false}>
                    <motion.span
                      key={isPlaying ? 'pause' : 'play'}
                      initial={{ scale: 0.5, opacity: 0, rotate: -30 }}
                      animate={{ scale: 1, opacity: 1, rotate: 0 }}
                      exit={{ scale: 0.5, opacity: 0, rotate: 30 }}
                      transition={{ duration: 0.14 }}
                      className="flex items-center justify-center"
                    >
                      {isPlaying ? (
                        <Pause size={17} fill="currentColor" />
                      ) : (
                        <Play size={17} fill="currentColor" className="translate-x-[1px]" />
                      )}
                    </motion.span>
                  </AnimatePresence>
                </motion.button>

                <motion.button
                  type="button"
                  whileTap={{ scale: 0.85, x: -3 }}
                  onClick={(e) => {
                    e.stopPropagation();
                    onNext();
                  }}
                  aria-label="Next"
                  className="w-9 h-9 flex items-center justify-center rounded-full text-slate-200 hover:bg-white/[0.08]"
                >
                  <SkipBack size={16} fill="currentColor" />
                </motion.button>

                <motion.button
                  type="button"
                  whileTap={{ scale: 0.85 }}
                  onClick={(e) => {
                    e.stopPropagation();
                    onStopAndClose();
                  }}
                  aria-label={t.stopAndClose}
                  className="w-8 h-8 flex items-center justify-center rounded-full text-slate-400 hover:text-white hover:bg-white/[0.08]"
                >
                  <X size={14} />
                </motion.button>
              </div>
            </div>

            {/* Right-to-Left Bottom Progress Bar */}
            <div dir="rtl" className="relative h-[3px] w-full bg-white/[0.08] overflow-hidden">
              <motion.div
                className="absolute right-0 inset-y-0 rounded-full"
                animate={{ width: `${progressPct}%` }}
                transition={{ ease: 'linear', duration: 0.15 }}
                style={{ backgroundColor: accentColor }}
              />
            </div>
          </div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
