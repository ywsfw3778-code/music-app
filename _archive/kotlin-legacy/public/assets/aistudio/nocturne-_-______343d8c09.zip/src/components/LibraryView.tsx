import {
  ArrowRight,
  ArrowUpDown,
  FileAudio,
  FolderOpen,
  Heart,
  ListMusic,
  Loader2,
  MoreHorizontal,
  Play,
  Plus,
  RotateCcw,
  Search,
  Settings2,
  ShieldCheck,
  X,
} from 'lucide-react';
import { motion } from 'motion/react';
import { useMemo, useState } from 'react';
import type { Translations } from '../i18n/translations';
import type { LibraryTab, Playlist, ScanProgress, SortOption, Track } from '../types/music';
import { formatDuration } from '../utils/smartFilter';
import { ArtworkTile } from './ArtworkTile';
import { CreatePlaylistModal } from './CreatePlaylistModal';
import { PlaylistSettingsModal } from './PlaylistSettingsModal';

interface LibraryViewProps {
  mode: 'library' | 'folders';
  tracks: Track[];
  playlists: Playlist[];
  currentTrackId: string | null;
  isPlaying: boolean;
  scanProgress: ScanProgress;
  accentColor: string;
  onPlayTrack: (track: Track, contextTracks?: Track[]) => void;
  onPlayPlaylist: (playlistTracks: Track[]) => void;
  onCreatePlaylist: (name: string, initialTrackIds?: string[]) => string;
  onUpdatePlaylist: (playlistId: string, patch: { name?: string; trackIds?: string[] }) => void;
  onToggleTrackInPlaylist: (playlistId: string, trackId: string) => void;
  onDeletePlaylist: (playlistId: string) => void;
  onRemoveTrackFromPlaylist: (playlistId: string, trackId: string) => void;
  onToggleFavorite: (trackId: string) => void;
  onOpenContextMenu: (track: Track) => void;
  onRestoreTrack: (track: Track) => void;
  onImportFolder: () => void;
  onImportFiles: () => void;
  t: Translations;
}

const kitchenSpring = {
  type: 'spring' as const,
  stiffness: 540,
  damping: 38,
  mass: 0.55,
};

export function LibraryView({
  mode,
  tracks,
  playlists,
  currentTrackId,
  isPlaying,
  scanProgress,
  accentColor,
  onPlayTrack,
  onPlayPlaylist,
  onCreatePlaylist,
  onUpdatePlaylist,
  onToggleTrackInPlaylist,
  onDeletePlaylist,
  onRemoveTrackFromPlaylist,
  onToggleFavorite,
  onOpenContextMenu,
  onRestoreTrack,
  onImportFolder,
  onImportFiles,
  t,
}: LibraryViewProps) {
  const [activeTab, setActiveTab] = useState<LibraryTab>('songs');
  const [searchQuery, setSearchQuery] = useState('');
  const [sortBy, setSortBy] = useState<SortOption>('title');
  const [selectedFolder, setSelectedFolder] = useState<string>('ALL');
  const [selectedPlaylistId, setSelectedPlaylistId] = useState<string | null>(null);

  // Create / Edit Playlist Modal state
  const [isPlaylistModalOpen, setIsPlaylistModalOpen] = useState(false);
  const [editingPlaylistId, setEditingPlaylistId] = useState<string | null>(null);
  const [settingsPlaylistId, setSettingsPlaylistId] = useState<string | null>(null);

  const activeSongs = useMemo(
    () => tracks.filter((tr) => tr.exclusionReason === null),
    [tracks]
  );
  const favoriteSongs = useMemo(
    () => activeSongs.filter((tr) => tr.isFavorite),
    [activeSongs]
  );
  const quarantinedSongs = useMemo(
    () => tracks.filter((tr) => tr.exclusionReason !== null),
    [tracks]
  );

  const selectedPlaylist = useMemo(
    () => playlists.find((p) => p.id === selectedPlaylistId) || null,
    [playlists, selectedPlaylistId]
  );

  const editingPlaylist = useMemo(
    () => playlists.find((p) => p.id === editingPlaylistId) || null,
    [playlists, editingPlaylistId]
  );

  const settingsPlaylist = useMemo(
    () => playlists.find((p) => p.id === settingsPlaylistId) || null,
    [playlists, settingsPlaylistId]
  );

  const foldersList = useMemo(() => {
    const counts = new Map<string, number>();
    for (const tr of activeSongs) {
      const folder = tr.folderPath || '/';
      counts.set(folder, (counts.get(folder) || 0) + 1);
    }
    return Array.from(counts.entries()).sort((a, b) => b[1] - a[1]);
  }, [activeSongs]);

  const displayedTracks = useMemo(() => {
    let source = activeSongs;

    if (mode === 'folders') {
      source =
        selectedFolder === 'ALL'
          ? activeSongs
          : activeSongs.filter((tr) => (tr.folderPath || '/') === selectedFolder);
    } else if (activeTab === 'playlists') {
      if (!selectedPlaylist) return [];
      source = selectedPlaylist.trackIds
        .map((id) => activeSongs.find((tr) => tr.id === id))
        .filter((tr): tr is Track => Boolean(tr));
    } else if (activeTab === 'favorites') {
      source = favoriteSongs;
    } else if (activeTab === 'quarantine') {
      source = quarantinedSongs;
    }

    const q = searchQuery.trim().toLowerCase();
    const filtered = q
      ? source.filter(
          (tr) =>
            tr.title.toLowerCase().includes(q) ||
            tr.artist.toLowerCase().includes(q) ||
            tr.album.toLowerCase().includes(q) ||
            tr.fileName.toLowerCase().includes(q)
        )
      : source;

    // Preserve user's added order inside a playlist unless searching
    if (mode === 'library' && activeTab === 'playlists' && selectedPlaylist) {
      return filtered;
    }

    return [...filtered].sort((a, b) => {
      if (sortBy === 'title') return a.title.localeCompare(b.title);
      if (sortBy === 'artist') return a.artist.localeCompare(b.artist);
      if (sortBy === 'duration') return b.duration - a.duration;
      return b.addedAt - a.addedAt;
    });
  }, [
    mode,
    activeTab,
    activeSongs,
    favoriteSongs,
    quarantinedSongs,
    selectedFolder,
    selectedPlaylist,
    searchQuery,
    sortBy,
  ]);

  const cycleSort = () => {
    const order: SortOption[] = ['title', 'artist', 'duration', 'addedAt'];
    const next = order[(order.indexOf(sortBy) + 1) % order.length];
    setSortBy(next);
  };

  const openNewPlaylistModal = () => {
    setEditingPlaylistId(null);
    setIsPlaylistModalOpen(true);
  };

  const openExistingPlaylistModal = (playlist: Playlist) => {
    setEditingPlaylistId(playlist.id);
    setIsPlaylistModalOpen(true);
  };

  const handleSaveNewPlaylist = (name: string, trackIds: string[]) => {
    const createdId = onCreatePlaylist(name, trackIds);
    setSelectedPlaylistId(createdId);
  };

  const sortLabel =
    sortBy === 'title'
      ? t.sortTitle
      : sortBy === 'artist'
      ? t.sortArtist
      : sortBy === 'duration'
      ? t.sortDuration
      : t.sortRecent;

  return (
    <div dir="rtl" className="px-4 pt-6 pb-40 max-w-md mx-auto">
      {/* Clean Header */}
      <header className="flex items-center justify-between gap-4 mb-5">
        <div>
          <h1 className="text-3xl sm:text-4xl font-extrabold tracking-tight text-white">
            {mode === 'folders' ? t.navFolders : t.appName}
          </h1>
          <p className="text-xs font-medium text-slate-400 mt-1">
            <span className="font-mono-tabular text-slate-200">{activeSongs.length}</span>{' '}
            {t.songsCount}
            {quarantinedSongs.length > 0 && (
              <>
                <span className="mx-1.5 opacity-50" aria-hidden="true">
                  ·
                </span>
                <span>
                  <span className="font-mono-tabular text-slate-300">
                    {quarantinedSongs.length}
                  </span>{' '}
                  {t.filteredCount}
                </span>
              </>
            )}
          </p>
        </div>

        <motion.button
          type="button"
          whileTap={{ scale: 0.94 }}
          onClick={onImportFiles}
          className="min-h-[42px] px-4 rounded-full water-drop-bar hover:bg-white/[0.08] text-xs font-semibold text-white flex items-center gap-2 shrink-0 transition-colors"
        >
          <Plus size={16} style={{ color: accentColor }} />
          <span className="whitespace-nowrap">{t.importMore}</span>
        </motion.button>
      </header>

      {/* Live Scan Progress */}
      {scanProgress.isScanning && (
        <div className="mb-5 p-4 rounded-2xl water-drop-bar space-y-2.5">
          <div className="flex items-center justify-between gap-3">
            <div className="flex items-center gap-2.5 min-w-0">
              <Loader2 size={16} className="animate-spin shrink-0" style={{ color: accentColor }} />
              <span className="text-xs font-semibold text-slate-100 truncate">
                {t.scanningTitle}
              </span>
            </div>
            <span className="text-xs font-mono-tabular text-slate-300 shrink-0">
              {scanProgress.processedFiles}/{scanProgress.totalFiles}
            </span>
          </div>
          <div dir="rtl" className="relative h-1.5 w-full rounded-full bg-white/10 overflow-hidden">
            <div
              className="absolute right-0 inset-y-0 transition-all duration-200 rounded-full"
              style={{
                width: `${
                  scanProgress.totalFiles > 0
                    ? Math.round((scanProgress.processedFiles / scanProgress.totalFiles) * 100)
                    : 0
                }%`,
                backgroundColor: accentColor,
              }}
            />
          </div>
          <p className="text-[11px] text-slate-400">
            {t.scanningSummary
              .replace('{ok}', String(scanProgress.importedCount))
              .replace('{rec}', String(scanProgress.excludedRecordings))
              .replace('{short}', String(scanProgress.excludedShortClips))}
          </p>
        </div>
      )}

      {/* Onboarding Empty State */}
      {tracks.length === 0 && !scanProgress.isScanning ? (
        <motion.div
          initial={{ opacity: 0, y: 16, scale: 0.98 }}
          animate={{ opacity: 1, y: 0, scale: 1 }}
          transition={kitchenSpring}
          className="mt-8 p-7 sm:p-9 rounded-3xl water-drop-bar text-center max-w-xl mx-auto"
        >
          <div className="w-16 h-16 rounded-2xl bg-white/[0.05] flex items-center justify-center mx-auto mb-5">
            <FolderOpen size={28} style={{ color: accentColor }} />
          </div>
          <h2 className="text-xl font-bold text-white text-balance">{t.emptyTitle}</h2>
          <p className="text-sm text-slate-400 mt-2.5 leading-relaxed max-w-md mx-auto">
            {t.emptyDescription}
          </p>
          <p className="text-xs text-slate-500 mt-3">{t.emptyFilterNote}</p>

          <div className="mt-7 flex flex-col sm:flex-row items-stretch sm:items-center justify-center gap-3">
            <motion.button
              type="button"
              whileTap={{ scale: 0.95 }}
              onClick={onImportFolder}
              className="min-h-[48px] px-6 py-3 rounded-full text-sm font-bold text-black flex items-center justify-center gap-2.5"
              style={{ backgroundColor: accentColor }}
            >
              <FolderOpen size={18} />
              <span className="whitespace-nowrap">{t.importFolder}</span>
            </motion.button>

            <motion.button
              type="button"
              whileTap={{ scale: 0.95 }}
              onClick={onImportFiles}
              className="min-h-[48px] px-6 py-3 rounded-full water-drop-bar hover:bg-white/[0.08] text-sm font-semibold text-slate-100 flex items-center justify-center gap-2.5 transition-colors"
            >
              <FileAudio size={18} />
              <span className="whitespace-nowrap">{t.importFiles}</span>
            </motion.button>
          </div>
        </motion.div>
      ) : (
        <>
          {/* Water-Drop Transparent Search + Sort Bar */}
          <div className="flex items-center gap-2.5 mb-3.5">
            <div className="relative flex-1">
              <Search
                size={16}
                className="absolute top-1/2 -translate-y-1/2 right-4 text-slate-300 pointer-events-none"
              />
              <input
                type="search"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder={t.searchPlaceholder}
                className="w-full min-h-[44px] pr-11 pl-4 rounded-full water-drop-bar text-sm text-white placeholder:text-slate-400 focus:outline-none transition-colors"
              />
            </div>

            <motion.button
              type="button"
              whileTap={{ scale: 0.94 }}
              onClick={cycleSort}
              className="min-h-[44px] px-4 rounded-full water-drop-bar hover:bg-white/[0.08] text-xs font-medium text-slate-100 flex items-center gap-2 shrink-0 transition-colors"
            >
              <ArrowUpDown size={14} style={{ color: accentColor }} />
              <span className="whitespace-nowrap">{sortLabel}</span>
            </motion.button>
          </div>

          {/* Water-Drop Transparent Sub-tabs with Sliding Pill */}
          {mode === 'library' ? (
            <div className="flex items-center gap-1 p-1 rounded-full water-drop-bar mb-4 overflow-x-auto no-scrollbar">
              {(
                [
                  { id: 'songs', label: `${t.tabAllSongs} · ${activeSongs.length}` },
                  { id: 'playlists', label: `${t.tabPlaylists} · ${playlists.length}` },
                  { id: 'favorites', label: `${t.tabFavorites} · ${favoriteSongs.length}` },
                  { id: 'quarantine', label: `${t.tabQuarantine} · ${quarantinedSongs.length}` },
                ] as Array<{ id: LibraryTab; label: string }>
              ).map((tab) => {
                const active = activeTab === tab.id;
                return (
                  <button
                    key={tab.id}
                    type="button"
                    onClick={() => {
                      setActiveTab(tab.id);
                      if (tab.id !== 'playlists') setSelectedPlaylistId(null);
                    }}
                    className={`relative flex-1 min-h-[38px] px-3 py-1.5 rounded-full text-xs font-semibold whitespace-nowrap shrink-0 transition-colors ${
                      active ? 'text-white' : 'text-slate-300 hover:text-white'
                    }`}
                  >
                    {active && (
                      <motion.div
                        layoutId="library-subtab-pill"
                        transition={kitchenSpring}
                        className="absolute inset-0 rounded-full water-drop-pill"
                      />
                    )}
                    <span className="relative z-10">{tab.label}</span>
                  </button>
                );
              })}
            </div>
          ) : (
            <div className="flex items-center gap-2 mb-4 overflow-x-auto no-scrollbar pb-1">
              <button
                type="button"
                onClick={() => setSelectedFolder('ALL')}
                className={`min-h-[38px] px-4 rounded-full text-xs font-semibold whitespace-nowrap shrink-0 transition-colors ${
                  selectedFolder === 'ALL'
                    ? 'water-drop-bar water-drop-pill text-white'
                    : 'water-drop-bar text-slate-300 hover:text-white'
                }`}
              >
                {t.allFolders} · {activeSongs.length}
              </button>
              {foldersList.map(([folder, count]) => (
                <button
                  key={folder}
                  type="button"
                  onClick={() => setSelectedFolder(folder)}
                  className={`min-h-[38px] px-4 rounded-full text-xs font-semibold whitespace-nowrap shrink-0 transition-colors ${
                    selectedFolder === folder
                      ? 'water-drop-bar water-drop-pill text-white'
                      : 'water-drop-bar text-slate-300 hover:text-white'
                  }`}
                >
                  {folder} · {count}
                </button>
              ))}
            </div>
          )}

          {/* Smooth Kitchen-Style Container Transition */}
          <motion.div
            key={`${mode}-${activeTab}-${selectedFolder}-${selectedPlaylistId || 'root'}`}
            initial={{ opacity: 0.4, y: 10, scale: 0.992 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            transition={kitchenSpring}
          >
            {/* PLAYLISTS OVERVIEW MODE */}
            {mode === 'library' && activeTab === 'playlists' && !selectedPlaylist ? (
              <div className="space-y-4">
                <div className="flex items-center justify-between gap-3 p-3.5 rounded-2xl matte-card">
                  <div>
                    <h2 className="text-sm font-bold text-white">{t.tabPlaylists}</h2>
                    <p className="text-xs text-slate-400 mt-0.5">{t.noPlaylistsDesc}</p>
                  </div>
                  <motion.button
                    type="button"
                    whileTap={{ scale: 0.94 }}
                    onClick={openNewPlaylistModal}
                    className="min-h-[42px] px-4 rounded-xl text-xs font-bold text-black flex items-center gap-1.5 shrink-0"
                    style={{ backgroundColor: accentColor }}
                  >
                    <Plus size={16} strokeWidth={2.5} />
                    <span>{t.createPlaylist}</span>
                  </motion.button>
                </div>

                {playlists.length === 0 ? (
                  <div className="py-16 text-center px-4">
                    <ListMusic size={34} className="mx-auto text-slate-500 mb-3" />
                    <p className="text-sm font-semibold text-slate-200">{t.noPlaylistsTitle}</p>
                    <p className="text-xs text-slate-400 mt-1.5 max-w-sm mx-auto">
                      {t.noPlaylistsDesc}
                    </p>
                  </div>
                ) : (
                  <div className="space-y-2">
                    {playlists.map((pl) => {
                      const plTracks = pl.trackIds
                        .map((id) => activeSongs.find((tr) => tr.id === id))
                        .filter((tr): tr is Track => Boolean(tr));
                      const firstCover = plTracks[0]?.coverUrl;

                      return (
                        <div
                          key={pl.id}
                          className="flex items-center gap-3 p-2.5 rounded-2xl matte-card hover:bg-white/[0.07] transition-colors"
                        >
                          <button
                            type="button"
                            onClick={() => setSelectedPlaylistId(pl.id)}
                            className="flex items-center gap-3.5 flex-1 min-w-0 text-start min-h-[50px]"
                          >
                            <ArtworkTile
                              coverUrl={firstCover}
                              title={pl.name}
                              accentColor={accentColor}
                              sizeClass="w-12 h-12"
                              roundedClass="rounded-xl"
                            />
                            <div className="min-w-0 flex-1">
                              <p className="text-sm font-bold text-white truncate">{pl.name}</p>
                              <p className="text-xs text-slate-400 mt-0.5">
                                <span className="font-mono-tabular text-slate-200">
                                  {plTracks.length}
                                </span>{' '}
                                {t.songsCount}
                              </p>
                            </div>
                          </button>

                          <div className="flex items-center gap-1.5 shrink-0">
                            <button
                              type="button"
                              onClick={() => openExistingPlaylistModal(pl)}
                              className="h-9 px-3 rounded-xl bg-white/[0.07] hover:bg-white/[0.13] text-xs font-semibold text-slate-100 flex items-center gap-1 transition-colors"
                            >
                              <Plus size={14} style={{ color: accentColor }} />
                              <span className="hidden sm:inline">{t.addSongsAction}</span>
                            </button>

                            {plTracks.length > 0 && (
                              <button
                                type="button"
                                onClick={() => onPlayPlaylist(plTracks)}
                                aria-label={t.playAll}
                                className="h-9 px-3 rounded-xl text-xs font-bold text-black flex items-center gap-1.5 active:scale-95 transition-transform"
                                style={{ backgroundColor: accentColor }}
                              >
                                <Play size={13} fill="currentColor" />
                                <span className="hidden sm:inline">{t.playAll}</span>
                              </button>
                            )}
                            <button
                              type="button"
                              onClick={() => setSettingsPlaylistId(pl.id)}
                              aria-label={t.playlistSettingsTitle}
                              title={t.playlistSettingsTitle}
                              className="w-9 h-9 flex items-center justify-center rounded-xl bg-white/[0.06] text-slate-300 hover:text-white hover:bg-white/[0.12] transition-colors"
                            >
                              <Settings2 size={16} />
                            </button>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                )}
              </div>
            ) : (
              /* FRAMELESS TRACK LIST (No Big Outer Frame Around Songs) */
              <div className="space-y-3">
                {mode === 'library' && activeTab === 'playlists' && selectedPlaylist && (
                  <div className="flex items-center justify-between gap-2 p-2.5 rounded-2xl matte-card">
                    <button
                      type="button"
                      onClick={() => setSelectedPlaylistId(null)}
                      className="min-h-[38px] px-3.5 rounded-xl bg-white/[0.06] hover:bg-white/[0.1] text-xs font-semibold text-slate-100 flex items-center gap-2 transition-colors"
                    >
                      <ArrowRight size={15} style={{ color: accentColor }} />
                      <span>{t.backToPlaylists}</span>
                      <span className="opacity-50">·</span>
                      <span className="font-bold text-white truncate max-w-[140px]">
                        {selectedPlaylist.name}
                      </span>
                    </button>

                    <div className="flex items-center gap-2">
                      <button
                        type="button"
                        onClick={() => setSettingsPlaylistId(selectedPlaylist.id)}
                        aria-label={t.playlistSettingsTitle}
                        title={t.playlistSettingsTitle}
                        className="min-h-[38px] px-3 rounded-xl bg-white/[0.08] hover:bg-white/[0.14] text-xs font-semibold text-white flex items-center gap-1.5 transition-colors"
                      >
                        <Settings2 size={15} style={{ color: accentColor }} />
                        <span className="hidden sm:inline">{t.playlistSettingsTitle}</span>
                      </button>

                      <button
                        type="button"
                        onClick={() => openExistingPlaylistModal(selectedPlaylist)}
                        className="min-h-[38px] px-3.5 rounded-xl bg-white/[0.08] hover:bg-white/[0.14] text-xs font-semibold text-white flex items-center gap-1.5 transition-colors"
                      >
                        <Plus size={15} style={{ color: accentColor }} />
                        <span>{t.addSongsAction}</span>
                      </button>

                      {displayedTracks.length > 0 && (
                        <button
                          type="button"
                          onClick={() => onPlayPlaylist(displayedTracks)}
                          className="min-h-[38px] px-4 rounded-xl text-xs font-bold text-black flex items-center gap-1.5 active:scale-95 transition-transform"
                          style={{ backgroundColor: accentColor }}
                        >
                          <Play size={14} fill="currentColor" />
                          <span>{t.playAll}</span>
                        </button>
                      )}
                    </div>
                  </div>
                )}

                {displayedTracks.length === 0 ? (
                  <div className="py-16 text-center px-4">
                    <ShieldCheck size={34} className="mx-auto text-slate-500 mb-3" />
                    <p className="text-sm font-semibold text-slate-200">
                      {searchQuery
                        ? t.noSearchResults
                        : mode === 'folders'
                        ? t.foldersEmptyTitle
                        : activeTab === 'playlists'
                        ? selectedPlaylist?.name
                        : activeTab === 'favorites'
                        ? t.noFavoritesTitle
                        : t.noQuarantineTitle}
                    </p>
                    <p className="text-xs text-slate-400 mt-1.5 max-w-sm mx-auto">
                      {searchQuery
                        ? ''
                        : mode === 'folders'
                        ? t.foldersEmptyDesc
                        : activeTab === 'playlists'
                        ? t.emptyPlaylistDesc
                        : activeTab === 'favorites'
                        ? t.noFavoritesDesc
                        : t.noQuarantineDesc}
                    </p>
                  </div>
                ) : (
                  <div className="space-y-1">
                    {displayedTracks.map((track) => {
                      const isCurrent = track.id === currentTrackId;
                      const isExcludedView = track.exclusionReason !== null;
                      return (
                        <div
                          key={track.id}
                          className={`relative flex items-center gap-3 py-2 px-2.5 rounded-2xl transition-colors ${
                            isCurrent ? 'bg-white/[0.08]' : 'hover:bg-white/[0.04]'
                          }`}
                        >
                          <button
                            type="button"
                            onClick={() => onPlayTrack(track, displayedTracks)}
                            className="relative z-10 flex items-center gap-3.5 flex-1 min-w-0 text-start min-h-[48px] active:scale-[0.99] transition-transform"
                          >
                            <ArtworkTile
                              coverUrl={track.coverUrl}
                              title={track.title}
                              accentColor={accentColor}
                              sizeClass="w-12 h-12"
                              roundedClass="rounded-xl"
                              isPlaying={isCurrent && isPlaying}
                            />

                            <div className="min-w-0 flex-1">
                              <p
                                className="text-[14px] font-semibold truncate leading-snug"
                                style={{ color: isCurrent ? accentColor : '#F8FAFC' }}
                              >
                                {track.title}
                              </p>
                              <p className="text-xs text-slate-400 truncate mt-0.5 flex items-center gap-1.5">
                                {isExcludedView ? (
                                  <>
                                    <span>
                                      {track.exclusionReason === 'recording'
                                        ? t.reasonRecording
                                        : t.reasonShortClip}
                                    </span>
                                    <span className="opacity-50" aria-hidden="true">
                                      ·
                                    </span>
                                    <span dir="ltr" className="font-mono-tabular">
                                      {formatDuration(track.duration)}
                                    </span>
                                    {track.matchedRule && (
                                      <>
                                        <span className="opacity-50" aria-hidden="true">
                                          ·
                                        </span>
                                        <span>{track.matchedRule}</span>
                                      </>
                                    )}
                                  </>
                                ) : (
                                  <>
                                    <span className="truncate">{track.artist}</span>
                                    <span className="opacity-50 shrink-0" aria-hidden="true">
                                      ·
                                    </span>
                                    <span dir="ltr" className="font-mono-tabular shrink-0">
                                      {formatDuration(track.duration)}
                                    </span>
                                    <span className="opacity-50 shrink-0" aria-hidden="true">
                                      ·
                                    </span>
                                    <span className="font-mono-tabular text-[11px] shrink-0">
                                      {track.formatLabel}
                                    </span>
                                  </>
                                )}
                              </p>
                            </div>
                          </button>

                          <div className="relative z-10 flex items-center gap-0.5 shrink-0">
                            {isExcludedView ? (
                              <button
                                type="button"
                                onClick={() => onRestoreTrack(track)}
                                aria-label={t.restoreTrack}
                                className="min-h-[38px] px-3 rounded-xl bg-white/[0.08] hover:bg-white/[0.14] text-xs font-medium text-white flex items-center gap-1.5 active:scale-95 transition-all"
                              >
                                <RotateCcw size={14} style={{ color: accentColor }} />
                                <span className="hidden sm:inline">{t.restoreTrack}</span>
                              </button>
                            ) : (
                              <button
                                type="button"
                                onClick={() => onToggleFavorite(track.id)}
                                aria-label={
                                  track.isFavorite ? t.removeFromFavorites : t.addToFavorites
                                }
                                className="w-10 h-10 flex items-center justify-center rounded-full hover:bg-white/10 active:scale-90 transition-transform"
                              >
                                <Heart
                                  size={17}
                                  fill={track.isFavorite ? accentColor : 'none'}
                                  style={{
                                    color: track.isFavorite
                                      ? accentColor
                                      : 'rgba(148, 163, 184, 0.6)',
                                  }}
                                />
                              </button>
                            )}

                            {activeTab === 'playlists' && selectedPlaylist && (
                              <button
                                type="button"
                                onClick={() =>
                                  onRemoveTrackFromPlaylist(selectedPlaylist.id, track.id)
                                }
                                aria-label={t.removeFromPlaylist}
                                className="w-9 h-9 flex items-center justify-center rounded-full text-slate-400 hover:text-rose-400 hover:bg-rose-500/10 active:scale-90 transition-all"
                              >
                                <X size={16} />
                              </button>
                            )}

                            <button
                              type="button"
                              onClick={() => onOpenContextMenu(track)}
                              aria-label="More options"
                              className="w-10 h-10 flex items-center justify-center rounded-full text-slate-400 hover:text-white hover:bg-white/10 active:scale-90 transition-all"
                            >
                              <MoreHorizontal size={18} />
                            </button>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                )}
              </div>
            )}
          </motion.div>
        </>
      )}

      {/* Dedicated Create / Edit Playlist Modal with 20% Light Blur & (+) Track Selector */}
      <CreatePlaylistModal
        isOpen={isPlaylistModalOpen}
        editingPlaylist={editingPlaylist}
        tracks={tracks}
        playlistsCount={playlists.length}
        accentColor={accentColor}
        onClose={() => setIsPlaylistModalOpen(false)}
        onSaveNewPlaylist={handleSaveNewPlaylist}
        onToggleTrackInExistingPlaylist={onToggleTrackInPlaylist}
        t={t}
      />

      {/* Dedicated Playlist Settings Modal (Reorder, Remove Specific Tracks, Safe Delete with 'مسح') */}
      <PlaylistSettingsModal
        isOpen={Boolean(settingsPlaylist)}
        playlist={settingsPlaylist}
        tracks={tracks}
        accentColor={accentColor}
        onClose={() => setSettingsPlaylistId(null)}
        onUpdatePlaylist={onUpdatePlaylist}
        onDeletePlaylist={(plId) => {
          onDeletePlaylist(plId);
          if (selectedPlaylistId === plId) {
            setSelectedPlaylistId(null);
          }
          setSettingsPlaylistId(null);
        }}
        onOpenAddSongs={(pl) => openExistingPlaylistModal(pl)}
        t={t}
      />
    </div>
  );
}
