import {
  Check,
  Clock,
  FileAudio,
  FolderOpen,
  FolderPlus,
  HardDrive,
  Heart,
  Info,
  ListEnd,
  ListPlus,
  Mic2,
  Plus,
  RotateCcw,
  ShieldAlert,
  Trash2,
  X,
} from 'lucide-react';
import { AnimatePresence, motion } from 'motion/react';
import { useState } from 'react';
import type { Translations } from '../i18n/translations';
import type { Playlist, Track } from '../types/music';
import { formatDuration, formatFileSize } from '../utils/smartFilter';
import { ArtworkTile } from './ArtworkTile';

interface TrackContextSheetProps {
  track: Track | null;
  playlists: Playlist[];
  onClose: () => void;
  onPlayNext: (track: Track) => void;
  onAddToQueue: (track: Track) => void;
  onToggleFavorite: (trackId: string) => void;
  onViewLyrics: (track: Track) => void;
  onToggleExclusion: (track: Track) => void;
  onDeleteTrack: (trackId: string) => void;
  onCreatePlaylistAndAdd: (name: string, trackId: string) => void;
  onToggleTrackInPlaylist: (playlistId: string, trackId: string) => void;
  t: Translations;
  accentColor: string;
  glowColor?: string;
}

const sheetStagger = {
  hidden: { opacity: 0 },
  show: {
    opacity: 1,
    transition: { staggerChildren: 0.035, delayChildren: 0.03 },
  },
};

const sheetItem = {
  hidden: { opacity: 0, x: 12 },
  show: {
    opacity: 1,
    x: 0,
    transition: { type: 'spring' as const, stiffness: 500, damping: 34 },
  },
};

export function TrackContextSheet({
  track,
  playlists,
  onClose,
  onPlayNext,
  onAddToQueue,
  onToggleFavorite,
  onViewLyrics,
  onToggleExclusion,
  onDeleteTrack,
  onCreatePlaylistAndAdd,
  onToggleTrackInPlaylist,
  t,
  accentColor,
}: TrackContextSheetProps) {
  const [showSpecs, setShowSpecs] = useState(false);
  const [showPlaylistPicker, setShowPlaylistPicker] = useState(false);
  const [newPlaylistName, setNewPlaylistName] = useState('');

  const handleClose = () => {
    setShowSpecs(false);
    setShowPlaylistPicker(false);
    setNewPlaylistName('');
    onClose();
  };

  const handleCreatePlaylist = () => {
    const clean = newPlaylistName.trim();
    if (!clean || !track) return;
    onCreatePlaylistAndAdd(clean, track.id);
    setNewPlaylistName('');
  };

  return (
    <AnimatePresence>
      {track && (
        <div
          dir="rtl"
          className="fixed inset-0 z-50 flex items-end lg:items-center justify-center p-3.5 sm:p-5"
        >
          {/* Clear Backdrop WITHOUT Blur */}
          <motion.button
            key="ctx-backdrop"
            type="button"
            aria-label={t.close}
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.18 }}
            onClick={handleClose}
            className="fixed inset-0 bg-black/30 cursor-default"
          />

          {/* Natural Matte Bottom Sheet with Framer Motion Drag-to-Dismiss & Stagger */}
          <motion.div
            key="ctx-sheet"
            initial={{ opacity: 0, y: 60, scale: 0.94 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 48, scale: 0.95 }}
            transition={{
              type: 'spring',
              stiffness: 480,
              damping: 34,
              mass: 0.72,
            }}
            drag="y"
            dragConstraints={{ top: 0, bottom: 0 }}
            dragElastic={{ top: 0.05, bottom: 0.4 }}
            onDragEnd={(_, info) => {
              if (info.offset.y > 90 || info.velocity.y > 420) {
                handleClose();
              }
            }}
            className="relative z-10 w-full max-w-[410px] matte-elevated rounded-3xl overflow-hidden p-5 max-h-[86vh] overflow-y-auto no-scrollbar"
          >
            {/* Top Pill Handle */}
            <div className="w-10 h-1 bg-white/20 rounded-full mx-auto mb-4" />

            {/* Clean Track Header */}
            <div className="flex items-center gap-3.5 pb-4 border-b border-white/[0.06]">
              <ArtworkTile
                coverUrl={track.coverUrl}
                title={track.title}
                accentColor={accentColor}
                sizeClass="w-14 h-14"
                roundedClass="rounded-2xl"
                iconSize={24}
              />

              <div className="min-w-0 flex-1">
                <h3 className="text-[15px] font-bold text-white truncate leading-snug">
                  {track.title}
                </h3>
                <p className="text-xs text-slate-400 truncate mt-0.5">
                  {track.artist} · {track.album}
                </p>
                <p
                  className="text-[11px] font-mono-tabular mt-1 font-medium"
                  style={{ color: accentColor }}
                >
                  {track.formatLabel} · {formatDuration(track.duration)} ·{' '}
                  {formatFileSize(track.fileSize)}
                </p>
              </div>

              <div className="flex items-center gap-1 shrink-0">
                <motion.button
                  type="button"
                  whileTap={{ scale: 0.8 }}
                  onClick={() => onToggleFavorite(track.id)}
                  aria-label={track.isFavorite ? t.removeFromFavorites : t.addToFavorites}
                  className="w-9 h-9 flex items-center justify-center rounded-full hover:bg-white/10"
                >
                  <Heart
                    size={18}
                    fill={track.isFavorite ? accentColor : 'none'}
                    style={{ color: track.isFavorite ? accentColor : '#cbd5e1' }}
                  />
                </motion.button>
                <motion.button
                  type="button"
                  whileTap={{ scale: 0.85 }}
                  onClick={handleClose}
                  aria-label={t.close}
                  className="w-9 h-9 flex items-center justify-center rounded-full text-slate-400 hover:text-white hover:bg-white/10"
                >
                  <X size={18} />
                </motion.button>
              </div>
            </div>

            {/* Staggered Framer Motion Action List */}
            <motion.div
              variants={sheetStagger}
              initial="hidden"
              animate="show"
              className="py-2 space-y-1"
            >
              <motion.button
                variants={sheetItem}
                whileTap={{ scale: 0.97 }}
                type="button"
                onClick={() => {
                  onPlayNext(track);
                  handleClose();
                }}
                className="w-full min-h-[46px] px-3 rounded-xl hover:bg-white/[0.06] flex items-center gap-3.5 text-sm font-medium text-white transition-colors"
              >
                <ListPlus size={19} style={{ color: accentColor }} className="shrink-0" />
                <span>{t.playNext}</span>
              </motion.button>

              <motion.button
                variants={sheetItem}
                whileTap={{ scale: 0.97 }}
                type="button"
                onClick={() => {
                  onAddToQueue(track);
                  handleClose();
                }}
                className="w-full min-h-[46px] px-3 rounded-xl hover:bg-white/[0.06] flex items-center gap-3.5 text-sm font-medium text-white transition-colors"
              >
                <ListEnd size={19} style={{ color: accentColor }} className="shrink-0" />
                <span>{t.addToQueue}</span>
              </motion.button>

              <motion.button
                variants={sheetItem}
                whileTap={{ scale: 0.97 }}
                type="button"
                onClick={() => setShowPlaylistPicker((prev) => !prev)}
                className="w-full min-h-[46px] px-3 rounded-xl hover:bg-white/[0.06] flex items-center justify-between text-sm font-medium text-white transition-colors"
              >
                <span className="flex items-center gap-3.5">
                  <FolderPlus size={19} style={{ color: accentColor }} className="shrink-0" />
                  <span>{t.addToPlaylist}</span>
                </span>
                <span className="text-xs font-mono-tabular text-slate-400">
                  {playlists.length}
                </span>
              </motion.button>

              {/* Inline Playlist Picker & Creator */}
              <AnimatePresence>
                {showPlaylistPicker && (
                  <motion.div
                    initial={{ opacity: 0, height: 0 }}
                    animate={{ opacity: 1, height: 'auto' }}
                    exit={{ opacity: 0, height: 0 }}
                    transition={{ type: 'spring', stiffness: 420, damping: 32 }}
                    className="overflow-hidden"
                  >
                    <div className="p-3 my-1 rounded-2xl bg-black/35 space-y-2.5">
                      <div className="flex gap-2">
                        <input
                          type="text"
                          value={newPlaylistName}
                          onChange={(e) => setNewPlaylistName(e.target.value)}
                          onKeyDown={(e) => {
                            if (e.key === 'Enter') handleCreatePlaylist();
                          }}
                          placeholder={t.playlistNamePlaceholder}
                          className="flex-1 min-h-[38px] px-3 rounded-xl bg-black/60 text-xs text-white placeholder:text-slate-500 focus:outline-none"
                        />
                        <motion.button
                          type="button"
                          whileTap={{ scale: 0.93 }}
                          onClick={handleCreatePlaylist}
                          className="min-h-[38px] px-3.5 rounded-xl text-xs font-bold text-black flex items-center gap-1 shrink-0"
                          style={{ backgroundColor: accentColor }}
                        >
                          <Plus size={14} />
                          <span>{t.createAction}</span>
                        </motion.button>
                      </div>

                      {playlists.length > 0 && (
                        <div className="max-h-36 overflow-y-auto no-scrollbar space-y-1 pt-1">
                          {playlists.map((pl) => {
                            const inPlaylist = pl.trackIds.includes(track.id);
                            return (
                              <button
                                key={pl.id}
                                type="button"
                                onClick={() => onToggleTrackInPlaylist(pl.id, track.id)}
                                className="w-full min-h-[36px] px-3 rounded-xl hover:bg-white/[0.06] flex items-center justify-between text-xs text-slate-100 transition-colors"
                              >
                                <span className="truncate font-medium">{pl.name}</span>
                                <span className="flex items-center gap-2 shrink-0">
                                  <span className="text-[11px] font-mono-tabular text-slate-400">
                                    {pl.trackIds.length}
                                  </span>
                                  {inPlaylist && (
                                    <Check size={14} style={{ color: accentColor }} />
                                  )}
                                </span>
                              </button>
                            );
                          })}
                        </div>
                      )}
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>

              <motion.button
                variants={sheetItem}
                whileTap={{ scale: 0.97 }}
                type="button"
                onClick={() => {
                  onViewLyrics(track);
                  handleClose();
                }}
                className="w-full min-h-[46px] px-3 rounded-xl hover:bg-white/[0.06] flex items-center gap-3.5 text-sm font-medium text-white transition-colors"
              >
                <Mic2 size={19} style={{ color: accentColor }} className="shrink-0" />
                <span>{t.viewLyrics}</span>
              </motion.button>

              <motion.button
                variants={sheetItem}
                whileTap={{ scale: 0.97 }}
                type="button"
                onClick={() => setShowSpecs((prev) => !prev)}
                className="w-full min-h-[46px] px-3 rounded-xl hover:bg-white/[0.06] flex items-center justify-between text-sm font-medium text-slate-200 transition-colors"
              >
                <span className="flex items-center gap-3.5">
                  <Info size={19} className="text-slate-400 shrink-0" />
                  <span>{t.trackDetails}</span>
                </span>
                <span className="text-xs font-mono-tabular text-slate-400">
                  {track.formatLabel}
                </span>
              </motion.button>
            </motion.div>

            {/* Expandable File Specs */}
            <AnimatePresence>
              {showSpecs && (
                <motion.div
                  initial={{ opacity: 0, height: 0 }}
                  animate={{ opacity: 1, height: 'auto' }}
                  exit={{ opacity: 0, height: 0 }}
                  transition={{ type: 'spring', stiffness: 420, damping: 32 }}
                  className="overflow-hidden"
                >
                  <div className="py-3 px-3 mb-2 rounded-2xl bg-black/35 space-y-2 text-xs">
                    <div className="flex items-center justify-between text-slate-300">
                      <span className="flex items-center gap-1.5 text-slate-400">
                        <FileAudio size={13} />
                        {t.fileFormat}
                      </span>
                      <span className="font-mono-tabular text-white">{track.formatLabel}</span>
                    </div>
                    <div className="flex items-center justify-between text-slate-300">
                      <span className="flex items-center gap-1.5 text-slate-400">
                        <Clock size={13} />
                        {t.fileDuration}
                      </span>
                      <span className="font-mono-tabular text-white">
                        {formatDuration(track.duration)}
                      </span>
                    </div>
                    <div className="flex items-center justify-between text-slate-300">
                      <span className="flex items-center gap-1.5 text-slate-400">
                        <HardDrive size={13} />
                        {t.fileSize}
                      </span>
                      <span className="font-mono-tabular text-white">
                        {formatFileSize(track.fileSize)}
                      </span>
                    </div>
                    <div className="flex items-start justify-between gap-3 pt-1 border-t border-white/[0.06]">
                      <span className="text-slate-400 shrink-0 flex items-center gap-1.5">
                        <FolderOpen size={13} />
                        {t.folderLocation}
                      </span>
                      <span className="text-slate-200 text-end break-all font-mono-tabular">
                        {track.folderPath || '/'}
                      </span>
                    </div>
                  </div>
                </motion.div>
              )}
            </AnimatePresence>

            {/* Bottom Actions */}
            <div className="pt-3 border-t border-white/[0.06] flex items-center gap-2">
              <motion.button
                whileTap={{ scale: 0.95 }}
                type="button"
                onClick={() => {
                  onToggleExclusion(track);
                  handleClose();
                }}
                className="flex-1 min-h-[44px] px-3 rounded-xl bg-white/[0.06] hover:bg-white/[0.11] flex items-center justify-center gap-2 text-xs font-semibold text-slate-100 transition-colors"
              >
                {track.exclusionReason ? (
                  <RotateCcw size={15} style={{ color: accentColor }} className="shrink-0" />
                ) : (
                  <ShieldAlert size={15} style={{ color: accentColor }} className="shrink-0" />
                )}
                <span className="truncate">
                  {track.exclusionReason ? t.restoreTrack : t.excludeTrack}
                </span>
              </motion.button>

              <motion.button
                whileTap={{ scale: 0.95 }}
                type="button"
                onClick={() => {
                  onDeleteTrack(track.id);
                  handleClose();
                }}
                className="flex-1 min-h-[44px] px-3 rounded-xl bg-rose-500/15 hover:bg-rose-500/22 flex items-center justify-center gap-2 text-xs font-semibold text-rose-300 transition-colors"
              >
                <Trash2 size={15} className="shrink-0" />
                <span className="truncate">{t.deleteFromLibrary}</span>
              </motion.button>
            </div>
          </motion.div>
        </div>
      )}
    </AnimatePresence>
  );
}
