export interface ParsedAudioMetadata {
  title: string;
  artist: string;
  album: string;
  duration: number;
  coverBlob?: Blob;
  formatLabel: string;
}

const DEFAULT_ACCENT = '#E2E8F0';

function decodeTextBytes(bytes: Uint8Array, encoding: number): string {
  try {
    if (encoding === 0) {
      return new TextDecoder('iso-8859-1').decode(bytes).replace(/\0+$/, '').trim();
    }
    if (encoding === 1) {
      // UTF-16 with BOM
      if (bytes.length >= 2 && bytes[0] === 0xff && bytes[1] === 0xfe) {
        return new TextDecoder('utf-16le').decode(bytes.subarray(2)).replace(/\0+$/, '').trim();
      }
      if (bytes.length >= 2 && bytes[0] === 0xfe && bytes[1] === 0xff) {
        return new TextDecoder('utf-16be').decode(bytes.subarray(2)).replace(/\0+$/, '').trim();
      }
      return new TextDecoder('utf-16le').decode(bytes).replace(/\0+$/, '').trim();
    }
    if (encoding === 2) {
      return new TextDecoder('utf-16be').decode(bytes).replace(/\0+$/, '').trim();
    }
    return new TextDecoder('utf-8').decode(bytes).replace(/\0+$/, '').trim();
  } catch {
    return '';
  }
}

function readSyncSafeInt(view: DataView, offset: number): number {
  return (
    ((view.getUint8(offset) & 0x7f) << 21) |
    ((view.getUint8(offset + 1) & 0x7f) << 14) |
    ((view.getUint8(offset + 2) & 0x7f) << 7) |
    (view.getUint8(offset + 3) & 0x7f)
  );
}

function parseId3v2(buffer: ArrayBuffer): Partial<ParsedAudioMetadata> {
  const view = new DataView(buffer);
  const bytes = new Uint8Array(buffer);
  if (bytes.length < 10) return {};
  if (bytes[0] !== 0x49 || bytes[1] !== 0x44 || bytes[2] !== 0x33) return {};

  const majorVersion = bytes[3];
  if (majorVersion < 2 || majorVersion > 4) return {};
  const flags = bytes[5];
  const tagSize = readSyncSafeInt(view, 6);
  const hasExtendedHeader = (flags & 0x40) !== 0;

  let offset = 10;
  const end = Math.min(bytes.length, 10 + tagSize);

  if (hasExtendedHeader && offset + 4 <= end) {
    const extSize = majorVersion === 4 ? readSyncSafeInt(view, offset) : view.getUint32(offset);
    offset += majorVersion === 4 ? extSize : extSize + 4;
  }

  const result: Partial<ParsedAudioMetadata> = {};

  while (offset + (majorVersion === 2 ? 6 : 10) <= end) {
    let frameId = '';
    let frameSize = 0;
    let headerLen = 10;

    if (majorVersion === 2) {
      headerLen = 6;
      frameId = String.fromCharCode(bytes[offset], bytes[offset + 1], bytes[offset + 2]);
      frameSize = (bytes[offset + 3] << 16) | (bytes[offset + 4] << 8) | bytes[offset + 5];
    } else {
      frameId = String.fromCharCode(
        bytes[offset],
        bytes[offset + 1],
        bytes[offset + 2],
        bytes[offset + 3]
      );
      frameSize =
        majorVersion === 4
          ? readSyncSafeInt(view, offset + 4)
          : view.getUint32(offset + 4);
    }

    if (!frameId || frameId.charCodeAt(0) === 0 || frameSize <= 0) break;
    const dataStart = offset + headerLen;
    const dataEnd = Math.min(end, dataStart + frameSize);
    if (dataStart >= dataEnd) break;

    const frameBytes = bytes.subarray(dataStart, dataEnd);

    if (frameId === 'TIT2' || frameId === 'TT2') {
      const val = decodeTextBytes(frameBytes.subarray(1), frameBytes[0]);
      if (val) result.title = val;
    } else if (frameId === 'TPE1' || frameId === 'TP1') {
      const val = decodeTextBytes(frameBytes.subarray(1), frameBytes[0]);
      if (val) result.artist = val;
    } else if (frameId === 'TALB' || frameId === 'TAL') {
      const val = decodeTextBytes(frameBytes.subarray(1), frameBytes[0]);
      if (val) result.album = val;
    } else if ((frameId === 'APIC' || frameId === 'PIC') && !result.coverBlob) {
      const encoding = frameBytes[0];
      let cursor = 1;
      let mime = 'image/jpeg';

      if (frameId === 'PIC') {
        const imgFmt = String.fromCharCode(frameBytes[1], frameBytes[2], frameBytes[3]).toLowerCase();
        mime = imgFmt === 'png' ? 'image/png' : 'image/jpeg';
        cursor = 4;
      } else {
        let mimeEnd = cursor;
        while (mimeEnd < frameBytes.length && frameBytes[mimeEnd] !== 0) mimeEnd++;
        mime = new TextDecoder('ascii').decode(frameBytes.subarray(cursor, mimeEnd)) || 'image/jpeg';
        if (mime === 'image/jpg') mime = 'image/jpeg';
        cursor = mimeEnd + 1;
      }

      // Skip picture type byte
      cursor += 1;

      // Skip null-terminated description
      if (encoding === 1 || encoding === 2) {
        while (cursor + 1 < frameBytes.length && !(frameBytes[cursor] === 0 && frameBytes[cursor + 1] === 0)) {
          cursor += 2;
        }
        cursor += 2;
      } else {
        while (cursor < frameBytes.length && frameBytes[cursor] !== 0) {
          cursor += 1;
        }
        cursor += 1;
      }

      if (cursor < frameBytes.length) {
        const imageBytes = frameBytes.slice(cursor);
        if (imageBytes.byteLength > 64) {
          result.coverBlob = new Blob([imageBytes], { type: mime });
        }
      }
    }

    offset = dataEnd;
  }

  return result;
}

function parseFlacMetadata(buffer: ArrayBuffer): Partial<ParsedAudioMetadata> {
  const bytes = new Uint8Array(buffer);
  const view = new DataView(buffer);
  if (bytes.length < 8) return {};
  if (bytes[0] !== 0x66 || bytes[1] !== 0x4c || bytes[2] !== 0x61 || bytes[3] !== 0x43) return {};

  const result: Partial<ParsedAudioMetadata> = {};
  let offset = 4;
  let isLast = false;

  while (!isLast && offset + 4 <= bytes.length) {
    const header = bytes[offset];
    isLast = (header & 0x80) !== 0;
    const blockType = header & 0x7f;
    const blockLen = (bytes[offset + 1] << 16) | (bytes[offset + 2] << 8) | bytes[offset + 3];
    const start = offset + 4;
    const end = Math.min(bytes.length, start + blockLen);

    if (blockType === 4 && start + 8 <= end) {
      // VORBIS_COMMENT
      let c = start;
      const vendorLen = view.getUint32(c, true);
      c += 4 + vendorLen;
      if (c + 4 <= end) {
        const count = view.getUint32(c, true);
        c += 4;
        for (let i = 0; i < count && c + 4 <= end; i++) {
          const len = view.getUint32(c, true);
          c += 4;
          if (c + len > end) break;
          const comment = new TextDecoder('utf-8').decode(bytes.subarray(c, c + len));
          c += len;
          const eq = comment.indexOf('=');
          if (eq > 0) {
            const key = comment.slice(0, eq).toUpperCase();
            const val = comment.slice(eq + 1).trim();
            if (key === 'TITLE' && val) result.title = val;
            if (key === 'ARTIST' && val) result.artist = val;
            if (key === 'ALBUM' && val) result.album = val;
          }
        }
      }
    } else if (blockType === 6 && start + 32 <= end && !result.coverBlob) {
      // PICTURE
      let c = start + 4; // skip picture type
      const mimeLen = view.getUint32(c, true) > 256 ? view.getUint32(c, false) : view.getUint32(c, false);
      c += 4;
      const mime = new TextDecoder('ascii').decode(bytes.subarray(c, c + mimeLen)) || 'image/jpeg';
      c += mimeLen;
      const descLen = view.getUint32(c, false);
      c += 4 + descLen + 16; // skip width, height, depth, colors
      if (c + 4 <= end) {
        const dataLen = view.getUint32(c, false);
        c += 4;
        if (c + dataLen <= end && dataLen > 64) {
          result.coverBlob = new Blob([bytes.slice(c, c + dataLen)], { type: mime });
        }
      }
    }

    offset = end;
  }

  return result;
}

function parseMp4Metadata(buffer: ArrayBuffer): Partial<ParsedAudioMetadata> {
  const bytes = new Uint8Array(buffer);
  const view = new DataView(buffer);
  const decoder = new TextDecoder('utf-8');
  const result: Partial<ParsedAudioMetadata> = {};

  function readAtomName(offset: number): string {
    return String.fromCharCode(
      bytes[offset],
      bytes[offset + 1],
      bytes[offset + 2],
      bytes[offset + 3]
    );
  }

  function scanAtoms(start: number, end: number) {
    let pos = start;
    while (pos + 8 <= end) {
      const size = view.getUint32(pos, false);
      if (size < 8 || pos + size > end) break;
      const name = readAtomName(pos + 4);

      if (name === 'moov' || name === 'udta' || name === 'ilst') {
        scanAtoms(pos + 8, pos + size);
      } else if (name === 'meta') {
        scanAtoms(pos + 12, pos + size);
      } else if (name === '©nam' || name === '©ART' || name === '©alb' || name === 'covr') {
        let subPos = pos + 8;
        while (subPos + 8 <= pos + size) {
          const subSize = view.getUint32(subPos, false);
          if (subSize < 16 || subPos + subSize > pos + size) break;
          const subName = readAtomName(subPos + 4);
          if (subName === 'data') {
            const payload = bytes.subarray(subPos + 16, subPos + subSize);
            if (name === '©nam') result.title = decoder.decode(payload).trim();
            if (name === '©ART') result.artist = decoder.decode(payload).trim();
            if (name === '©alb') result.album = decoder.decode(payload).trim();
            if (name === 'covr' && !result.coverBlob && payload.byteLength > 64) {
              const typeFlag = view.getUint32(subPos + 8, false);
              const mime = typeFlag === 14 ? 'image/png' : 'image/jpeg';
              result.coverBlob = new Blob([payload.slice()], { type: mime });
            }
          }
          subPos += subSize;
        }
      }
      pos += size;
    }
  }

  scanAtoms(0, bytes.length);
  return result;
}

export function cleanFileNameToTrackGuess(fileName: string): { title: string; artist: string } {
  const withoutExt = fileName.replace(/\.[^/.]+$/, '');
  const cleaned = withoutExt
    .replace(/\[(.*?)\]/g, ' ')
    .replace(/\((official\s*(video|audio|lyric\s*video|hd|hq)|lyrics?|audio|mp3|320kbps)\)/gi, ' ')
    .replace(/^\d{1,3}[\s._-]+/, '')
    .replace(/\s+/g, ' ')
    .trim();

  const dashSplit = cleaned.split(/\s+[-–—]\s+/);
  if (dashSplit.length >= 2) {
    return {
      artist: dashSplit[0].trim(),
      title: dashSplit.slice(1).join(' - ').trim(),
    };
  }

  return {
    title: cleaned || withoutExt,
    artist: '',
  };
}

export function readAudioDuration(file: Blob): Promise<number> {
  return new Promise((resolve) => {
    const audio = document.createElement('audio');
    const url = URL.createObjectURL(file);
    let settled = false;

    const cleanup = (duration: number) => {
      if (settled) return;
      settled = true;
      audio.removeAttribute('src');
      audio.load();
      URL.revokeObjectURL(url);
      resolve(Number.isFinite(duration) ? duration : 0);
    };

    const timer = window.setTimeout(() => cleanup(0), 4000);

    audio.preload = 'metadata';
    audio.onloadedmetadata = () => {
      window.clearTimeout(timer);
      cleanup(audio.duration);
    };
    audio.onerror = () => {
      window.clearTimeout(timer);
      cleanup(0);
    };
    audio.src = url;
  });
}

export async function extractAudioMetadata(
  file: File,
  fallbackArtist: string,
  fallbackAlbum: string
): Promise<ParsedAudioMetadata> {
  const ext = (file.name.split('.').pop() || 'AUDIO').toUpperCase();
  const headerSlice = file.slice(0, Math.min(file.size, 2 * 1024 * 1024));
  const buffer = await headerSlice.arrayBuffer();

  let tags: Partial<ParsedAudioMetadata> = {};
  if (ext === 'MP3' || ext === 'AAC' || ext === 'WAV') {
    tags = parseId3v2(buffer);
  } else if (ext === 'FLAC') {
    tags = parseFlacMetadata(buffer);
  } else if (ext === 'M4A' || ext === 'MP4' || ext === 'ALAC') {
    tags = parseMp4Metadata(buffer);
  } else {
    tags = parseId3v2(buffer);
  }

  const guess = cleanFileNameToTrackGuess(file.name);
  const duration = await readAudioDuration(file);

  return {
    title: tags.title || guess.title || file.name,
    artist: tags.artist || guess.artist || fallbackArtist,
    album: tags.album || fallbackAlbum,
    duration,
    coverBlob: tags.coverBlob,
    formatLabel: ext,
  };
}

export interface TrackColorPalette {
  accent: string; // Vibrant bright foreground accent (buttons, active icons, sliders)
  glow: string; // Rich saturated mid-tone for ambient glows & glass tinting
  secondary: string; // Complementary/secondary gradient hue
}

export const MONOCHROME_PALETTE: TrackColorPalette = {
  accent: '#F5F5F5',
  glow: '#141414',
  secondary: '#1F1F1F',
};

export function getFallbackPaletteForSeed(_seed?: string): TrackColorPalette {
  return MONOCHROME_PALETTE;
}

function rgbToHsl(r: number, g: number, b: number): [number, number, number] {
  r /= 255;
  g /= 255;
  b /= 255;
  const max = Math.max(r, g, b);
  const min = Math.min(r, g, b);
  let h = 0;
  let s = 0;
  const l = (max + min) / 2;

  if (max !== min) {
    const d = max - min;
    s = l > 0.5 ? d / (2 - max - min) : d / (max + min);
    switch (max) {
      case r:
        h = (g - b) / d + (g < b ? 6 : 0);
        break;
      case g:
        h = (b - r) / d + 2;
        break;
      case b:
        h = (r - g) / d + 4;
        break;
    }
    h /= 6;
  }
  return [h * 360, s, l];
}

function hslToHex(h: number, s: number, l: number): string {
  const hue = ((h % 360) + 360) % 360;
  const c = (1 - Math.abs(2 * l - 1)) * s;
  const x = c * (1 - Math.abs(((hue / 60) % 2) - 1));
  const m = l - c / 2;
  let r = 0;
  let g = 0;
  let b = 0;

  if (hue < 60) [r, g, b] = [c, x, 0];
  else if (hue < 120) [r, g, b] = [x, c, 0];
  else if (hue < 180) [r, g, b] = [0, c, x];
  else if (hue < 240) [r, g, b] = [0, x, c];
  else if (hue < 300) [r, g, b] = [x, 0, c];
  else [r, g, b] = [c, 0, x];

  const toByte = (n: number) =>
    Math.min(255, Math.max(0, Math.round((n + m) * 255)))
      .toString(16)
      .padStart(2, '0');

  return `#${toByte(r)}${toByte(g)}${toByte(b)}`;
}

function extractPaletteFromImageElement(img: HTMLImageElement, _seed: string): TrackColorPalette {
  const canvas = document.createElement('canvas');
  canvas.width = 32;
  canvas.height = 32;
  const ctx = canvas.getContext('2d');
  if (!ctx) return MONOCHROME_PALETTE;

  ctx.drawImage(img, 0, 0, 32, 32);
  const { data } = ctx.getImageData(0, 0, 32, 32);

  // Bucket hues into 12 sectors (30 deg each) to find the most vibrant dominant color
  const buckets = Array.from({ length: 12 }, () => ({
    weight: 0,
    r: 0,
    g: 0,
    b: 0,
  }));

  let validMidtonePixels = 0;
  let colorfulPixels = 0;

  for (let i = 0; i < data.length; i += 4) {
    const r = data[i];
    const g = data[i + 1];
    const b = data[i + 2];
    const maxDiff = Math.max(r, g, b) - Math.min(r, g, b);
    const [h, s, l] = rgbToHsl(r, g, b);

    if (l >= 0.08 && l <= 0.94) {
      validMidtonePixels++;
      // Require real RGB channel separation (>= 30) and saturation (>= 0.22)
      // so grayscale JPEG compression noise never triggers a fake blue tint
      if (s >= 0.22 && maxDiff >= 30) {
        colorfulPixels++;
      }
    }

    // Ignore near-black, near-white, or low-saturation/grayscale pixels
    if (l < 0.1 || l > 0.93 || s < 0.22 || maxDiff < 30) continue;

    const bucketIndex = Math.floor(h / 30) % 12;
    const weight = s * s * (1 - Math.abs(l - 0.52));
    buckets[bucketIndex].weight += weight;
    buckets[bucketIndex].r += r * weight;
    buckets[bucketIndex].g += g * weight;
    buckets[bucketIndex].b += b * weight;
  }

  // If the artwork is Black & White / Monochrome (< 10% colorful pixels), return clean silver-white!
  const colorfulRatio = validMidtonePixels > 0 ? colorfulPixels / validMidtonePixels : 0;
  if (colorfulRatio < 0.1) {
    return MONOCHROME_PALETTE;
  }

  const sorted = [...buckets].sort((a, b) => b.weight - a.weight);
  const best = sorted[0];

  if (!best || best.weight <= 0.05) {
    return MONOCHROME_PALETTE;
  }

  const avgR = best.r / best.weight;
  const avgG = best.g / best.weight;
  const avgB = best.b / best.weight;
  const [domH, domS] = rgbToHsl(avgR, avgG, avgB);

  if (domS < 0.2) {
    return MONOCHROME_PALETTE;
  }

  const clampedS = Math.max(0.52, Math.min(0.92, domS * 1.18));
  const accent = hslToHex(domH, clampedS, 0.68);
  const glow = hslToHex(domH, Math.min(0.92, clampedS * 1.05), 0.48);

  const secondBucket = sorted[1] && sorted[1].weight > best.weight * 0.25 ? sorted[1] : null;
  let secH = (domH + 32) % 360;
  if (secondBucket) {
    const [h2] = rgbToHsl(
      secondBucket.r / secondBucket.weight,
      secondBucket.g / secondBucket.weight,
      secondBucket.b / secondBucket.weight
    );
    secH = h2;
  }
  const secondary = hslToHex(secH, Math.max(0.45, clampedS * 0.85), 0.54);

  return { accent, glow, secondary };
}

export async function extractPaletteFromCoverUrl(
  coverUrl: string | undefined,
  seed: string
): Promise<TrackColorPalette> {
  if (!coverUrl) return MONOCHROME_PALETTE;

  return new Promise((resolve) => {
    const img = new Image();
    img.crossOrigin = 'anonymous';
    img.onload = () => {
      try {
        resolve(extractPaletteFromImageElement(img, seed));
      } catch {
        resolve(getFallbackPaletteForSeed(seed));
      }
    };
    img.onerror = () => resolve(getFallbackPaletteForSeed(seed));
    img.src = coverUrl;
  });
}

/**
 * Extracts a vibrant, high-contrast accent color from an album cover blob
 * (or generates a distinct fallback color from the track filename/title).
 */
export async function extractAdaptiveAccent(
  coverBlob?: Blob,
  seed = DEFAULT_ACCENT
): Promise<string> {
  if (!coverBlob) return getFallbackPaletteForSeed(seed).accent;

  return new Promise((resolve) => {
    const img = new Image();
    const url = URL.createObjectURL(coverBlob);

    const finish = (hex: string) => {
      URL.revokeObjectURL(url);
      resolve(hex);
    };

    img.onload = () => {
      try {
        const palette = extractPaletteFromImageElement(img, seed);
        finish(palette.accent);
      } catch {
        finish(getFallbackPaletteForSeed(seed).accent);
      }
    };

    img.onerror = () => finish(getFallbackPaletteForSeed(seed).accent);
    img.src = url;
  });
}
