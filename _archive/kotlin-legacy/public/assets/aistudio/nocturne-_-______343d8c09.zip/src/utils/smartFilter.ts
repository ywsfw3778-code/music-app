import type { AppSettings, ExclusionReason, Track } from '../types/music';

const RECORDING_PATH_PATTERNS: Array<{ pattern: RegExp; label: string }> = [
  { pattern: /(^|\/)(recordings?|voice[\s_-]?notes?|voice[\s_-]?memos?|sound[\s_-]?recorder|call[\s_-]?recordings?|calls?|miui\/sound_recorder|samsung\/voice recorder)(\/|$)/i, label: 'Recordings folder' },
  { pattern: /(whatsapp[\s_-]?(audio|voice|ptt)|telegram[\s_-]?(audio|voice)|viber[\s_-]?audio|messenger[\s_-]?voice)/i, label: 'Messaging voice note' },
  { pattern: /(^|\/)(notifications?|ringtones?|alarms?|ui|system\/media)(\/|$)/i, label: 'System audio folder' },
  { pattern: /^(ptt[-_]|aud[-_]\d{8}[-_]wa|voice[-_]?\d+|rec[-_]?\d+|recording[-_\s]?\d*|call[-_]?rec|memo[-_]?\d+|vn[-_]?\d+)/i, label: 'Voice note filename' },
  { pattern: /(تسجيل|مكالمة|ملاحظة[\s_-]?صوتية|رسالة[\s_-]?صوتية|فويس)/i, label: 'Arabic recording tag' },
];

const RECORDING_EXTENSIONS = new Set(['amr', '3gp', '3gpp', 'awb', 'qcp', 'spx']);

export const SUPPORTED_AUDIO_EXTENSIONS = new Set([
  'mp3',
  'm4a',
  'aac',
  'flac',
  'wav',
  'ogg',
  'opus',
  'webm',
  'wma',
  'aiff',
  'alac',
  'amr',
  '3gp',
]);

export function isSupportedAudioFile(file: File): boolean {
  const ext = file.name.split('.').pop()?.toLowerCase() ?? '';
  if (SUPPORTED_AUDIO_EXTENSIONS.has(ext)) return true;
  return file.type.startsWith('audio/');
}

export function evaluateTrackExclusion(
  params: {
    fileName: string;
    folderPath: string;
    duration: number;
    manuallyRestored?: boolean;
  },
  settings: AppSettings
): { exclusionReason: ExclusionReason; matchedRule?: string } {
  if (params.manuallyRestored) {
    return { exclusionReason: null };
  }

  const ext = params.fileName.split('.').pop()?.toLowerCase() ?? '';
  const combinedPath = `${params.folderPath}/${params.fileName}`.replace(/^\/+/, '');

  if (settings.autoExcludeRecordings) {
    if (RECORDING_EXTENSIONS.has(ext)) {
      return { exclusionReason: 'recording', matchedRule: `.${ext} voice format` };
    }

    for (const rule of RECORDING_PATH_PATTERNS) {
      if (rule.pattern.test(combinedPath) || rule.pattern.test(params.fileName)) {
        return { exclusionReason: 'recording', matchedRule: rule.label };
      }
    }

    for (const keyword of settings.customExcludeKeywords) {
      const clean = keyword.trim().toLowerCase();
      if (clean.length >= 2 && combinedPath.toLowerCase().includes(clean)) {
        return { exclusionReason: 'recording', matchedRule: `Keyword: ${keyword.trim()}` };
      }
    }
  }

  if (params.duration > 0 && params.duration < settings.minDurationSeconds) {
    return {
      exclusionReason: 'short_duration',
      matchedRule: `< ${settings.minDurationSeconds}s`,
    };
  }

  return { exclusionReason: null };
}

export function reevaluateTracksWithSettings(tracks: Track[], settings: AppSettings): Track[] {
  return tracks.map((track) => {
    const result = evaluateTrackExclusion(
      {
        fileName: track.fileName,
        folderPath: track.folderPath,
        duration: track.duration,
        manuallyRestored: track.manuallyRestored,
      },
      settings
    );
    return {
      ...track,
      exclusionReason: result.exclusionReason,
      matchedRule: result.matchedRule,
    };
  });
}

export function formatDuration(seconds: number): string {
  if (!Number.isFinite(seconds) || seconds < 0) return '00:00';
  const totalSec = Math.floor(seconds);
  const hrs = Math.floor(totalSec / 3600);
  const mins = Math.floor((totalSec % 3600) / 60);
  const secs = totalSec % 60;
  const mm = String(mins).padStart(2, '0');
  const ss = String(secs).padStart(2, '0');
  if (hrs > 0) {
    return `${hrs}:${mm}:${ss}`;
  }
  return `${mm}:${ss}`;
}

export function formatFileSize(bytes: number): string {
  if (!Number.isFinite(bytes) || bytes <= 0) return '0 MB';
  if (bytes < 1024 * 1024) {
    return `${Math.max(1, Math.round(bytes / 1024))} KB`;
  }
  return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
}
