import type { LyricLine, LyricsData, Track } from '../types/music';
import { cleanFileNameToTrackGuess } from './audioMetadata';

const LRCLIB_HEADERS = {
  'Lrclib-Client': 'NocturneAMOLEDPlayer/1.0 (https://nocturne-player.local)',
};

export interface LrclibSearchResult {
  id: number;
  trackName: string;
  artistName: string;
  albumName?: string;
  duration?: number;
  syncedLyrics?: string | null;
  plainLyrics?: string | null;
}

export function parseLrcText(lrc: string): LyricLine[] {
  const lines: LyricLine[] = [];
  const rawLines = lrc.split(/\r?\n/);
  const timestampRegex = /\[(\d{1,2}):(\d{2})(?:[.:](\d{1,3}))?\]/g;

  for (const rawLine of rawLines) {
    const matches = [...rawLine.matchAll(timestampRegex)];
    if (matches.length === 0) continue;

    const text = rawLine.replace(timestampRegex, '').trim();
    if (!text) continue;

    for (const match of matches) {
      const mins = parseInt(match[1], 10);
      const secs = parseInt(match[2], 10);
      const fracRaw = match[3] || '0';
      const fracMs =
        fracRaw.length === 3
          ? parseInt(fracRaw, 10)
          : fracRaw.length === 2
          ? parseInt(fracRaw, 10) * 10
          : parseInt(fracRaw, 10) * 100;
      const timeMs = mins * 60_000 + secs * 1000 + fracMs;
      lines.push({ timeMs, text });
    }
  }

  return lines.sort((a, b) => a.timeMs - b.timeMs);
}

function isUnknownField(val: string): boolean {
  const lower = val.toLowerCase();
  return (
    !val.trim() ||
    lower === 'unknown artist' ||
    lower === 'unknown album' ||
    val.includes('غير معروف') ||
    val.includes('غير محدد')
  );
}

export async function fetchSyncedLyricsForTrack(track: Track): Promise<LyricsData> {
  const guess = cleanFileNameToTrackGuess(track.fileName);
  const queryTitle = track.title || guess.title;
  const queryArtist = isUnknownField(track.artist) ? guess.artist : track.artist;

  // 1. Try exact /api/get if we have both title and artist
  if (queryTitle && queryArtist) {
    try {
      const params = new URLSearchParams({
        track_name: queryTitle,
        artist_name: queryArtist,
      });
      if (track.duration > 0) {
        params.set('duration', String(Math.round(track.duration)));
      }
      const res = await fetch(`https://lrclib.net/api/get?${params.toString()}`, {
        headers: LRCLIB_HEADERS,
      });
      if (res.ok) {
        const data = (await res.json()) as LrclibSearchResult;
        if (data.syncedLyrics || data.plainLyrics) {
          return {
            trackId: track.id,
            syncedLines: data.syncedLyrics ? parseLrcText(data.syncedLyrics) : [],
            plainLyrics: data.plainLyrics || '',
            offsetMs: 0,
            source: 'lrclib',
            matchedTitle: data.trackName,
            matchedArtist: data.artistName,
            fetchedAt: Date.now(),
          };
        }
      }
    } catch {
      // Fallback to search endpoint
    }
  }

  // 2. Fallback to /api/search with query
  const searchQuery = [queryArtist, queryTitle].filter(Boolean).join(' ').trim();
  if (searchQuery) {
    try {
      const results = await searchLrclibLyrics(searchQuery);
      const best =
        results.find((item) => item.syncedLyrics && item.syncedLyrics.trim().length > 0) ||
        results.find((item) => item.plainLyrics && item.plainLyrics.trim().length > 0);

      if (best) {
        return {
          trackId: track.id,
          syncedLines: best.syncedLyrics ? parseLrcText(best.syncedLyrics) : [],
          plainLyrics: best.plainLyrics || '',
          offsetMs: 0,
          source: 'lrclib',
          matchedTitle: best.trackName,
          matchedArtist: best.artistName,
          fetchedAt: Date.now(),
        };
      }
    } catch {
      // Network error or rate limit
    }
  }

  return {
    trackId: track.id,
    syncedLines: [],
    plainLyrics: '',
    offsetMs: 0,
    source: 'none',
    fetchedAt: Date.now(),
  };
}

export async function searchLrclibLyrics(query: string): Promise<LrclibSearchResult[]> {
  const clean = query.trim();
  if (!clean) return [];

  const params = new URLSearchParams({ q: clean });
  const res = await fetch(`https://lrclib.net/api/search?${params.toString()}`, {
    headers: LRCLIB_HEADERS,
  });

  if (!res.ok) {
    throw new Error(`LRCLIB returned ${res.status}`);
  }

  const data = (await res.json()) as LrclibSearchResult[];
  return Array.isArray(data) ? data.slice(0, 15) : [];
}

export function buildLyricsDataFromResult(
  trackId: string,
  result: LrclibSearchResult
): LyricsData {
  return {
    trackId,
    syncedLines: result.syncedLyrics ? parseLrcText(result.syncedLyrics) : [],
    plainLyrics: result.plainLyrics || '',
    offsetMs: 0,
    source: 'lrclib',
    matchedTitle: result.trackName,
    matchedArtist: result.artistName,
    fetchedAt: Date.now(),
  };
}
