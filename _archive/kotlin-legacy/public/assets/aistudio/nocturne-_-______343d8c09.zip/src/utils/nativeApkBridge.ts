/**
 * Native Phone System Media & Permissions Bridge (Android APK / Realme 11 System Mini Capsule)
 *
 * Connects the audio engine directly to the phone's operating system (Android MediaSessionCompat,
 * Foreground Service MediaStyle Notification, Runtime Notification & Audio Permissions, and WakeLock)
 * so the phone's own native Dynamic Island / Realme 11 Mini Capsule operates automatically
 * without rendering any fake capsule inside the app.
 */

export interface NativeMediaSessionPayload {
  trackId: string;
  title: string;
  artist: string;
  album: string;
  durationMs: number;
  positionMs: number;
  isPlaying: boolean;
  artworkBase64: string; // data:image/jpeg;base64,... (512x512 square bitmap)
  accentColor: string;
}

export type NativeMediaActionType =
  | 'play'
  | 'pause'
  | 'toggle'
  | 'next'
  | 'prev'
  | 'seek'
  | 'stop';

export interface SystemPermissionsState {
  notificationsGranted: boolean;
  mediaSessionActive: boolean;
  wakeLockActive: boolean;
  nativeServiceConnected: boolean;
}

interface AndroidMediaBridgeInterface {
  updateMediaSession?: (jsonPayload: string) => void;
  updatePlaybackState?: (isPlaying: boolean, positionMs: number, durationMs: number) => void;
  stopMediaService?: () => void;
  requestSystemPermissions?: () => boolean;
  hasNotificationPermission?: () => boolean;
  openCapsuleSystemSettings?: () => void;
}

interface CapacitorMediaSessionPlugin {
  setMetadata?: (opts: {
    title: string;
    artist: string;
    album: string;
    artwork: Array<{ src: string; sizes: string; type: string }>;
  }) => Promise<void>;
  setPlaybackState?: (opts: { playbackState: 'playing' | 'paused' | 'none' }) => Promise<void>;
  setPositionState?: (opts: {
    duration: number;
    playbackRate: number;
    position: number;
  }) => Promise<void>;
  setActionHandler?: (
    opts: { action: string },
    callback: (details?: { seekTime?: number }) => void
  ) => Promise<void>;
}

interface CordovaMusicControls {
  create?: (
    options: Record<string, unknown>,
    onSuccess?: () => void,
    onError?: () => void
  ) => void;
  updateIsPlaying?: (isPlaying: boolean) => void;
  updateElapsed?: (args: { elapsed: number; isPlaying: boolean }) => void;
  destroy?: () => void;
  subscribe?: (callback: (action: string) => void) => void;
  listen?: () => void;
}

declare global {
  interface Window {
    AndroidMediaBridge?: AndroidMediaBridgeInterface;
    __onNativeMediaAction?: (action: NativeMediaActionType, value?: number) => void;
    __onNativePermissionResult?: (granted: boolean) => void;
    Capacitor?: {
      isNativePlatform?: () => boolean;
      Plugins?: {
        MediaSession?: CapacitorMediaSessionPlugin;
      };
    };
    MusicControls?: CordovaMusicControls;
  }
}

class NativeApkMediaBridge {
  private actionListener: ((action: NativeMediaActionType, value?: number) => void) | null = null;
  private isBound = false;
  private wakeLockSentinel: WakeLockSentinel | null = null;
  private permissionsRequestedOnce = false;

  public bindActionHandler(handler: (action: NativeMediaActionType, value?: number) => void) {
    this.actionListener = handler;

    window.__onNativeMediaAction = (action: NativeMediaActionType, value?: number) => {
      this.actionListener?.(action, value);
    };

    if (this.isBound) return;
    this.isBound = true;

    const capMedia = window.Capacitor?.Plugins?.MediaSession;
    if (capMedia?.setActionHandler) {
      void capMedia.setActionHandler({ action: 'play' }, () => this.actionListener?.('play'));
      void capMedia.setActionHandler({ action: 'pause' }, () => this.actionListener?.('pause'));
      void capMedia.setActionHandler({ action: 'nexttrack' }, () => this.actionListener?.('next'));
      void capMedia.setActionHandler({ action: 'previoustrack' }, () =>
        this.actionListener?.('prev')
      );
      void capMedia.setActionHandler({ action: 'seekto' }, (details) => {
        if (typeof details?.seekTime === 'number') {
          this.actionListener?.('seek', details.seekTime);
        }
      });
      void capMedia.setActionHandler({ action: 'stop' }, () => this.actionListener?.('stop'));
    }

    const musicControls = window.MusicControls;
    if (musicControls?.subscribe && musicControls?.listen) {
      musicControls.subscribe((rawEvent: string) => {
        try {
          const parsed = JSON.parse(rawEvent) as { message?: string; position?: number };
          const msg = parsed.message || rawEvent;
          if (msg === 'music-controls-play') this.actionListener?.('play');
          else if (msg === 'music-controls-pause') this.actionListener?.('pause');
          else if (msg === 'music-controls-next') this.actionListener?.('next');
          else if (msg === 'music-controls-previous') this.actionListener?.('prev');
          else if (msg === 'music-controls-seek-to' && typeof parsed.position === 'number') {
            this.actionListener?.('seek', parsed.position);
          } else if (msg === 'music-controls-destroy') {
            this.actionListener?.('stop');
          }
        } catch {
          // Ignore malformed event
        }
      });
      musicControls.listen();
    }
  }

  /**
   * Requests Android 13/14 POST_NOTIFICATIONS, READ_MEDIA_AUDIO, and Foreground Service permissions
   * required by Realme 11's system Mini Capsule to display the ongoing MediaStyle notification.
   */
  public async requestPhoneSystemPermissions(): Promise<boolean> {
    let granted = false;

    // 1. Trigger native Android runtime permission dialog if running in APK WebView bridge
    if (window.AndroidMediaBridge?.requestSystemPermissions) {
      try {
        granted = Boolean(window.AndroidMediaBridge.requestSystemPermissions());
      } catch {
        // Ignore
      }
    }

    // 2. Request OS Notification permission via standard API (triggers Android POST_NOTIFICATIONS prompt)
    if (typeof window !== 'undefined' && 'Notification' in window) {
      try {
        if (Notification.permission === 'granted') {
          granted = true;
        } else if (Notification.permission !== 'denied') {
          const res = await Notification.requestPermission();
          if (res === 'granted') granted = true;
        }
      } catch {
        // Ignore
      }
    }

    // 3. Acquire WakeLock so playback and system media session never drop when screen turns off
    await this.acquireWakeLock();

    return granted;
  }

  public ensurePermissionsOnFirstPlay() {
    if (this.permissionsRequestedOnce) return;
    this.permissionsRequestedOnce = true;
    void this.requestPhoneSystemPermissions();
  }

  public async acquireWakeLock() {
    if (typeof navigator === 'undefined' || !('wakeLock' in navigator)) return;
    try {
      if (!this.wakeLockSentinel) {
        this.wakeLockSentinel = await navigator.wakeLock.request('screen');
        this.wakeLockSentinel.addEventListener('release', () => {
          this.wakeLockSentinel = null;
        });
      }
    } catch {
      // Ignore if WakeLock is not permitted in current context
    }
  }

  public releaseWakeLock() {
    if (this.wakeLockSentinel) {
      void this.wakeLockSentinel.release().catch(() => {});
      this.wakeLockSentinel = null;
    }
  }

  public getSystemPermissionsState(): SystemPermissionsState {
    let notificationsGranted = false;
    if (window.AndroidMediaBridge?.hasNotificationPermission) {
      try {
        notificationsGranted = Boolean(window.AndroidMediaBridge.hasNotificationPermission());
      } catch {
        // Ignore
      }
    } else if (typeof window !== 'undefined' && 'Notification' in window) {
      notificationsGranted = Notification.permission === 'granted';
    }

    return {
      notificationsGranted,
      mediaSessionActive: typeof navigator !== 'undefined' && 'mediaSession' in navigator,
      wakeLockActive: Boolean(this.wakeLockSentinel),
      nativeServiceConnected: Boolean(
        window.AndroidMediaBridge ||
          window.Capacitor?.isNativePlatform?.() ||
          window.MusicControls
      ),
    };
  }

  public openPhoneCapsuleSettings() {
    if (window.AndroidMediaBridge?.openCapsuleSystemSettings) {
      try {
        window.AndroidMediaBridge.openCapsuleSystemSettings();
      } catch {
        // Ignore
      }
    }
  }

  public publishMetadataAndState(payload: NativeMediaSessionPayload) {
    this.ensurePermissionsOnFirstPlay();
    if (payload.isPlaying) {
      void this.acquireWakeLock();
    }

    // 1. Native Android JavascriptInterface (Android Studio APK / RealmeMediaPlaybackService)
    if (window.AndroidMediaBridge?.updateMediaSession) {
      try {
        window.AndroidMediaBridge.updateMediaSession(JSON.stringify(payload));
      } catch {
        // Ignore bridge error
      }
    }

    // 2. Capacitor MediaSession Plugin
    const capMedia = window.Capacitor?.Plugins?.MediaSession;
    if (capMedia) {
      try {
        void capMedia.setMetadata?.({
          title: payload.title,
          artist: payload.artist,
          album: payload.album,
          artwork: [
            { src: payload.artworkBase64, sizes: '512x512', type: 'image/jpeg' },
          ],
        });
        void capMedia.setPlaybackState?.({
          playbackState: payload.isPlaying ? 'playing' : 'paused',
        });
        if (payload.durationMs > 0) {
          void capMedia.setPositionState?.({
            duration: payload.durationMs / 1000,
            playbackRate: 1,
            position: Math.min(payload.durationMs, payload.positionMs) / 1000,
          });
        }
      } catch {
        // Ignore
      }
    }

    // 3. Cordova MusicControls Plugin
    const musicControls = window.MusicControls;
    if (musicControls?.create) {
      try {
        musicControls.create({
          track: payload.title,
          artist: payload.artist,
          album: payload.album,
          cover: payload.artworkBase64,
          isPlaying: payload.isPlaying,
          dismissable: false,
          hasPrev: true,
          hasNext: true,
          hasClose: true,
          duration: Math.round(payload.durationMs / 1000),
          elapsed: Math.round(payload.positionMs / 1000),
        });
      } catch {
        // Ignore
      }
    }
  }

  public publishPositionAndState(isPlaying: boolean, positionSec: number, durationSec: number) {
    const posMs = Math.round(Math.max(0, positionSec) * 1000);
    const durMs = Math.round(Math.max(0, durationSec) * 1000);

    if (!isPlaying) {
      this.releaseWakeLock();
    }

    if (window.AndroidMediaBridge?.updatePlaybackState) {
      try {
        window.AndroidMediaBridge.updatePlaybackState(isPlaying, posMs, durMs);
      } catch {
        // Ignore
      }
    }

    const capMedia = window.Capacitor?.Plugins?.MediaSession;
    if (capMedia) {
      try {
        void capMedia.setPlaybackState?.({
          playbackState: isPlaying ? 'playing' : 'paused',
        });
        if (durationSec > 0) {
          void capMedia.setPositionState?.({
            duration: Math.max(5, durationSec),
            playbackRate: 1,
            position: Math.min(durationSec, Math.max(0, positionSec)),
          });
        }
      } catch {
        // Ignore
      }
    }

    const musicControls = window.MusicControls;
    if (musicControls) {
      try {
        musicControls.updateIsPlaying?.(isPlaying);
        musicControls.updateElapsed?.({
          elapsed: Math.round(positionSec),
          isPlaying,
        });
      } catch {
        // Ignore
      }
    }
  }

  public stopNativeSession() {
    this.releaseWakeLock();
    if (window.AndroidMediaBridge?.stopMediaService) {
      try {
        window.AndroidMediaBridge.stopMediaService();
      } catch {
        // Ignore
      }
    }
    const capMedia = window.Capacitor?.Plugins?.MediaSession;
    if (capMedia?.setPlaybackState) {
      void capMedia.setPlaybackState({ playbackState: 'none' });
    }
    window.MusicControls?.destroy?.();
  }
}

export const nativeApkBridge = new NativeApkMediaBridge();
