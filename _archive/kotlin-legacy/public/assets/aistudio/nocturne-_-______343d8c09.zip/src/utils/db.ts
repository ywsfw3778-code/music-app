import type { AppSettings, LyricsData, Playlist, Track } from '../types/music';

const DB_NAME = 'nocturne_amoled_player_db';
const DB_VERSION = 1;
const STORE_TRACKS = 'tracks';
const STORE_LYRICS = 'lyrics';
const SETTINGS_KEY = 'nocturne_settings_v1';
const PLAYLISTS_KEY = 'nocturne_playlists_v1';

export const DEFAULT_SETTINGS: AppSettings = {
  language: 'ar',
  crossfadeEnabled: true,
  crossfadeSeconds: 4,
  minDurationSeconds: 30,
  autoExcludeRecordings: true,
  customExcludeKeywords: [],
  dynamicArtworkAccent: true,
  artworkBackgroundMode: 'full',
};

interface StoredTrackRecord {
  id: string;
  title: string;
  artist: string;
  album: string;
  duration: number;
  folderPath: string;
  fileName: string;
  mimeType: string;
  fileSize: number;
  formatLabel: string;
  coverBlob?: Blob;
  accentColor: string;
  audioBlob: Blob;
  isFavorite: boolean;
  addedAt: number;
  exclusionReason: Track['exclusionReason'];
  matchedRule?: string;
  manuallyRestored: boolean;
}

function openDatabase(): Promise<IDBDatabase> {
  return new Promise((resolve, reject) => {
    const request = indexedDB.open(DB_NAME, DB_VERSION);

    request.onupgradeneeded = () => {
      const db = request.result;
      if (!db.objectStoreNames.contains(STORE_TRACKS)) {
        db.createObjectStore(STORE_TRACKS, { keyPath: 'id' });
      }
      if (!db.objectStoreNames.contains(STORE_LYRICS)) {
        db.createObjectStore(STORE_LYRICS, { keyPath: 'trackId' });
      }
    };

    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(request.error);
  });
}

export function loadSettings(): AppSettings {
  try {
    const raw = localStorage.getItem(SETTINGS_KEY);
    if (!raw) return DEFAULT_SETTINGS;
    return { ...DEFAULT_SETTINGS, ...JSON.parse(raw) };
  } catch {
    return DEFAULT_SETTINGS;
  }
}

export function saveSettings(settings: AppSettings): void {
  try {
    localStorage.setItem(SETTINGS_KEY, JSON.stringify(settings));
  } catch {
    // Ignore quota errors
  }
}

export function loadPlaylists(): Playlist[] {
  try {
    const raw = localStorage.getItem(PLAYLISTS_KEY);
    if (!raw) return [];
    const parsed = JSON.parse(raw);
    return Array.isArray(parsed) ? parsed : [];
  } catch {
    return [];
  }
}

export function savePlaylists(playlists: Playlist[]): void {
  try {
    localStorage.setItem(PLAYLISTS_KEY, JSON.stringify(playlists));
  } catch {
    // Ignore quota errors
  }
}

export async function loadAllTracksFromDB(): Promise<Track[]> {
  try {
    const db = await openDatabase();
    return await new Promise((resolve, reject) => {
      const tx = db.transaction(STORE_TRACKS, 'readonly');
      const store = tx.objectStore(STORE_TRACKS);
      const req = store.getAll();
      req.onsuccess = () => {
        const records = (req.result as StoredTrackRecord[]) || [];
        const hydrated: Track[] = records.map((rec) => ({
          ...rec,
          coverUrl: rec.coverBlob ? URL.createObjectURL(rec.coverBlob) : undefined,
        }));
        resolve(hydrated);
      };
      req.onerror = () => reject(req.error);
    });
  } catch {
    return [];
  }
}

export async function saveTracksToDB(tracks: Track[]): Promise<void> {
  if (tracks.length === 0) return;
  const db = await openDatabase();
  await new Promise<void>((resolve, reject) => {
    const tx = db.transaction(STORE_TRACKS, 'readwrite');
    const store = tx.objectStore(STORE_TRACKS);
    for (const track of tracks) {
      const record: StoredTrackRecord = {
        id: track.id,
        title: track.title,
        artist: track.artist,
        album: track.album,
        duration: track.duration,
        folderPath: track.folderPath,
        fileName: track.fileName,
        mimeType: track.mimeType,
        fileSize: track.fileSize,
        formatLabel: track.formatLabel,
        coverBlob: track.coverBlob,
        accentColor: track.accentColor,
        audioBlob: track.audioBlob,
        isFavorite: track.isFavorite,
        addedAt: track.addedAt,
        exclusionReason: track.exclusionReason,
        matchedRule: track.matchedRule,
        manuallyRestored: track.manuallyRestored,
      };
      store.put(record);
    }
    tx.oncomplete = () => resolve();
    tx.onerror = () => reject(tx.error);
  });
}

export async function deleteTrackFromDB(trackId: string): Promise<void> {
  const db = await openDatabase();
  await new Promise<void>((resolve, reject) => {
    const tx = db.transaction([STORE_TRACKS, STORE_LYRICS], 'readwrite');
    tx.objectStore(STORE_TRACKS).delete(trackId);
    tx.objectStore(STORE_LYRICS).delete(trackId);
    tx.oncomplete = () => resolve();
    tx.onerror = () => reject(tx.error);
  });
}

export async function clearAllStorageDB(): Promise<void> {
  try {
    localStorage.removeItem(PLAYLISTS_KEY);
  } catch {
    // Ignore
  }
  const db = await openDatabase();
  await new Promise<void>((resolve, reject) => {
    const tx = db.transaction([STORE_TRACKS, STORE_LYRICS], 'readwrite');
    tx.objectStore(STORE_TRACKS).clear();
    tx.objectStore(STORE_LYRICS).clear();
    tx.oncomplete = () => resolve();
    tx.onerror = () => reject(tx.error);
  });
}

export async function loadLyricsFromDB(trackId: string): Promise<LyricsData | null> {
  try {
    const db = await openDatabase();
    return await new Promise((resolve) => {
      const tx = db.transaction(STORE_LYRICS, 'readonly');
      const req = tx.objectStore(STORE_LYRICS).get(trackId);
      req.onsuccess = () => resolve((req.result as LyricsData) || null);
      req.onerror = () => resolve(null);
    });
  } catch {
    return null;
  }
}

export async function saveLyricsToDB(lyrics: LyricsData): Promise<void> {
  try {
    const db = await openDatabase();
    await new Promise<void>((resolve) => {
      const tx = db.transaction(STORE_LYRICS, 'readwrite');
      tx.objectStore(STORE_LYRICS).put(lyrics);
      tx.oncomplete = () => resolve();
      tx.onerror = () => resolve();
    });
  } catch {
    // Ignore errors
  }
}
