package com.nocturne.sukoon.player

import android.app.PendingIntent
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.net.Uri
import androidx.annotation.OptIn
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.Player
import androidx.media3.common.util.UnstableApi
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.session.DefaultMediaNotificationProvider
import androidx.media3.session.MediaSession
import androidx.media3.session.MediaSessionService
import java.io.ByteArrayOutputStream

/**
 * PlaybackService المتوافق مع Android 15 وواجهة Realme UI 6.0 (ColorOS 15) Live Alerts / Dynamic Island.
 *
 * يرث من `MediaSessionService` (مكتبة Media3) ويربط `ExoPlayer` بـ `MediaSession`
 * مع ضمان عدم إرسال أي `MediaItem` بدون `Title` و `Artist` و `ArtworkData` صالحة.
 */
class PlaybackService : MediaSessionService() {

    private var mediaSession: MediaSession? = null
    private lateinit var player: ExoPlayer

    companion object {
        var webViewActionCallback: ((action: String, seekSec: Double?) -> Unit)? = null

        /**
         * يبني MediaItem مكتمل الـ MediaMetadata (بما في ذلك صورة غلاف احتياطية إن لم تتوفر)
         * لأن OplusMediaController في Realme UI 6.0 يرفض عرض الكبسولة إذا كانت البيانات فارغة.
         */
        fun buildRealmeCompatibleMediaItem(
            mediaId: String,
            audioUri: Uri,
            title: String,
            artist: String,
            album: String = "سُكون",
            artworkBytes: ByteArray? = null,
            artworkUri: Uri? = null
        ): MediaItem {
            val safeTitle = title.ifBlank { "مقطع صوتي" }
            val safeArtist = artist.ifBlank { "فنان غير معروف" }
            val finalArtworkBytes = artworkBytes ?: generateFallbackCoverBytes()

            val metadataBuilder = MediaMetadata.Builder()
                .setTitle(safeTitle)
                .setDisplayTitle(safeTitle)
                .setArtist(safeArtist)
                .setAlbumTitle(album.ifBlank { "سُكون" })
                .setIsPlayable(true)
                .setIsBrowsable(false)
                .setMediaType(MediaMetadata.MEDIA_TYPE_MUSIC)
                .setArtworkData(finalArtworkBytes, MediaMetadata.PICTURE_TYPE_FRONT_COVER)

            if (artworkUri != null) {
                metadataBuilder.setArtworkUri(artworkUri)
            }

            return MediaItem.Builder()
                .setMediaId(mediaId)
                .setUri(audioUri)
                .setMediaMetadata(metadataBuilder.build())
                .build()
        }

        /**
         * يولد صورة غلاف مربعة 512x512 بصيغة PNG في حال عدم وجود غلاف مدمج بالملف الصوتي
         * لضمان استجابة كبسولة Realme UI 6.0 دائماً.
         */
        fun generateFallbackCoverBytes(): ByteArray {
            val size = 512
            val bmp = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
            val canvas = Canvas(bmp)
            canvas.drawColor(Color.parseColor("#09090B"))

            val ringPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                style = Paint.Style.STROKE
                strokeWidth = 6f
                color = Color.parseColor("#27272A")
            }
            canvas.drawCircle(size / 2f, size / 2f, 180f, ringPaint)
            canvas.drawCircle(size / 2f, size / 2f, 130f, ringPaint)

            val centerPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                style = Paint.Style.FILL
                color = Color.parseColor("#F4F4F5")
            }
            canvas.drawCircle(size / 2f, size / 2f, 64f, centerPaint)

            val holePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                style = Paint.Style.FILL
                color = Color.BLACK
            }
            canvas.drawCircle(size / 2f, size / 2f, 18f, holePaint)

            val out = ByteArrayOutputStream()
            bmp.compress(Bitmap.CompressFormat.PNG, 90, out)
            return out.toByteArray()
        }
    }

    @OptIn(UnstableApi::class)
    override fun onCreate() {
        super.onCreate()

        // 1. إعداد AudioAttributes الخاصة بالموسيقى مع تفعيل AudioFocus التلقائي
        val audioAttributes = AudioAttributes.Builder()
            .setUsage(C.USAGE_MEDIA)
            .setContentType(C.AUDIO_CONTENT_TYPE_MUSIC)
            .build()

        // 2. تهيئة ExoPlayer وربطه بالـ AudioAttributes والـ WakeMode
        player = ExoPlayer.Builder(this)
            .setAudioAttributes(audioAttributes, /* handleAudioFocus = */ true)
            .setHandleAudioBecomingNoisy(true)
            .setWakeMode(C.WAKE_MODE_LOCAL)
            .build()

        // 3. إعداد PendingIntent لفتح MainActivity عند الضغط على كبسولة ريلمي (Live Alerts)
        val openActivityIntent = Intent(this, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }
        val sessionActivityPendingIntent = PendingIntent.getActivity(
            this,
            0,
            openActivityIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        // 4. إنشاء MediaSession وربطه بالـ ExoPlayer
        mediaSession = MediaSession.Builder(this, player)
            .setSessionActivity(sessionActivityPendingIntent)
            .setCallback(object : MediaSession.Callback {})
            .build()

        // 5. تفعيل مزود إشعارات Media3 القياسي المتوافق مع OplusMediaController
        val notificationProvider = DefaultMediaNotificationProvider.Builder(this)
            .build()
        setMediaNotificationProvider(notificationProvider)

        // 6. مراقبة تغييرات حالة المشغل لمزامنتها مع الواجهة
        player.addListener(object : Player.Listener {
            override fun onIsPlayingChanged(isPlaying: Boolean) {
                webViewActionCallback?.invoke(if (isPlaying) "play" else "pause", null)
            }

            override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) {
                super.onMediaItemTransition(mediaItem, reason)
            }
        })
    }

    override fun onGetSession(controllerInfo: MediaSession.ControllerInfo): MediaSession? {
        return mediaSession
    }

    override fun onTaskRemoved(rootIntent: Intent?) {
        val currentPlayer = mediaSession?.player
        if (currentPlayer == null || !currentPlayer.playWhenReady || currentPlayer.mediaItemCount == 0) {
            stopSelf()
        }
    }

    override fun onDestroy() {
        mediaSession?.run {
            player.release()
            release()
            mediaSession = null
        }
        super.onDestroy()
    }
}
