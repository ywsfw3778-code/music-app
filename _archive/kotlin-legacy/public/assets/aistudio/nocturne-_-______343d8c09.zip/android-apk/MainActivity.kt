package com.example

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.content.ComponentName
import android.content.ContentUris
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.Color
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import android.provider.Settings
import android.util.Base64
import android.util.Size
import android.webkit.JavascriptInterface
import android.webkit.MimeTypeMap
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.ComponentActivity
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.Player
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import com.google.common.util.concurrent.ListenableFuture
import com.google.common.util.concurrent.MoreExecutors
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.FilterInputStream
import java.io.InputStream
import java.util.concurrent.Executors

/**
 * MainActivity المربوط بـ PlaybackService عبر MediaController.Builder و SessionToken
 * مع فحص تلقائي لأغاني الهاتف عبر MediaStore وتقديم الصوت والصور المصغرة للـ WebView.
 */
class MainActivity : ComponentActivity() {

    private lateinit var webView: WebView
    private var controllerFuture: ListenableFuture<MediaController>? = null
    private var filePathCallback: ValueCallback<Array<Uri>>? = null
    private val scannerExecutor = Executors.newSingleThreadExecutor()

    private val fileChooserLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        val callback = filePathCallback
        filePathCallback = null
        if (callback == null) return@registerForActivityResult

        if (result.resultCode == Activity.RESULT_OK && result.data != null) {
            val data = result.data!!
            val clipData = data.clipData
            val uris = when {
                clipData != null && clipData.itemCount > 0 -> {
                    Array(clipData.itemCount) { i -> clipData.getItemAt(i).uri }
                }
                data.data != null -> arrayOf(data.data!!)
                else -> emptyArray()
            }
            callback.onReceiveValue(uris)
        } else {
            callback.onReceiveValue(null)
        }
    }

    private val mediaController: MediaController?
        get() = if (controllerFuture?.isDone == true && !controllerFuture!!.isCancelled) {
            try {
                controllerFuture?.get()
            } catch (_: Exception) {
                null
            }
        } else null

    companion object {
        private const val PERMISSION_REQUEST_CODE = 501
        private const val VIRTUAL_ASSET_HOST = "appassets.androidplatform.net"
    }

    @SuppressLint("SetJavaScriptEnabled")
    @Suppress("DEPRECATION")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        window.statusBarColor = Color.BLACK
        window.navigationBarColor = Color.BLACK

        webView = WebView(this).apply {
            setBackgroundColor(Color.BLACK)
        }
        setContentView(webView)

        webView.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            databaseEnabled = true
            mediaPlaybackRequiresUserGesture = false
            allowFileAccess = true
            allowContentAccess = true
            allowFileAccessFromFileURLs = true
            allowUniversalAccessFromFileURLs = true
            mixedContentMode = WebSettings.MIXED_CONTENT_ALWAYS_ALLOW
        }

        webView.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(
                view: WebView?,
                request: WebResourceRequest?
            ): WebResourceResponse? {
                val url = request?.url ?: return null
                if (url.host == VIRTUAL_ASSET_HOST) {
                    val rawPath = url.path?.trimStart('/') ?: "public/index.html"
                    if (rawPath.startsWith("__local_audio/")) {
                        val idStr = rawPath.removePrefix("__local_audio/").substringBefore('?')
                        val mediaId = idStr.toLongOrNull() ?: return null
                        return serveLocalAudio(mediaId, request)
                    }
                    if (rawPath.startsWith("__local_art/")) {
                        val idStr = rawPath.removePrefix("__local_art/").substringBefore('?')
                        val mediaId = idStr.toLongOrNull() ?: return null
                        val albumId = url.getQueryParameter("albumId")?.toLongOrNull() ?: 0L
                        return serveLocalArtwork(mediaId, albumId)
                    }

                    val assetPath = if (rawPath.isEmpty()) "public/index.html" else rawPath
                    return try {
                        val stream = assets.open(assetPath)
                        val ext = assetPath.substringAfterLast('.', "").lowercase()
                        val mimeType = when (ext) {
                            "html" -> "text/html"
                            "js", "mjs" -> "text/javascript"
                            "css" -> "text/css"
                            "json", "webmanifest" -> "application/json"
                            "svg" -> "image/svg+xml"
                            "png" -> "image/png"
                            "jpg", "jpeg" -> "image/jpeg"
                            "wav" -> "audio/wav"
                            else -> MimeTypeMap.getSingleton().getMimeTypeFromExtension(ext)
                                ?: "application/octet-stream"
                        }
                        WebResourceResponse(
                            mimeType,
                            "UTF-8",
                            200,
                            "OK",
                            mapOf("Access-Control-Allow-Origin" to "*"),
                            stream
                        )
                    } catch (_: Exception) {
                        null
                    }
                }
                return super.shouldInterceptRequest(view, request)
            }

            override fun onPageFinished(view: WebView?, url: String?) {
                super.onPageFinished(view, url)
                if (hasAudioReadPermission()) {
                    scanDeviceAudioAsync()
                }
            }
        }

        webView.webChromeClient = object : WebChromeClient() {
            override fun onShowFileChooser(
                webView: WebView?,
                filePathCallback: ValueCallback<Array<Uri>>?,
                fileChooserParams: FileChooserParams?
            ): Boolean {
                this@MainActivity.filePathCallback?.onReceiveValue(null)
                this@MainActivity.filePathCallback = filePathCallback

                return try {
                    val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                        addCategory(Intent.CATEGORY_OPENABLE)
                        type = "*/*"
                        putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true)
                    }
                    fileChooserLauncher.launch(intent)
                    true
                } catch (_: Exception) {
                    this@MainActivity.filePathCallback = null
                    false
                }
            }
        }

        onBackPressedDispatcher.addCallback(
            this,
            object : OnBackPressedCallback(true) {
                override fun handleOnBackPressed() {
                    if (webView.canGoBack()) {
                        webView.goBack()
                    } else {
                        isEnabled = false
                        onBackPressedDispatcher.onBackPressed()
                    }
                }
            }
        )

        webView.addJavascriptInterface(AndroidMediaBridge(), "AndroidMediaBridge")

        requestRequiredPhonePermissions()
        webView.clearCache(true)
        webView.loadUrl("https://$VIRTUAL_ASSET_HOST/public/index.html")
    }

    private fun serveLocalAudio(mediaId: Long, request: WebResourceRequest): WebResourceResponse? {
        return try {
            val audioUri = ContentUris.withAppendedId(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, mediaId)
            val mimeType = contentResolver.getType(audioUri) ?: "audio/mpeg"
            val afd = contentResolver.openAssetFileDescriptor(audioUri, "r") ?: return null
            val totalLength = afd.length
            val rangeHeader = request.requestHeaders["Range"] ?: request.requestHeaders["range"]

            if (!rangeHeader.isNullOrBlank() && rangeHeader.startsWith("bytes=") && totalLength > 0) {
                val rangeSpec = rangeHeader.removePrefix("bytes=").substringBefore(',')
                val parts = rangeSpec.split('-')
                val start = parts.getOrNull(0)?.trim()?.toLongOrNull() ?: 0L
                val endReq = parts.getOrNull(1)?.trim()?.toLongOrNull()
                val end = if (endReq != null && endReq < totalLength) endReq else (totalLength - 1)
                val contentLength = (end - start + 1).coerceAtLeast(0L)

                val rawStream = afd.createInputStream()
                var skipped = 0L
                while (skipped < start) {
                    val s = rawStream.skip(start - skipped)
                    if (s <= 0) break
                    skipped += s
                }
                val boundedStream: InputStream = object : FilterInputStream(rawStream) {
                    private var remaining = contentLength
                    override fun read(): Int {
                        if (remaining <= 0) return -1
                        val b = super.read()
                        if (b != -1) remaining--
                        return b
                    }

                    override fun read(b: ByteArray, off: Int, len: Int): Int {
                        if (remaining <= 0) return -1
                        val toRead = minOf(len.toLong(), remaining).toInt()
                        val count = super.read(b, off, toRead)
                        if (count > 0) remaining -= count
                        return count
                    }

                    override fun close() {
                        super.close()
                        try {
                            afd.close()
                        } catch (_: Exception) {
                        }
                    }
                }

                val headers = mutableMapOf(
                    "Access-Control-Allow-Origin" to "*",
                    "Accept-Ranges" to "bytes",
                    "Content-Range" to "bytes $start-$end/$totalLength",
                    "Content-Length" to contentLength.toString()
                )
                WebResourceResponse(mimeType, null, 206, "Partial Content", headers, boundedStream)
            } else {
                val rawStream = afd.createInputStream()
                val wrappedStream: InputStream = object : FilterInputStream(rawStream) {
                    override fun close() {
                        super.close()
                        try {
                            afd.close()
                        } catch (_: Exception) {
                        }
                    }
                }
                val headers = mutableMapOf(
                    "Access-Control-Allow-Origin" to "*",
                    "Accept-Ranges" to "bytes"
                )
                if (totalLength > 0) {
                    headers["Content-Length"] = totalLength.toString()
                }
                WebResourceResponse(mimeType, null, 200, "OK", headers, wrappedStream)
            }
        } catch (_: Exception) {
            null
        }
    }

    private fun loadTrackArtworkBytes(mediaId: Long, albumId: Long): ByteArray? {
        val cacheFolder = File(cacheDir, "art_cache").apply { mkdirs() }
        val artFile = File(cacheFolder, "art_$mediaId.jpg")
        val noneFile = File(cacheFolder, "art_$mediaId.none")

        if (artFile.exists() && artFile.length() > 0) {
            return try {
                artFile.readBytes()
            } catch (_: Exception) {
                null
            }
        }
        if (noneFile.exists()) {
            return null
        }

        val audioUri = ContentUris.withAppendedId(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, mediaId)
        var bytes: ByteArray? = null

        // 1. Embedded picture via MediaMetadataRetriever
        val retriever = MediaMetadataRetriever()
        try {
            retriever.setDataSource(this, audioUri)
            bytes = retriever.embeddedPicture
        } catch (_: Exception) {
        } finally {
            try {
                retriever.release()
            } catch (_: Exception) {
            }
        }

        // 2. Android 10+ ContentResolver.loadThumbnail fallback
        if ((bytes == null || bytes.isEmpty()) && Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            try {
                val bmp: Bitmap = contentResolver.loadThumbnail(audioUri, Size(512, 512), null)
                val bos = ByteArrayOutputStream()
                bmp.compress(Bitmap.CompressFormat.JPEG, 86, bos)
                bytes = bos.toByteArray()
            } catch (_: Exception) {
            }
        }

        // 3. AlbumArt content URI fallback
        if ((bytes == null || bytes.isEmpty()) && albumId > 0) {
            try {
                val albumArtUri = ContentUris.withAppendedId(
                    Uri.parse("content://media/external/audio/albumart"),
                    albumId
                )
                contentResolver.openInputStream(albumArtUri)?.use { input ->
                    bytes = input.readBytes()
                }
            } catch (_: Exception) {
            }
        }

        return if (bytes != null && bytes!!.isNotEmpty()) {
            try {
                artFile.writeBytes(bytes!!)
            } catch (_: Exception) {
            }
            bytes
        } else {
            try {
                noneFile.createNewFile()
            } catch (_: Exception) {
            }
            null
        }
    }

    private fun serveLocalArtwork(mediaId: Long, albumId: Long): WebResourceResponse {
        val bytes = loadTrackArtworkBytes(mediaId, albumId)
        return if (bytes != null && bytes.isNotEmpty()) {
            WebResourceResponse(
                "image/jpeg",
                null,
                200,
                "OK",
                mapOf(
                    "Access-Control-Allow-Origin" to "*",
                    "Cache-Control" to "public, max-age=86400"
                ),
                ByteArrayInputStream(bytes)
            )
        } else {
            WebResourceResponse(
                "text/plain",
                "UTF-8",
                404,
                "Not Found",
                mapOf("Access-Control-Allow-Origin" to "*"),
                ByteArrayInputStream(ByteArray(0))
            )
        }
    }

    private fun hasAudioReadPermission(): Boolean {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            ContextCompat.checkSelfPermission(
                this,
                Manifest.permission.READ_MEDIA_AUDIO
            ) == PackageManager.PERMISSION_GRANTED
        } else {
            ContextCompat.checkSelfPermission(
                this,
                Manifest.permission.READ_EXTERNAL_STORAGE
            ) == PackageManager.PERMISSION_GRANTED
        }
    }

    @Suppress("DEPRECATION")
    private fun scanDeviceAudioAsync() {
        if (!hasAudioReadPermission()) {
            requestRequiredPhonePermissions()
            return
        }
        scannerExecutor.execute {
            try {
                val tracksArray = JSONArray()
                val projection = mutableListOf(
                    MediaStore.Audio.Media._ID,
                    MediaStore.Audio.Media.TITLE,
                    MediaStore.Audio.Media.ARTIST,
                    MediaStore.Audio.Media.ALBUM,
                    MediaStore.Audio.Media.ALBUM_ID,
                    MediaStore.Audio.Media.DURATION,
                    MediaStore.Audio.Media.DISPLAY_NAME,
                    MediaStore.Audio.Media.MIME_TYPE,
                    MediaStore.Audio.Media.SIZE,
                    MediaStore.Audio.Media.DATE_ADDED,
                    MediaStore.Audio.Media.DATA
                )
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    projection.add(MediaStore.Audio.Media.RELATIVE_PATH)
                }

                val selection = "${MediaStore.Audio.Media.DURATION} > 0"
                val sortOrder = "${MediaStore.Audio.Media.DATE_ADDED} DESC"

                contentResolver.query(
                    MediaStore.Audio.Media.EXTERNAL_CONTENT_URI,
                    projection.toTypedArray(),
                    selection,
                    null,
                    sortOrder
                )?.use { cursor ->
                    val idCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media._ID)
                    val titleCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.TITLE)
                    val artistCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.ARTIST)
                    val albumCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.ALBUM)
                    val albumIdCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.ALBUM_ID)
                    val durationCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.DURATION)
                    val nameCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.DISPLAY_NAME)
                    val mimeCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.MIME_TYPE)
                    val sizeCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.SIZE)
                    val dateCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.DATE_ADDED)
                    val dataCol = cursor.getColumnIndex(MediaStore.Audio.Media.DATA)
                    val relPathCol = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                        cursor.getColumnIndex(MediaStore.Audio.Media.RELATIVE_PATH)
                    } else -1

                    while (cursor.moveToNext()) {
                        val id = cursor.getLong(idCol)
                        val durationMs = cursor.getLong(durationCol)
                        if (durationMs <= 0L) continue

                        val displayName = cursor.getString(nameCol) ?: "track_$id.mp3"
                        val rawTitle = cursor.getString(titleCol)?.trim().orEmpty()
                        val cleanTitle = if (rawTitle.isNotEmpty() && rawTitle != "<unknown>") {
                            rawTitle
                        } else {
                            displayName.substringBeforeLast('.')
                        }

                        val rawArtist = cursor.getString(artistCol)?.trim().orEmpty()
                        val cleanArtist = if (rawArtist.isNotEmpty() && rawArtist != "<unknown>") {
                            rawArtist
                        } else {
                            "فنان غير معروف"
                        }

                        val rawAlbum = cursor.getString(albumCol)?.trim().orEmpty()
                        val cleanAlbum = if (rawAlbum.isNotEmpty() && rawAlbum != "<unknown>") {
                            rawAlbum
                        } else {
                            "سُكون"
                        }

                        val albumId = cursor.getLong(albumIdCol)
                        val mimeType = cursor.getString(mimeCol) ?: "audio/mpeg"
                        val fileSize = cursor.getLong(sizeCol)
                        val dateAddedSec = cursor.getLong(dateCol)

                        val relPath = if (relPathCol >= 0) cursor.getString(relPathCol) else null
                        val fullDataPath = if (dataCol >= 0) cursor.getString(dataCol) else null
                        val folderPath = when {
                            !relPath.isNullOrBlank() -> relPath.trimEnd('/', '\\')
                            !fullDataPath.isNullOrBlank() -> {
                                File(fullDataPath).parentFile?.name ?: "Music"
                            }
                            else -> "Music"
                        }

                        val ext = displayName.substringAfterLast('.', "mp3").uppercase()

                        val obj = JSONObject().apply {
                            put("id", "ms_$id")
                            put("mediaStoreId", id)
                            put("albumId", albumId)
                            put("title", cleanTitle)
                            put("artist", cleanArtist)
                            put("album", cleanAlbum)
                            put("duration", durationMs.toDouble() / 1000.0)
                            put("folderPath", folderPath)
                            put("fileName", displayName)
                            put("mimeType", mimeType)
                            put("fileSize", fileSize)
                            put("formatLabel", ext)
                            put("addedAt", if (dateAddedSec > 0) dateAddedSec * 1000L else System.currentTimeMillis())
                            put("audioUrl", "https://$VIRTUAL_ASSET_HOST/__local_audio/$id")
                            put("coverUrl", "https://$VIRTUAL_ASSET_HOST/__local_art/$id?albumId=$albumId")
                        }
                        tracksArray.put(obj)
                    }
                }

                val jsonStr = tracksArray.toString()
                val b64 = Base64.encodeToString(jsonStr.toByteArray(Charsets.UTF_8), Base64.NO_WRAP)
                runOnUiThread {
                    webView.evaluateJavascript(
                        "window.__onNativeAudioScannedB64 && window.__onNativeAudioScannedB64('$b64');",
                        null
                    )
                }
            } catch (_: Exception) {
            }
        }
    }

    private var suppressNativeEchoUntilMs: Long = 0L

    override fun onStart() {
        super.onStart()
        val sessionToken = SessionToken(this, ComponentName(this, PlaybackService::class.java))
        controllerFuture = MediaController.Builder(this, sessionToken).buildAsync()
        controllerFuture?.addListener(
            {
                val controller = mediaController ?: return@addListener
                controller.addListener(object : Player.Listener {
                    override fun onIsPlayingChanged(isPlaying: Boolean) {
                        if (System.currentTimeMillis() < suppressNativeEchoUntilMs) return
                        val action = if (isPlaying) "play" else "pause"
                        runOnUiThread {
                            webView.evaluateJavascript(
                                "window.__onNativeMediaAction && window.__onNativeMediaAction('$action');",
                                null
                            )
                        }
                    }
                })
            },
            MoreExecutors.directExecutor()
        )
    }

    override fun onStop() {
        controllerFuture?.let { MediaController.releaseFuture(it) }
        controllerFuture = null
        super.onStop()
    }

    fun playAudioWithMetadata(
        mediaId: String,
        audioUri: Uri,
        title: String,
        artist: String,
        album: String = "سُكون",
        artworkBytes: ByteArray? = null,
        artworkUri: Uri? = null
    ) {
        val controller = mediaController ?: return
        val mediaItem: MediaItem = PlaybackService.buildRealmeCompatibleMediaItem(
            mediaId = mediaId,
            audioUri = audioUri,
            title = title,
            artist = artist,
            album = album,
            artworkBytes = artworkBytes,
            artworkUri = artworkUri
        )
        controller.setMediaItem(mediaItem)
        controller.prepare()
        controller.play()
    }

    private fun requestRequiredPhonePermissions(): Boolean {
        val needed = mutableListOf<String>()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)
                != PackageManager.PERMISSION_GRANTED
            ) {
                needed.add(Manifest.permission.POST_NOTIFICATIONS)
            }
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_MEDIA_AUDIO)
                != PackageManager.PERMISSION_GRANTED
            ) {
                needed.add(Manifest.permission.READ_MEDIA_AUDIO)
            }
        } else {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_EXTERNAL_STORAGE)
                != PackageManager.PERMISSION_GRANTED
            ) {
                needed.add(Manifest.permission.READ_EXTERNAL_STORAGE)
            }
        }
        if (needed.isNotEmpty()) {
            ActivityCompat.requestPermissions(this, needed.toTypedArray(), PERMISSION_REQUEST_CODE)
            return false
        }
        return true
    }

    @Suppress("DEPRECATION")
    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == PERMISSION_REQUEST_CODE) {
            val allGranted = grantResults.isNotEmpty() &&
                    grantResults.all { it == PackageManager.PERMISSION_GRANTED }
            if (hasAudioReadPermission()) {
                scanDeviceAudioAsync()
            }
            runOnUiThread {
                webView.evaluateJavascript(
                    "window.__onNativePermissionResult && window.__onNativePermissionResult($allGranted);",
                    null
                )
            }
        }
    }

    private var lastSyncedTrackId: String? = null

    inner class AndroidMediaBridge {
        @JavascriptInterface
        fun scanDeviceAudio() {
            scanDeviceAudioAsync()
        }

        @JavascriptInterface
        fun updateMediaSession(jsonPayload: String) {
            runOnUiThread {
                try {
                    suppressNativeEchoUntilMs = System.currentTimeMillis() + 900L
                    val obj = JSONObject(jsonPayload)
                    val trackId = obj.optString("trackId", "track_1")
                    val title = obj.optString("title", "سُكون").ifBlank { "سُكون" }
                    val artist = obj.optString("artist", "فنان غير معروف").ifBlank { "فنان غير معروف" }
                    val album = obj.optString("album", "سُكون").ifBlank { "سُكون" }
                    val isPlaying = obj.optBoolean("isPlaying", true)
                    val artworkBase64 = obj.optString("artworkBase64", "")

                    val nativeMediaId = if (trackId.startsWith("ms_")) {
                        trackId.removePrefix("ms_").toLongOrNull()
                    } else null

                    val artworkBytes: ByteArray = when {
                        artworkBase64.startsWith("data:image") -> {
                            val base64Part = artworkBase64.substringAfter(",")
                            Base64.decode(base64Part, Base64.DEFAULT)
                        }
                        nativeMediaId != null -> {
                            loadTrackArtworkBytes(nativeMediaId, 0L)
                                ?: PlaybackService.generateFallbackCoverBytes()
                        }
                        else -> PlaybackService.generateFallbackCoverBytes()
                    }

                    val controller = mediaController ?: return@runOnUiThread
                    val metadata = MediaMetadata.Builder()
                        .setTitle(title)
                        .setDisplayTitle(title)
                        .setArtist(artist)
                        .setAlbumTitle(album)
                        .setIsPlayable(true)
                        .setIsBrowsable(false)
                        .setMediaType(MediaMetadata.MEDIA_TYPE_MUSIC)
                        .setArtworkData(artworkBytes, MediaMetadata.PICTURE_TYPE_FRONT_COVER)
                        .build()

                    val item = MediaItem.Builder()
                        .setMediaId(trackId)
                        .setUri(Uri.parse("asset:///silent_keepalive.wav"))
                        .setMediaMetadata(metadata)
                        .build()

                    lastSyncedTrackId = trackId
                    controller.setMediaItem(item)
                    controller.prepare()
                    if (isPlaying) {
                        controller.play()
                    } else {
                        controller.pause()
                    }
                } catch (_: Exception) {
                }
            }
        }

        @JavascriptInterface
        fun updatePlaybackState(isPlaying: Boolean, positionMs: Long, durationMs: Long) {
            runOnUiThread {
                val controller = mediaController ?: return@runOnUiThread
                if (isPlaying && !controller.isPlaying) {
                    suppressNativeEchoUntilMs = System.currentTimeMillis() + 600L
                    controller.play()
                } else if (!isPlaying && controller.isPlaying) {
                    suppressNativeEchoUntilMs = System.currentTimeMillis() + 600L
                    controller.pause()
                }
            }
        }

        @JavascriptInterface
        fun stopMediaService() {
            runOnUiThread {
                mediaController?.stop()
            }
        }

        @JavascriptInterface
        fun requestSystemPermissions(): Boolean {
            return requestRequiredPhonePermissions()
        }

        @JavascriptInterface
        fun hasNotificationPermission(): Boolean {
            return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                ContextCompat.checkSelfPermission(
                    this@MainActivity,
                    Manifest.permission.POST_NOTIFICATIONS
                ) == PackageManager.PERMISSION_GRANTED
            } else {
                true
            }
        }

        @JavascriptInterface
        fun openCapsuleSystemSettings() {
            try {
                val intent = Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS).apply {
                    putExtra(Settings.EXTRA_APP_PACKAGE, packageName)
                }
                startActivity(intent)
            } catch (_: Exception) {
            }
        }
    }
}
