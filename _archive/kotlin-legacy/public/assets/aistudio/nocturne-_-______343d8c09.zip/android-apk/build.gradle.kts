plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    // الاحتفاظ بالـ namespace الحالي كما هو حتى لا تتأثر الـ imports والكلاسات
    namespace = "com.nocturne.sukoon.player"
    compileSdk = 35 // Android 15

    defaultConfig {
        // تغيير الـ applicationId حصرياً لتخطي الـ Package Whitelist في Realme UI 6.0 (OplusMediaController)
        applicationId = "com.hiby.music"
        minSdk = 26
        targetSdk = 35
        versionCode = 1
        versionName = "1.0.0"

        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = "17"
    }
}

dependencies {
    val media3Version = "1.4.1"

    // مكتبات Media3 الأساسية المطلوبة لـ Realme UI 6.0 Live Alerts / Dynamic Island
    implementation("androidx.media3:media3-exoplayer:$media3Version")
    implementation("androidx.media3:media3-session:$media3Version")
    implementation("androidx.media3:media3-ui:$media3Version")

    // مكتبات أندرويد الأساسية
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("com.google.android.material:material:1.12.0")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-guava:1.8.1")
}
