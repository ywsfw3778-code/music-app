package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.LayoutDirection

@Composable
fun NocturneTheme(
    accentColor: Color = NocturneCyan,
    content: @Composable () -> Unit
) {
    val colorScheme = darkColorScheme(
        primary = accentColor,
        onPrimary = PitchBlackAmoled,
        secondary = NocturneViolet,
        onSecondary = TextPureWhite,
        tertiary = accentColor,
        background = PitchBlackAmoled,
        onBackground = TextPureWhite,
        surface = PitchBlackAmoled,
        onSurface = TextPureWhite,
        surfaceVariant = WaterDropWhite5,
        onSurfaceVariant = TextSecondarySilver,
        error = DangerCrimson,
        onError = TextPureWhite
    )

    // Force fixed Arabic RTL direction across all screens, bars, and sliders
    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
        MaterialTheme(
            colorScheme = colorScheme,
            typography = Typography,
            content = content
        )
    }
}
