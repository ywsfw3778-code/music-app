package com.example

import android.app.PendingIntent
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.net.Uri
import android.os.Build
import android.os.SystemClock
import android.view.KeyEvent
import androidx.annotation.OptIn
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.common.ForwardingPlayer
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.Player
import androidx.media3.common.util.UnstableApi
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.session.DefaultMediaNotificationProvider
import androidx.media3.session.MediaSession
import androidx.media3.session.MediaSessionService
import java.io.ByteArrayOutputStream

/**
 * PlaybackService المتوافق مع Android 15 وواجهة Realme UI 6.0 (ColorOS 15) Live Alerts / Dynamic Island.
 *
 * يرث من `MediaSessionService` (مكتبة Media3) ويربط `ExoPlayer` بـ `MediaSession`
 * مع ضمان عدم إرسال أي `MediaItem` بدون `Title` و `Artist` و `ArtworkData` صالحة.
 */
class PlaybackService : MediaSessionService() {

    private var mediaSession: MediaSession? = null
    private lateinit var player: ExoPlayer
    private lateinit var sessionPlayer: ForwardingPlayer
    private var lastSyncedTrackId: String? = null

    companion object {
        var webViewActionCallback: ((action: String, seekSec: Double?) -> Unit)? = null
        @Volatile var reportedDurationMs: Long = 0L
        @Volatile var reportedPositionMs: Long = 0L
        @Volatile var reportedPositionUpdatedAtMs: Long = 0L
        @Volatile var reportedIsPlaying: Boolean = false
        @Volatile var lastExternalCommandMs: Long = 0L
        @Volatile var instance: PlaybackService? = null

        /**
         * يبني MediaItem مكتمل الـ MediaMetadata (بما في ذلك صورة غلاف احتياطية إن لم تتوفر)
         * لأن OplusMediaController في Realme UI 6.0 يرفض عرض الكبسولة إذا كانت البيانات فارغة.
         */
        fun buildRealmeCompatibleMediaItem(
            mediaId: String,
            audioUri: Uri,
            title: String,
            artist: String,
            album: String = "سُكون",
            artworkBytes: ByteArray? = null,
            artworkUri: Uri? = null
        ): MediaItem {
            val safeTitle = title.ifBlank { "مقطع صوتي" }
            val safeArtist = artist.ifBlank { "فنان غير معروف" }
            val finalArtworkBytes = artworkBytes ?: generateFallbackCoverBytes()

            val metadataBuilder = MediaMetadata.Builder()
                .setTitle(safeTitle)
                .setDisplayTitle(safeTitle)
                .setArtist(safeArtist)
                .setAlbumTitle(album.ifBlank { "سُكون" })
                .setIsPlayable(true)
                .setIsBrowsable(false)
                .setMediaType(MediaMetadata.MEDIA_TYPE_MUSIC)
                .setArtworkData(finalArtworkBytes, MediaMetadata.PICTURE_TYPE_FRONT_COVER)

            if (artworkUri != null) {
                metadataBuilder.setArtworkUri(artworkUri)
            }

            return MediaItem.Builder()
                .setMediaId(mediaId)
                .setUri(audioUri)
                .setMediaMetadata(metadataBuilder.build())
                .build()
        }

        /**
         * يولد صورة غلاف مربعة 512x512 بصيغة PNG في حال عدم وجود غلاف مدمج بالملف الصوتي
         * لضمان استجابة كبسولة Realme UI 6.0 دائماً.
         */
        fun generateFallbackCoverBytes(): ByteArray {
            val size = 512
            val bmp = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
            val canvas = Canvas(bmp)
            canvas.drawColor(Color.parseColor("#09090B"))

            val ringPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                style = Paint.Style.STROKE
                strokeWidth = 6f
                color = Color.parseColor("#27272A")
            }
            canvas.drawCircle(size / 2f, size / 2f, 180f, ringPaint)
            canvas.drawCircle(size / 2f, size / 2f, 130f, ringPaint)

            val centerPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                style = Paint.Style.FILL
                color = Color.parseColor("#F4F4F5")
            }
            canvas.drawCircle(size / 2f, size / 2f, 64f, centerPaint)

            val holePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                style = Paint.Style.FILL
                color = Color.BLACK
            }
            canvas.drawCircle(size / 2f, size / 2f, 18f, holePaint)

            val out = ByteArrayOutputStream()
            bmp.compress(Bitmap.CompressFormat.PNG, 90, out)
            return out.toByteArray()
        }
    }

    private fun dispatchToWebView(action: String, seekSec: Double? = null) {
        lastExternalCommandMs = SystemClock.elapsedRealtime()
        android.util.Log.d("SukoonMedia", "dispatchToWebView action=$action seek=$seekSec")
        webViewActionCallback?.invoke(action, seekSec)
    }

    fun syncFromWebViewMetadata(
        trackId: String,
        title: String,
        artist: String,
        album: String,
        artworkBytes: ByteArray,
        durationMs: Long,
        isPlaying: Boolean
    ) {
        if (durationMs > 0L) {
            reportedDurationMs = durationMs
        }
        reportedIsPlaying = isPlaying
        reportedPositionUpdatedAtMs = SystemClock.elapsedRealtime()
        player.repeatMode = Player.REPEAT_MODE_ONE

        if (lastSyncedTrackId != trackId || player.mediaItemCount == 0) {
            val metadataBuilder = MediaMetadata.Builder()
                .setTitle(title)
                .setDisplayTitle(title)
                .setArtist(artist)
                .setAlbumTitle(album)
                .setIsPlayable(true)
                .setIsBrowsable(false)
                .setMediaType(MediaMetadata.MEDIA_TYPE_MUSIC)
                .setArtworkData(artworkBytes, MediaMetadata.PICTURE_TYPE_FRONT_COVER)
            if (durationMs > 0L) {
                metadataBuilder.setDurationMs(durationMs)
            }
            val item = MediaItem.Builder()
                .setMediaId(trackId)
                .setUri(Uri.parse("asset:///silent_keepalive.wav"))
                .setMediaMetadata(metadataBuilder.build())
                .build()

            lastSyncedTrackId = trackId
            player.setMediaItem(item)
            player.prepare()
        }

        if (isPlaying) {
            if (!player.isPlaying) player.play()
        } else {
            if (player.isPlaying) player.pause()
        }
    }

    fun syncFromWebViewPlaybackState(isPlaying: Boolean, positionMs: Long, durationMs: Long) {
        if (durationMs > 0L) {
            reportedDurationMs = durationMs
        }
        reportedPositionMs = positionMs.coerceAtLeast(0L)
        reportedPositionUpdatedAtMs = SystemClock.elapsedRealtime()

        if (SystemClock.elapsedRealtime() - lastExternalCommandMs < 1500L) {
            return
        }

        reportedIsPlaying = isPlaying
        if (isPlaying && !player.isPlaying) {
            player.play()
        } else if (!isPlaying && player.isPlaying) {
            player.pause()
        }
    }

    fun stopFromWebView() {
        lastSyncedTrackId = null
        reportedIsPlaying = false
        player.stop()
    }

    @OptIn(UnstableApi::class)
    override fun onCreate() {
        super.onCreate()
        instance = this

        val audioAttributes = AudioAttributes.Builder()
            .setUsage(C.USAGE_MEDIA)
            .setContentType(C.AUDIO_CONTENT_TYPE_MUSIC)
            .build()

        player = ExoPlayer.Builder(this)
            .setAudioAttributes(audioAttributes, /* handleAudioFocus = */ false)
            .setHandleAudioBecomingNoisy(true)
            .setWakeMode(C.WAKE_MODE_LOCAL)
            .build().apply {
                repeatMode = Player.REPEAT_MODE_ONE
                volume = 0f
            }

        val openActivityIntent = Intent(this, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }
        val sessionActivityPendingIntent = PendingIntent.getActivity(
            this,
            0,
            openActivityIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        sessionPlayer = object : ForwardingPlayer(player) {
            override fun getDuration(): Long {
                val d = reportedDurationMs
                return if (d > 0L) d else super.getDuration()
            }

            override fun getContentDuration(): Long = getDuration()

            override fun getCurrentPosition(): Long {
                val d = reportedDurationMs
                if (d <= 0L) return super.getCurrentPosition()
                val elapsed = if (reportedIsPlaying && reportedPositionUpdatedAtMs > 0L) {
                    (SystemClock.elapsedRealtime() - reportedPositionUpdatedAtMs).coerceAtLeast(0L)
                } else 0L
                return (reportedPositionMs + elapsed).coerceIn(0L, d)
            }

            override fun getContentPosition(): Long = getCurrentPosition()

            override fun getAvailableCommands(): Player.Commands {
                return super.getAvailableCommands().buildUpon()
                    .addAll(
                        Player.COMMAND_PLAY_PAUSE,
                        Player.COMMAND_STOP,
                        Player.COMMAND_SEEK_TO_NEXT,
                        Player.COMMAND_SEEK_TO_NEXT_MEDIA_ITEM,
                        Player.COMMAND_SEEK_TO_PREVIOUS,
                        Player.COMMAND_SEEK_TO_PREVIOUS_MEDIA_ITEM,
                        Player.COMMAND_SEEK_IN_CURRENT_MEDIA_ITEM
                    )
                    .build()
            }

            override fun isCommandAvailable(command: Int): Boolean {
                return when (command) {
                    Player.COMMAND_PLAY_PAUSE,
                    Player.COMMAND_STOP,
                    Player.COMMAND_SEEK_TO_NEXT,
                    Player.COMMAND_SEEK_TO_NEXT_MEDIA_ITEM,
                    Player.COMMAND_SEEK_TO_PREVIOUS,
                    Player.COMMAND_SEEK_TO_PREVIOUS_MEDIA_ITEM,
                    Player.COMMAND_SEEK_IN_CURRENT_MEDIA_ITEM -> true
                    else -> super.isCommandAvailable(command)
                }
            }

            override fun hasNextMediaItem(): Boolean = true

            override fun hasPreviousMediaItem(): Boolean = true

            override fun getNextMediaItemIndex(): Int = 0

            override fun getPreviousMediaItemIndex(): Int = 0

            override fun getMaxSeekToPreviousPosition(): Long = Long.MAX_VALUE

            override fun seekToNext() {
                dispatchToWebView("next")
            }

            override fun seekToNextMediaItem() {
                dispatchToWebView("next")
            }

            override fun seekToPrevious() {
                dispatchToWebView("prev")
            }

            override fun seekToPreviousMediaItem() {
                dispatchToWebView("prev")
            }

            override fun seekTo(positionMs: Long) {
                reportedPositionMs = positionMs.coerceAtLeast(0L)
                reportedPositionUpdatedAtMs = SystemClock.elapsedRealtime()
                dispatchToWebView("seek", positionMs / 1000.0)
            }

            override fun seekTo(mediaItemIndex: Int, positionMs: Long) {
                reportedPositionMs = positionMs.coerceAtLeast(0L)
                reportedPositionUpdatedAtMs = SystemClock.elapsedRealtime()
                dispatchToWebView("seek", positionMs / 1000.0)
            }

            override fun play() {
                reportedIsPlaying = true
                reportedPositionUpdatedAtMs = SystemClock.elapsedRealtime()
                super.play()
                dispatchToWebView("play")
            }

            override fun pause() {
                reportedIsPlaying = false
                reportedPositionUpdatedAtMs = SystemClock.elapsedRealtime()
                super.pause()
                dispatchToWebView("pause")
            }

            override fun setPlayWhenReady(playWhenReady: Boolean) {
                reportedIsPlaying = playWhenReady
                reportedPositionUpdatedAtMs = SystemClock.elapsedRealtime()
                super.setPlayWhenReady(playWhenReady)
                dispatchToWebView(if (playWhenReady) "play" else "pause")
            }
        }

        mediaSession = MediaSession.Builder(this, sessionPlayer)
            .setSessionActivity(sessionActivityPendingIntent)
            .setCallback(object : MediaSession.Callback {
                override fun onPlayerCommandRequest(
                    session: MediaSession,
                    controller: MediaSession.ControllerInfo,
                    playerCommand: Int
                ): Int {
                    android.util.Log.d("SukoonMedia", "onPlayerCommandRequest cmd=$playerCommand from=${controller.packageName}")
                    return super.onPlayerCommandRequest(session, controller, playerCommand)
                }

                override fun onMediaButtonEvent(
                    session: MediaSession,
                    controllerInfo: MediaSession.ControllerInfo,
                    mediaButtonIntent: Intent
                ): Boolean {
                    val keyEvent: KeyEvent? = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                        mediaButtonIntent.getParcelableExtra(Intent.EXTRA_KEY_EVENT, KeyEvent::class.java)
                    } else {
                        @Suppress("DEPRECATION")
                        mediaButtonIntent.getParcelableExtra(Intent.EXTRA_KEY_EVENT)
                    }
                    if (keyEvent != null && keyEvent.action == KeyEvent.ACTION_DOWN && keyEvent.repeatCount == 0) {
                        android.util.Log.d("SukoonMedia", "onMediaButtonEvent keyCode=${keyEvent.keyCode}")
                        when (keyEvent.keyCode) {
                            KeyEvent.KEYCODE_MEDIA_NEXT -> {
                                dispatchToWebView("next")
                                return true
                            }
                            KeyEvent.KEYCODE_MEDIA_PREVIOUS -> {
                                dispatchToWebView("prev")
                                return true
                            }
                            KeyEvent.KEYCODE_MEDIA_PAUSE -> {
                                sessionPlayer.pause()
                                return true
                            }
                            KeyEvent.KEYCODE_MEDIA_PLAY -> {
                                sessionPlayer.play()
                                return true
                            }
                            KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE, KeyEvent.KEYCODE_HEADSETHOOK -> {
                                if (reportedIsPlaying) sessionPlayer.pause() else sessionPlayer.play()
                                return true
                            }
                        }
                    }
                    return super.onMediaButtonEvent(session, controllerInfo, mediaButtonIntent)
                }
            })
            .build()

        val notificationProvider = DefaultMediaNotificationProvider.Builder(this)
            .build()
        setMediaNotificationProvider(notificationProvider)
    }

    override fun onGetSession(controllerInfo: MediaSession.ControllerInfo): MediaSession? {
        return mediaSession
    }

    override fun onTaskRemoved(rootIntent: Intent?) {
        val currentPlayer = mediaSession?.player
        if (currentPlayer == null || !currentPlayer.playWhenReady || currentPlayer.mediaItemCount == 0) {
            stopSelf()
        }
    }

    override fun onDestroy() {
        if (instance === this) {
            instance = null
        }
        mediaSession?.run {
            player.release()
            release()
            mediaSession = null
        }
        super.onDestroy()
    }
}
